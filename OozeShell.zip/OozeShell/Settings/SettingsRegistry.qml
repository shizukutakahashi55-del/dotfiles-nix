// SettingsRegistry — lista única de las categorías de Ajustes avanzados, ordenadas por grupo (Usuario · Aspecto · Escritorio · Sistema · Acerca de).

pragma Singleton
import QtQuick
import Quickshell
import "../Services/Lang"
import "../COMMON"
import "../Services/Agents"

Singleton {
  id: root


  readonly property var allCategories: [
    { id: "profile", group: "personal",    icon: "󰀄", titleKey: "advCatProfile",     page: "pages/ProfilePage.qml" },

    { id: "general", group: "personal",    icon: "󰒓", titleKey: "advCatGeneral",     page: "pages/GeneralPage.qml" },

    { id: "appearance", group: "look", icon: "󰏘", titleKey: "advCatAppearance",  page: "pages/AppearancePage.qml" },

    { id: "interface", group: "look",  icon: "󰕰", titleKey: "advCatInterface",   page: "pages/InterfacePage.qml" },

    { id: "wallpapers", group: "look",  icon: "󰸉", titleKey: "advCatWallpapers",  page: "pages/WallpapersPage.qml",
      sections: [
        { titleKey: "wallsFoldersTitle",
          kw: "carpeta carpetas folder directorio ruta path wallpapers livewallpapers live video videos imagenes fondo examinar descargas download",
          rows: [
            { labelKey: "wallsFolderStatic", kw: "wallpapers imagenes fondos carpeta folder ruta path jpg png" },
            { labelKey: "wallsFolderLive",   kw: "livewallpapers live video videos mp4 mpvpaper carpeta folder ruta path" },
            { labelKey: "wallsOnlineSaveDir", kw: "carpeta descargas folder download guardar ruta path online" }
          ] },
        { titleKey: "wallsLayoutTitle",
          kw: "galeria layout diseno disposicion compacto compact top normal selectores barra panel wallpapers fondos",
          rows: [
            { labelKey: "wallsLayoutChoice", hintKey: "wallsLayoutChoiceHint", kw: "layout compacto compact normal top fullview full view grande centrado inclinado paralelogramo rail lateral vertical columna lista list vista previa preview izquierda derecha selectores barra galeria disposicion" },
            { labelKey: "wallsRailSide", kw: "rail lateral lado izquierda derecha left right side borde" },
            { labelKey: "wallsHqPreview", hintKey: "wallsHqPreviewHint", kw: "hq preview vista previa alta calidad gif live en vivo video animada nitidez resolucion" },
            { labelKey: "wallsLayoutSize", kw: "tamano tamaño size escala scale slider galeria compact normal porcentaje" }
          ] },
        { titleKey: "advMatugenTitle", hintKey: "advPaletteHint",
          kw: "matugen palette paleta colores color esquema scheme wallpaper fondo automatico",
          rows: [] },
        { titleKey: "wallsStaticTitle",
          kw: "estatico estaticos imagen awww oozewalls ajuste fit crop stretch no recortar encajar estirar bandas relleno color",
          rows: [
            { labelKey: "wallsStaticEngine", hintKey: "wallsStaticEngineHint", kw: "motor engine backend awww oozewalls capa layer imagen estatico ligero ram" },
            { labelKey: "wallsStaticFit", kw: "ajuste fit crop llenar encajar estirar stretch original recortar resize" },
            { labelKey: "wallsStaticFill", hintKey: "wallsStaticFillHint", kw: "color relleno bandas fill hex negro" }
          ] },
        { titleKey: "wallsAnimTitle",
          kw: "animacion transicion cambio fade desvanecer deslizar slide barrido wipe circulo zoom persianas aleatoria random efecto duracion",
          rows: [
            { labelKey: "wallsAnimKind", hintKey: "wallsAnimHint", kw: "animacion transicion cambio fade desvanecer deslizar slide barrido wipe circulo zoom persianas aleatoria random efecto" },
            { labelKey: "wallsAnimDuration", kw: "duracion tiempo velocidad milisegundos ms animacion transicion" }
          ] },
        { titleKey: "wallsLiveTitle",
          kw: "live en vivo video animado mpvpaper mpv fondo animado rendimiento gpu cpu matugen",
          rows: [
            { labelKey: "wallsLiveEngine", hintKey: "wallsLiveEngineHint", kw: "motor engine backend mpvpaper oozewalls control restaurar inicio" },
            { labelKey: "wallsLiveFit", kw: "ajuste llenar encajar fill fit panscan recortar bandas" },
            { labelKey: "wallsLiveLayer", hintKey: "wallsLiveLayerHint", kw: "capa layer bottom background" },
            { labelKey: "wallsLiveHwdec", hintKey: "wallsLiveHwdecHint", kw: "hwdec hardware decodificacion vaapi nvdec gpu" }
          ] },
        { titleKey: "wallsLiveSaveTitle",
          kw: "ahorro recursos rendimiento ram vram memoria live en vivo video optimizar",
          rows: [
            { labelKey: "wallsLiveOptimize", hintKey: "wallsLiveOptimizeHint", kw: "copia liviana optimizar ffmpeg reencodear ligera ahorro memoria" },
            { labelKey: "wallsLiveMaxHeight", kw: "alto maximo altura resolucion 1080p 720p height" },
            { labelKey: "wallsLiveMaxFps", kw: "fps cuadros fotogramas 30 60 framerate" },
            { labelKey: "wallsLiveSwap", hintKey: "wallsLiveSwapHint", kw: "cambiar copia parpadeo relanzar swap" },
            { labelKey: "wallsLiveStopHidden", hintKey: "wallsLiveStopHiddenHint", kw: "parar pausar fullscreen pantalla completa ahorro energia power-saver ocultar" },
            { labelKey: "wallsLiveRam", hintKey: "wallsLiveRamHint", kw: "ram memoria tope limite fuga vigilante watchdog mb" }
          ] },
        { titleKey: "wallsOnlineTitle", hintKey: "wallsOnlineHint",
          kw: "online internet en linea wallhaven bing descargar descarga fuente remoto nube wallpapers fondos busqueda sfw matugen",
          rows: [
            { labelKey: "wallsOnlineSource", kw: "fuente source wallhaven bing" },
            { labelKey: "wallsOnlineQuery", hintKey: "wallsOnlineQueryHint", kw: "busqueda buscar search consulta palabras clave keywords tags" },
            { labelKey: "wallsOnlineSorting", kw: "orden sorting top popular aleatorio random recientes latest relevancia vistas" },
            { labelKey: "wallsOnlineCats", kw: "categorias categories general anime personas people" },
            { labelKey: "wallsOnlineRes", kw: "resolucion minima resolution 1080p 1440p 4k" },
            { labelKey: "wallsOnlinePurity", hintKey: "wallsOnlinePurityHint", kw: "pureza purity nsfw sfw sketchy adulto +18 contenido" },
            { labelKey: "wallsOnlineApiKey", hintKey: "wallsOnlineApiKeyHint", kw: "api key clave token wallhaven" }
          ] },
        { titleKey: "wallsOnlineLiveTitle", hintKey: "wallsOnlineLiveHint",
          kw: "online live en vivo video videos moewalls wallpaperwaifu descargar fuente",
          rows: [
            { labelKey: "wallsOnlineSource", kw: "fuente source moewalls wallpaperwaifu" }
          ] },
        { titleKey: "wallsToolsTitle", hintKey: "wallsToolsHint",
          kw: "herramientas instalar instalado dependencias requisitos awww oozewalls mpvpaper ffmpeg socat curl jq matugen tools install",
          rows: [] }
      ] },

    { id: "terminal", group: "look", icon: "󰞷", titleKey: "advCatTerminal", page: "pages/TerminalPage.qml",
      sections: [
        { titleKey: "termDotfilesTitle", hintKey: "termDotfilesHint",
          kw: "dotfiles configuracion config carpeta repositorio git enlaces symlink zshrc editar terminal buscar escanear",
          rows: [
            { labelKey: "termDotfilesFolder", kw: "carpeta repositorio dotfiles abrir buscar escanear git" }
          ] },
        { titleKey: "termOpacityTitle", hintKey: "termOpacityHint",
          kw: "opacidad transparencia transparente alpha terminal kitty ghostty foot alacritty wezterm fondo translucido",
          rows: [] },
        { titleKey: "termStarshipTitle", hintKey: "termStarshipHint",
          kw: "starship prompt prompt linea comandos hora fecha directorio carpeta duracion matugen plantilla editar toml",
          rows: [
            { labelKey: "termStarshipNewline", kw: "linea blanco espacio salto prompt newline" },
            { labelKey: "termStarshipTime", kw: "hora reloj time mostrar prompt" },
            { labelKey: "termStarshipTimeFormat", kw: "formato hora 24 12 horas am pm" },
            { labelKey: "termStarshipDuration", kw: "duracion tiempo comando lento cmd_duration" },
            { labelKey: "termStarshipDurationMin", kw: "duracion minimo segundos umbral cmd_duration" },
            { labelKey: "termStarshipDirDepth", kw: "directorio carpeta niveles profundidad truncar ruta" }
          ] }
      ] },

    { id: "fastfetch", group: "look", icon: "󰣇", titleKey: "advCatFastfetch", page: "pages/FastfetchPage.qml",
      sections: [
        { titleKey: "termFastfetchTitle", hintKey: "termFastfetchHint",
          kw: "fastfetch neofetch random-fastfetch inicio terminal apagar encender probar sistema info",
          rows: [
            { labelKey: "termFastfetchEnable", hintKey: "termFastfetchEnableHint", kw: "fastfetch apagar encender desactivar activar inicio terminal on off" },
            { labelKey: "termFfTest", hintKey: "termFfTestHint", kw: "probar prueba test terminal sixel kitty imagen" }
          ] },
        { titleKey: "termFfLogoTitle",
          kw: "logo imagen imagenes aleatoria random fija distro ascii ansi sin logo carpeta images",
          rows: [
            { labelKey: "termFfSource", kw: "origen fuente imagenes distro ansi ninguno logo" },
            { labelKey: "termFastfetchRandom", hintKey: "termFastfetchRandomHint", kw: "random aleatorio imagen logo azar random-fastfetch" },
            { labelKey: "termFastfetchImagesTitle", hintKey: "termFastfetchImagesHint", kw: "imagenes agregar anadir copiar carpeta logo borrar eliminar fija elegir" },
            { labelKey: "termFfBuiltin", hintKey: "termFfBuiltinHint", kw: "nombre logo distro arch ubuntu list-logos ascii" }
          ] },
        { titleKey: "termFfTypeTitle", hintKey: "termFfTypeHint",
          kw: "tipo entrada input protocolo sixel kitty iterm chafa auto deteccion detectar terminal imagen",
          rows: [] },
        { titleKey: "termFfMarginsTitle",
          kw: "margenes margins padding espacio ancho alto width height posicion logo izquierda derecha arriba abajo",
          rows: [
            { labelKey: "termFfMarginsOn", hintKey: "termFfMarginsOnHint", kw: "margenes personalizar padding espacio" },
            { labelKey: "termFfPadTop", kw: "arriba top margen padding" },
            { labelKey: "termFfPadBottom", kw: "abajo bottom margen padding" },
            { labelKey: "termFfPadLeft", kw: "izquierda left margen padding" },
            { labelKey: "termFfPadRight", kw: "derecha right margen padding" },
            { labelKey: "termFfWidth", hintKey: "termFfSizeHint", kw: "ancho width tamano size caracteres logo" },
            { labelKey: "termFfHeight", kw: "alto height tamano size caracteres logo" },
            { labelKey: "termFfPosition", kw: "posicion position logo izquierda derecha arriba left right top" }
          ] },
        { titleKey: "termFfStyleTitle", hintKey: "termFfStyleHint",
          kw: "estilo style preset presets neofetch archey paleofetch screenfetch examples config jsonc vista previa",
          rows: [
            { labelKey: "termFfPreview", hintKey: "termFfPreviewHint", kw: "vista previa preview modulos" }
          ] },
        { titleKey: "termAnsiTitle", hintKey: "termAnsiHint",
          kw: "ansi arte art logo colores escape editor texto importar color hex negrita",
          rows: [] }
      ] },

    { id: "bar", group: "desktop", icon: "shape:bar", titleKey: "advCatBar", page: "pages/BarPage.qml",
      sections: [
        { titleKey: "barBackendTitle", hintKey: "barBackendHint",
          kw: "barra bar backend motor waybar ooze propio",
          rows: [
            { labelKey: "barOoze", kw: "ooze propio quickshell" },
            { labelKey: "barWaybar", kw: "waybar" }
          ] },
        { titleKey: "barSection", hintKey: "barSectionHint",
          kw: "barra bar posicion arriba abajo izquierda derecha flotante islas ocultar esconder marco frame position top bottom left right floating",
          rows: [
            { labelKey: "barPosition", kw: "posicion position arriba abajo izquierda derecha top bottom left right" },
            { labelKey: "barFloating", kw: "flotante floating" },
            { labelKey: "barIslands", hintKey: "barIslandsHint", kw: "islas islands pildoras" },
            { labelKey: "barWorkspaceStyle", kw: "workspaces escritorios estilo puntos numeros kanji romanos burbujas lineas dots numbers roman bubbles" },
            { labelKey: "barWorkspaceName", hintKey: "barWorkspaceNameHint", kw: "workspaces nombre name etiqueta" },
            { labelKey: "barModular", hintKey: "barModularHint", kw: "modular pildoras modulos sin fondo pills" },
            { labelKey: "barMixed", hintKey: "barMixedHint", kw: "mixed mixto colores multicolor colorido islas modulos degradado lineas" },
            { labelKey: "barMixedStyle", hintKey: "barMixedStyleHint", kw: "mixed estilo islas modulos degradado lineas gradient lines" },
            { labelKey: "barHide", hintKey: "barHideHint", kw: "ocultar esconder hide barra bar oculta" },
            { labelKey: "barRevealMode", hintKey: "barRevealHint", kw: "mostrar revelar hover click raton" },
            { labelKey: "barHideFrame", hintKey: "barHideFrameHint", kw: "marco marcos frame esquinas corners ocultar" }
          ] },
        { titleKey: "barModulesTitle", hintKey: "barModulesHint",
          kw: "modulos modules isla islands picker elegir orden order mover move izquierda centro derecha left center right reloj clock audio bateria tray bandeja taskbar mpris notificaciones",
          rows: [] },
        { titleKey: "barClockTitle", hintKey: "barClockHint",
          kw: "reloj clock hora time estilo style segundos seconds fecha date tarjetas cards analogico analog 12 24",
          rows: [
            { labelKey: "barClock24h", kw: "24 12 horas formato am pm hour format" },
            { labelKey: "barClockStyle", kw: "estilo style reloj clock segundos fecha tarjetas analogico apilado" }
          ] },
        { titleKey: "barGlass", hintKey: "barGlassHint",
          kw: "cristal glass transparencia translucido opacidad blur desenfoque vidrio",
          rows: [
            { labelKey: "barGlassOpacity", kw: "opacidad transparencia opacity" },
            { labelKey: "barGlassBlur", hintKey: "barGlassBlurHint", kw: "blur desenfoque xray compositor niri" },
            { labelKey: "barGlassSeam", hintKey: "barGlassSeamHint", kw: "union linea sombra franja seam borde barra oscura" }
          ] },
        { titleKey: "barFloatWin", hintKey: "barFloatWinHint",
          kw: "flotante flotantes floating ventanas windows tooltips popups animacion animation resorte spring zoom pop slide fade",
          rows: [
            { labelKey: "barWinAnim", hintKey: "barWinAnimHint", kw: "animacion animation estilo style resorte spring suave smooth zoom pop deslizar slide fade desvanecer" }
          ] },
        { titleKey: "barPillMode", hintKey: "barPillModeHint",
          kw: "pildora pill compacta ocultar",
          rows: [
            { labelKey: "barPillAutoHide", kw: "ocultar esconder auto" },
            { labelKey: "barPillTraySync", kw: "tray bandeja sincronizar" },
            { labelKey: "pillSize", hintKey: "pillSizeHint", kw: "pildora pill tamano size escala scale grande pequeno" }
          ] },
        { titleKey: "dashSection", hintKey: "dashSectionHint",
          kw: "dashboard tablero panel barra pildora pill bar",
          rows: [
            { labelKey: "dashSize", hintKey: "dashSizeHint", kw: "dashboard tablero panel barra bar pildora pill tamano size grande pequeno niveles" }
          ] },
        { titleKey: "batterySection", hintKey: "batteryHint",
          kw: "bateria battery energia",
          rows: [] }
      ] },

    { id: "dock", group: "desktop", icon: "shape:dock", titleKey: "advCatDock", page: "pages/DockPage.qml",
      sections: [
        { titleKey: "dockSection",
          kw: "dock iconos apps barra de aplicaciones",
          rows: [
            { labelKey: "dockEnable",   kw: "dock mostrar show activar encender apagar" },
            { labelKey: "dockAutoHide", kw: "auto ocultar hide esconder" },
            { labelKey: "dockPosition", kw: "posicion position arriba abajo izquierda derecha" }
          ] },
        { titleKey: "advDockLookTitle", hintKey: "advDockLookHint",
          kw: "apariencia modo pildora pill panel fusionado fused flotante floating tamano size escala scale altura height grosor opacidad opacity transparencia blur desenfoque difuminado",
          rows: [
            { labelKey: "advDockModeLabel", hintKey: "advDockModeHint", kw: "modo mode pildora pill panel fusionado fused flotante floating" },
            { labelKey: "dockSize", hintKey: "dockSizeHint", kw: "tamano size escala scale dock grande pequeno" },
            { labelKey: "dockHeight", hintKey: "dockHeightHint", kw: "altura height alto grosor grueso barra dock" },
            { labelKey: "advDockOpacity",   kw: "opacidad opacity transparencia dock" },
            { labelKey: "advDockBlur",      kw: "blur desenfoque difuminado dock" }
          ] }
      ] },

    { id: "widgets", group: "desktop",    icon: "󰕮", titleKey: "advCatWidgets",     page: "pages/WidgetsPage.qml",
      sections: [
        { titleKey: "wgGlobalTitle", hintKey: "wgGlobalHint",
          kw: "widgets global todos apagar encender opacidad blur desenfoque difuminado off on",
          rows: [
            { labelKey: "wgEnabled", kw: "apagar encender todos on off enable" },
            { labelKey: "wgGlobalOpacity", kw: "opacidad opacity transparencia" },
            { labelKey: "wgGlobalBlur", kw: "blur desenfoque difuminado" },
            { labelKey: "wgGlobalBorder", kw: "borde bordes border borders contorno degradado" }
          ] },
        { titleKey: "wgGeneralTitle", hintKey: "wgGeneralHint",
          kw: "widgets escritorio desktop reloj clock sistema cpu ram gpu pomodoro temporizador timer mover arrastrar editar redimensionar resize tamano capa layer wallpaper fondo mpvpaper awww",
          rows: [
            { labelKey: "wgQuickTitle", hintKey: "wgQuickHint", kw: "ajustes rapidos panel lateral compacto clic derecho quick settings side panel right click" },
            { labelKey: "wgEditMode", kw: "mover arrastrar editar posicion redimensionar resize tamano move drag edit" },
            { labelKey: "wgLayerTitle", hintKey: "wgLayerHint", kw: "capa layer bottom background fondo wallpaper encima debajo" },
            { labelKey: "wgFreeMove", hintKey: "wgFreeMoveHint", kw: "movimiento libre mover escritorio arrastrar free move drag" },
            { labelKey: "wgArrange", kw: "ordenar alinear acomodar arrange align overlap encimar" },
            { labelKey: "wgRaise", kw: "subir levantar tapa mpvpaper fondo animado live raise" }
          ] },
        { titleKey: "wgAddTitle", hintKey: "wgAddHint",
          kw: "agregar anadir nuevo crear widget add new create reloj clock sistema system pomodoro" },
        { titleKey: "wgListTitle",
          kw: "lista widgets estilo style monitor pantalla posicion tamano size opciones apagar encender quitar eliminar blur desenfoque difuminado cristal vidrio pomodoro" }
      ] },

    { id: "audiobg", group: "desktop",   icon: "󰝚", titleKey: "advCatAudioBg",     page: "pages/AudioBgPage.qml",
      sections: [
        { titleKey: "abGeneralTitle", hintKey: "abGeneralHint",
          kw: "cava visualizador audio espectro fondo pantalla completa musica ecualizador visualizer spectrum background",
          rows: [
            { labelKey: "abEnabled", kw: "activar encender apagar enable on off cava visualizador" },
            { labelKey: "abDemo", hintKey: "abDemoHint", kw: "demo demostracion prueba test sin audio" },
            { labelKey: "abMonitor", kw: "pantalla monitor screen display" }
          ] },
        { titleKey: "abPlacementTitle", hintKey: "abPlacementHint",
          kw: "posicion borde arriba abajo izquierda derecha centro espejo barra pildora dock marco cristal capa wallpaper",
          rows: [
            { labelKey: "abEdge", hintKey: "abEdgeHint", kw: "borde edge arriba abajo izquierda derecha ambos laterales centro espejo top bottom left right" },
            { labelKey: "abFit", hintKey: "abFitHint", kw: "barra bar pildora pill dock marco frame cristal glass detras ajustar fit behind" },
            { labelKey: "abLayer", hintKey: "abLayerHint", kw: "capa layer bottom background wallpaper awww mpvpaper subir raise" },
            { labelKey: "abThickness", hintKey: "abThicknessHint", kw: "tamano size grosor alto porcentaje" }
          ] },
        { titleKey: "abStyleTitle", hintKey: "abStyleHint",
          kw: "estilo style barras bloques puntos onda linea columnas radial color degradado arcoiris opacidad redondeo picos simetria",
          rows: [
            { labelKey: "abStyle", kw: "estilo style barras bloques puntos onda linea columnas radial bars blocks dots wave line columns" },
            { labelKey: "abColor", kw: "color degradado arcoiris gradient rainbow primario personalizado" },
            { labelKey: "abOpacity", kw: "opacidad transparencia opacity" },
            { labelKey: "abGap", kw: "separacion espacio gap spacing" },
            { labelKey: "abInner", hintKey: "abInnerHint", kw: "radio interior hueco centro radial inner radius" },
            { labelKey: "abRoundness", kw: "redondeo radio round radius" },
            { labelKey: "abPeaks", hintKey: "abPeaksHint", kw: "picos peaks maximo" },
            { labelKey: "abSymmetric", hintKey: "abSymmetricHint", kw: "simetria espejo graves symmetric mirror bass" }
          ] },
        { titleKey: "abAudioTitle", hintKey: "abAudioHint",
          kw: "bandas bars fps suavizado sensibilidad ganancia cava rendimiento audio",
          rows: [
            { labelKey: "abBars", hintKey: "abBarsHint", kw: "bandas barras detalle bars" },
            { labelKey: "abFps", hintKey: "abFpsHint", kw: "fps fotogramas frames rendimiento performance" },
            { labelKey: "abSmooth", kw: "suavizado smooth smoothing caida" },
            { labelKey: "abSensitivity", kw: "sensibilidad ganancia gain sensitivity" },
            { labelKey: "abAutosens", hintKey: "abAutosensHint", kw: "auto sensibilidad automatica autosens" }
          ] }
      ] },

    { id: "mpris", group: "desktop",      icon: "󰎈", titleKey: "advCatMpris",       page: "pages/MprisPage.qml",
      sections: [
        { titleKey: "mprisBarTitle", hintKey: "mprisBarHint",
          kw: "mpris reproductor musica cancion barra horizontal vertical estilo style player media controles progreso aro",
          rows: [
            { labelKey: "mprisStyleBarH", kw: "estilo barra horizontal clasico controles progreso classic controls progress" },
            { labelKey: "mprisStyleBarV", kw: "estilo barra vertical caratula portada aro ring cover controles" }
          ] },
        { titleKey: "mprisDashTitle",
          kw: "mpris dashboard panel reproductor estilo glass cristal portada",
          rows: [
            { labelKey: "mprisStyleDash", kw: "estilo dashboard predeterminado glass cristal portada" }
          ] },
        { titleKey: "mprisPopupTitle", hintKey: "mprisPopupHint",
          kw: "mpris popup ventana cuelga barra reproductor estilo glass tarjeta circulo card circle",
          rows: [
            { labelKey: "mprisStylePopup", kw: "estilo popup ventana barra predeterminado glass tarjeta circulo" }
          ] }
      ] },

    { id: "launcher", group: "desktop",    icon: "󰀻", titleKey: "advCatLauncher",    page: "pages/LauncherPage.qml",
      sections: [
        { titleKey: "lnBackendTitle", hintKey: "lnBackendHint",
          kw: "launcher lanzador backend rofi quickshell ooze aplicaciones apps drun",
          rows: [
            { labelKey: "lnQuickshell", kw: "quickshell ooze propio" },
            { labelKey: "lnRofi", kw: "rofi script" }
          ] },
        { titleKey: "settingsLauncherSection", hintKey: "settingsLauncherHint",
          kw: "launcher lanzador aplicaciones apps ubicacion posicion centro barra center bar imagen image tamano size",
          rows: [
            { labelKey: "settingsLauncherPlacement", kw: "ubicacion posicion centro barra center bar" },
            { labelKey: "settingsLauncherBar", kw: "barra bar pegado conectado" },
            { labelKey: "settingsLauncherCenter", kw: "centro centrado center" },
            { labelKey: "settingsLauncherLayout", hintKey: "settingsLauncherLayoutHint", kw: "diseno layout split frosted cristal detalle detail" },
            { labelKey: "settingsLauncherRecents", hintKey: "settingsLauncherRecentsHint", kw: "recientes favoritos recents favorites" },
            { labelKey: "settingsLauncherCapsule", hintKey: "settingsLauncherCapsuleHint", kw: "capsula capsule imagen marco frame tarjeta split" },
            { labelKey: "settingsLauncherFloating", hintKey: "settingsLauncherFloatingHint", kw: "flotante floating separado gap launcher" },
            { labelKey: "settingsLauncherDoubleClick", hintKey: "settingsLauncherDoubleClickHint", kw: "doble clic click mouse raton double" },
            { labelKey: "settingsLauncherImage", kw: "imagen image quitar" },
            { labelKey: "settingsLauncherSize", kw: "tamano size" }
          ] },
        { titleKey: "settingsLauncherPrefixes", hintKey: "settingsLauncherPrefixesHint",
          kw: "prefijos prefixes comandos commands paleta palette tmux busqueda search",
          rows: [
            { labelKey: "settingsLauncherPrefixes", hintKey: "settingsLauncherPrefixesHint", kw: "prefijos prefixes comandos commands paleta palette tmux" }
          ] },
        { titleKey: "settingsEffectsSection", hintKey: "settingsEffectsHint",
          kw: "efectos effects cpu gpu rendimiento performance",
          rows: [
            { labelKey: "settingsEffectsLabel", hintKey: "settingsEffectsHint", kw: "efectos effects" },
            { labelKey: "settingsLauncherParticles", hintKey: "settingsLauncherParticlesHint", kw: "particulas brillos particles glow" },
            { labelKey: "settingsLauncherParticleStyle", kw: "estilo particulas estrellas nieve luciernagas polvo stars snow fireflies dust" },
            { labelKey: "settingsLauncherParticleDensity", kw: "densidad particulas density cantidad" },
            { labelKey: "settingsLauncherGlow", hintKey: "settingsLauncherGlowHint", kw: "brillo seleccion glow pulso" },
            { labelKey: "settingsLauncherImageGlow", hintKey: "settingsLauncherImageGlowHint", kw: "brillo imagen resplandor orbe glow orb wallpaper" },
            { labelKey: "settingsLauncherEnter", hintKey: "settingsLauncherEnterHint", kw: "animacion entrada enter animation fade zoom slide" },
            { labelKey: "settingsLauncherWallpaperLive", hintKey: "settingsLauncherWallpaperLiveHint", kw: "fondo animado wallpaper video mpvpaper walls live" }
          ] }
      ] },

    { id: "quickbar", group: "desktop",    icon: "󰍉", titleKey: "advCatQuickBar",  page: "pages/QuickBarPage.qml",
      sections: [
        { titleKey: "qbLookTitle", hintKey: "qbLookHint",
          kw: "quicksearch quick search barra rapida quick bar spotlight posicion arriba abajo centro ancho tamano position width top bottom center compacto",
          rows: [
            { labelKey: "qbPosition", kw: "posicion arriba abajo centro top bottom center" },
            { labelKey: "qbWidth", kw: "ancho tamano compacto amplio width compact wide" }
          ] },
        { titleKey: "qbBrowserTitle", hintKey: "qbBrowserHint",
          kw: "navegador browser firefox chromium chrome brave librewolf zen vivaldi edge xdg-open",
          rows: [
            { labelKey: "qbBrowserPref", kw: "navegador preferido instalado firefox chromium brave default predeterminado" },
            { labelKey: "qbPrivate", hintKey: "qbPrivateHint", kw: "privada incognito privado private window ventana" }
          ] },
        { titleKey: "qbSearchTitle", hintKey: "qbSearchHint",
          kw: "busqueda web buscador google duckduckgo brave bing startpage ecosia search engine url",
          rows: [
            { labelKey: "qbEngine", kw: "buscador google duckduckgo bing ecosia startpage motor engine" },
            { labelKey: "qbCustomUrl", hintKey: "qbCustomUrlHint", kw: "personalizado custom url plantilla template" },
            { labelKey: "qbBangs", hintKey: "qbBangsHint", kw: "atajos sitio bang yt youtube gh github wiki wikipedia prefijo shortcuts" }
          ] },
        { titleKey: "qbFilesTitle", hintKey: "qbFilesHint",
          kw: "archivos carpetas buscar files search nvim neovim terminal editor fd find",
          rows: [
            { labelKey: "qbFilesEnable", kw: "archivos activar desactivar encender apagar on off files" },
            { labelKey: "qbFilesOpener", hintKey: "qbFilesOpenerHint", kw: "abrir con nvim neovim terminal editor xdg-open app" },
            { labelKey: "qbFilesEditor", hintKey: "qbFilesEditorHint", kw: "editor comando nvim vim helix neovim" },
            { labelKey: "qbFilesSmart", hintKey: "qbFilesSmartHint", kw: "imagenes pdf video audio no editables binarios" },
            { labelKey: "qbFilesRoots", hintKey: "qbFilesRootsHint", kw: "carpetas rutas home donde buscar folders paths" },
            { labelKey: "qbFilesDepth", hintKey: "qbFilesDepthHint", kw: "profundidad niveles subcarpetas depth" },
            { labelKey: "qbFilesMax", kw: "resultados cantidad maximo results" },
            { labelKey: "qbFilesHidden", kw: "ocultos hidden dotfiles" }
          ] }
      ] },

    { id: "powermenu", group: "desktop",   icon: "󰐥", titleKey: "advCatPowerMenu",   page: "pages/PowerMenuPage.qml",
      sections: [
        { titleKey: "pmBackendTitle", hintKey: "pmBackendHint",
          kw: "powermenu energia apagar reiniciar suspender backend rofi quickshell sesion power",
          rows: [
            { labelKey: "pmQuickshell", kw: "quickshell ooze propio" },
            { labelKey: "pmRofi", kw: "rofi script" }
          ] }
      ] },

    { id: "oozelock", group: "desktop", icon: String.fromCodePoint(0xF033E), titleKey: "advCatOozeLock", page: "pages/OozeLockPage.qml",
      sections: [
        { titleKey: "olBackgroundTitle", hintKey: "olBackgroundHint",
          kw: "bloqueo lock lockscreen pantalla fondo wallpaper imagen blur desenfoque oscurecer brillo oozelock",
          rows: [
            { labelKey: "lockModeAuto", kw: "automatico auto wallpaper actual fondo" },
            { labelKey: "lockModeCustom", kw: "imagen personalizada custom ruta path" },
            { labelKey: "olBlur", hintKey: "olBlurHint", kw: "blur desenfoque difuminado fondo" },
            { labelKey: "olDim", hintKey: "olDimHint", kw: "oscurecer oscuro brillo dim darken fondo" }
          ] },
        { titleKey: "olLayoutTitle", hintKey: "olLayoutHint",
          kw: "bloqueo lock distribucion layout disposicion posicion reloj acceso login input campo contrasena izquierda derecha centro abajo oozelock",
          rows: [
            { labelKey: "olLayoutTitle", hintKey: "olLayoutHint", kw: "distribucion layout disposicion posicion reloj acceso login input campo contrasena sddm centrado columna esquina" },
            { labelKey: "olShowPower", hintKey: "olShowPowerHint", kw: "apagar reiniciar energia power shutdown reboot botones" }
          ] },
        { titleKey: "olInfoTitle", hintKey: "olInfoHint",
          kw: "bloqueo lock reloj hora 24 12 formato fecha avatar foto nombre teclado idioma bateria oozelock",
          rows: [
            { labelKey: "olClock24h", kw: "reloj hora 24 12 formato am pm" },
            { labelKey: "olClockStyle", kw: "reloj estilo clasico apilado minimalista tarjetas analogico clock style analog" },
            { labelKey: "olClockScale", kw: "reloj tamano escala size scale grande pequeno" },
            { labelKey: "olShowDate", kw: "fecha dia date" },
            { labelKey: "olShowAvatar", hintKey: "olShowAvatarHint", kw: "avatar foto perfil nombre bienvenida" },
            { labelKey: "olShowLayout", hintKey: "olShowLayoutHint", kw: "teclado idioma layout distribucion" },
            { labelKey: "olShowBattery", hintKey: "olShowBatteryHint", kw: "bateria battery porcentaje carga" }
          ] },
        { titleKey: "olWidgetsTitle", hintKey: "olWidgetsHint",
          kw: "bloqueo lock widgets addons complementos posicion arriba abajo clima musica oozelock",
          rows: [
            { labelKey: "olWidgetsStyle", hintKey: "olWidgetsStyleHint", kw: "dashboard panel vertical tarjetas cards diseno estilo widgets unificado" },
            { labelKey: "olDashScale", hintKey: "olDashScaleHint", kw: "dashboard tamano escala size scale panel grande pequeno" },
            { labelKey: "olSideWidth", hintKey: "olSideWidthHint", kw: "ancho panel lateral width izquierda derecha tamano" },
            { labelKey: "olPlacement", hintKey: "olPlacementHint", kw: "posicion arriba abajo izquierda derecha lateral vertical dashboard panel top bottom left right widgets" }
          ] },
        { titleKey: "olWeatherTitle", hintKey: "olWeatherHint",
          kw: "bloqueo lock clima weather temperatura pronostico ciudad celsius fahrenheit open-meteo oozelock",
          rows: [
            { labelKey: "olWeatherEnable", kw: "clima weather activar desactivar encender apagar" },
            { labelKey: "olWeatherCity", hintKey: "olWeatherCityHint", kw: "ciudad city lugar ubicacion coordenadas" },
            { labelKey: "olCardScale", hintKey: "olCardScaleHint", kw: "tamano escala size scale grande pequeno agrandar reducir clima weather" },
            { labelKey: "olWeatherStyle", hintKey: "olWeatherStyleHint", kw: "estilo forecast pronostico tarjeta card clasico widget diseno" },
            { labelKey: "olWeatherUnits", kw: "unidades celsius fahrenheit grados km mph" },
            { labelKey: "olWeatherForecast", hintKey: "olWeatherForecastHint", kw: "pronostico forecast proximos dias" },
            { labelKey: "olWeatherDays", hintKey: "olWeatherDaysHint", kw: "dias pronostico cantidad semana" },
            { labelKey: "olWeatherTint", hintKey: "olWeatherTintHint", kw: "color tinte velo degradado clima" },
            { labelKey: "olWeatherRefresh", kw: "actualizar refrescar minutos intervalo" }
          ] },
        { titleKey: "olMediaTitle", hintKey: "olMediaHint",
          kw: "bloqueo lock musica reproductor mpris media player spotify controles portada oozelock",
          rows: [
            { labelKey: "olMediaEnable", kw: "musica mpris reproductor activar desactivar" },
            { labelKey: "olCardScale", hintKey: "olCardScaleHint", kw: "tamano escala size scale grande pequeno agrandar reducir musica reproductor player" },
            { labelKey: "olMediaStyle", hintKey: "olMediaStyleHint", kw: "estilo reproductor player clasico audio visualizer diseno" },
            { labelKey: "olMediaVisualizer", hintKey: "olMediaVisualizerHint", kw: "espectro visualizador barras cava audio ecualizador" },
            { labelKey: "olMediaCover", kw: "portada caratula cover album" },
            { labelKey: "olMediaOnlyPlaying", hintKey: "olMediaOnlyPlayingHint", kw: "solo reproduciendo pausado ocultar" }
          ] },
        { titleKey: "olNotifTitle", hintKey: "olNotifHint",
          kw: "bloqueo lock notificaciones avisos apps privacidad notifications oozelock",
          rows: [
            { labelKey: "olNotifMode", kw: "notificaciones avisos apps solo mostrar ocultar privacidad contenido" },
            { labelKey: "olCardScale", hintKey: "olCardScaleHint", kw: "tamano escala size scale grande pequeno agrandar reducir notificaciones avisos" },
            { labelKey: "olNotifMax", hintKey: "olNotifMaxHint", kw: "maximo cantidad limite notificaciones avisos" }
          ] },
        { titleKey: "olResetTitle",
          kw: "restaurar reset valores predeterminados bloqueo lock oozelock",
          rows: [
            { labelKey: "olResetLabel", hintKey: "olResetHint", kw: "restaurar reset predeterminado defecto" }
          ] }
      ] },

    { id: "agenda", group: "desktop",      icon: "󰃭", titleKey: "advCatAgenda",      page: "pages/AgendaPage.qml",
      sections: [
        { titleKey: "todoAlarmsTitle", hintKey: "todoAlarmsHint",
          kw: "alarma alarmas recordatorio recordatorios aviso notificacion hora reminder alarm todo agenda",
          rows: [
            { labelKey: "todoAlarmsEnable", kw: "alarma alarmas activar desactivar encender apagar on off" },
            { labelKey: "todoAlarmSound", hintKey: "todoAlarmSoundHint", kw: "sonido audio pitido campana beep sound pw-play paplay" },
            { labelKey: "todoAlarmPersistent", hintKey: "todoAlarmPersistentHint", kw: "notificacion persistente fija pantalla critica cerrar sticky" },
            { labelKey: "todoAlarmTest", kw: "probar prueba test alarma notificacion" }
          ] }
      ] },

    { id: "focus", group: "desktop", icon: "󰔟", titleKey: "advCatFocus", page: "pages/FocusPage.qml",
      sections: [
        { titleKey: "focusDurationsTitle", hintKey: "focusDurationsHint",
          kw: "focus pomodoro temporizador timer enfoque descanso corto largo minutos rondas dashboard concentracion",
          rows: [
            { labelKey: "wgOpt_focusMin", kw: "enfoque focus minutos duracion" },
            { labelKey: "wgOpt_shortMin", kw: "descanso corto short break minutos" },
            { labelKey: "wgOpt_longMin", kw: "descanso largo long break minutos" },
            { labelKey: "wgOpt_rounds", kw: "rondas enfoques ciclos rounds" }
          ] },
        { titleKey: "focusAlertsTitle",
          kw: "avisos notificacion sonido automatico siguiente fase reiniciar reset",
          rows: [
            { labelKey: "wgOpt_autoNext", kw: "automatico siguiente fase auto" },
            { labelKey: "wgOpt_notify", kw: "avisar notificacion" },
            { labelKey: "wgOpt_sound", kw: "sonido audio" },
            { labelKey: "focusRestart", kw: "reiniciar reset cero" }
          ] }
      ] },

    { id: "capture", group: "desktop", icon: "󰄀", titleKey: "advCatCapture", page: "pages/CapturePage.qml",
      sections: [
        { titleKey: "capFoldersTitle", hintKey: "capFoldersHint",
          kw: "carpeta carpetas folder directorio ruta path capturas screenshots grabaciones recordings videos guardar abrir",
          rows: [
            { labelKey: "capShotDir", kw: "carpeta capturas screenshots imagenes pictures ruta path" },
            { labelKey: "capRecDir", kw: "carpeta grabaciones recordings videos ruta path" },
            { labelKey: "capOpenShots", kw: "abrir open carpeta capturas" },
            { labelKey: "capOpenRecs", kw: "abrir open carpeta grabaciones" }
          ] },
        { titleKey: "capShotTitle",
          kw: "captura pantallazo screenshot imagen png jpeg jpg calidad nombre archivo cursor portapapeles clipboard grim",
          rows: [
            { labelKey: "capShotFormat", kw: "formato format png jpeg jpg imagen" },
            { labelKey: "capShotQuality", kw: "calidad quality jpeg compresion" },
            { labelKey: "capShotPattern", hintKey: "capPatternHint", kw: "nombre archivo plantilla patron name pattern fecha date strftime" },
            { labelKey: "capShotCursor", kw: "cursor puntero raton mouse pointer" },
            { labelKey: "capShotClipboard", hintKey: "capShotClipboardHint", kw: "portapapeles clipboard copiar copy wl-copy" }
          ] },
        { titleKey: "capRecTitle",
          kw: "grabar grabacion pantalla screen recording screencast video mp4 mkv webm fps audio microfono vaapi gpu wf-recorder",
          rows: [
            { labelKey: "capRecFormat", hintKey: "capRecFormatHint", kw: "formato format mp4 mkv webm video codec h264 vp8" },
            { labelKey: "capRecFps", kw: "fps cuadros fotogramas framerate 24 30 60" },
            { labelKey: "capRecQuality", kw: "calidad quality baja media alta bitrate crf" },
            { labelKey: "capRecAudio", kw: "audio sonido sistema microfono mic sound system" },
            { labelKey: "capRecHw", hintKey: "capRecHwHint", kw: "hardware aceleracion vaapi nvenc nvidia gpu codificacion encoder codificador cpu x264" },
            { labelKey: "capRecDelay", hintKey: "capRecDelayHint", kw: "cuenta atras retraso delay countdown segundos timer" },
            { labelKey: "capRecPattern", hintKey: "capPatternHint", kw: "nombre archivo video plantilla patron name pattern fecha" }
          ] },
        { titleKey: "capGeneralTitle",
          kw: "avisos notificacion notificar notify aviso terminar guardado",
          rows: [
            { labelKey: "capNotify", hintKey: "capNotifyHint", kw: "notificar avisar notification guardado terminar" }
          ] },
        { titleKey: "capToolsTitle", hintKey: "capToolsHint",
          kw: "herramientas instalar dependencias requisitos grim wl-copy wf-recorder ffmpeg pactl notify-send tools install",
          rows: [] }
      ] },

    { id: "globalmanager", group: "system", icon: "󰖯", titleKey: "advCatGlobalManager", page: "pages/GlobalManagerPage.qml",
      sections: [
        { titleKey: "gmWmTitle", hintKey: "gmWmHint",
          kw: "window manager wm compositor hyprland mango mangowm niri sesion",
          rows: [] },
        { titleKey: "gmDistroTitle", hintKey: "gmDistroHint",
          kw: "distro distribucion arch nixos paquetes package search buscador nix-search",
          rows: [
            { labelKey: "gmPkgHelperTitle", kw: "paru yay pacman aur gestor paquetes helper" }
          ] },
        { titleKey: "gmCapsTitle", hintKey: "gmCapsHint",
          kw: "compatibilidad capacidades soporte blur sombras animaciones layouts monitor",
          rows: [] }
      ] },

    { id: "hypr", group: "system",       icon: "󰹑", titleKey: "advCatHyprMonitor", page: "", requires: "monitorEditor" },

    { id: "audio", group: "system",      icon: "󰕾", titleKey: "advCatAudio",       page: "pages/AudioPage.qml" },

    { id: "keybinds", group: "system",   icon: "󰌌", titleKey: "advCatKeybinds",  page: "pages/KeybindsPage.qml",
      sections: [
        { titleKey: "kbListTitle", hintKey: "kbListHint",
          kw: "keybinds binds atajos teclado shortcuts combinacion combo editar borrar restaurar hyprland",
          rows: [
            { labelKey: "kbEdit", kw: "editar cambiar combo edit change" },
            { labelKey: "kbDelete", kw: "borrar desactivar eliminar quitar delete remove disable" },
            { labelKey: "kbRestore", kw: "restaurar recuperar restore" }
          ] },
        { titleKey: "kbNewTitle", hintKey: "kbNewHint",
          kw: "nuevo agregar crear bind custom personalizado add new create comando exec",
          rows: [
            { labelKey: "kbAdd", kw: "agregar anadir nuevo crear add" }
          ] }
      ] },

    { id: "defaultapps", group: "system", icon: "󰓎", titleKey: "advCatDefaultApps", page: "pages/DefaultAppsPage.qml",
      sections: [
        { titleKey: "daAppsTitle", hintKey: "daAppsHint",
          kw: "apps predeterminadas default aplicaciones navegador terminal archivos editor musica video imagenes sistema xdg-open",
          rows: [
            { labelKey: "daRoleBrowser",  kw: "navegador browser firefox chromium brave zen web" },
            { labelKey: "daRoleTerminal", kw: "terminal foot kitty alacritty wezterm ghostty konsole" },
            { labelKey: "daRoleFiles",    kw: "archivos gestor files file manager thunar nautilus dolphin yazi ranger carpetas" },
            { labelKey: "daRoleEditor",   kw: "editor texto nvim neovim vim helix code zed kate nano" },
            { labelKey: "daRoleMusic",    kw: "musica music audio spotify rhythmbox cmus" },
            { labelKey: "daRoleVideo",    kw: "video mpv vlc reproductor player" },
            { labelKey: "daCustomLabel",  hintKey: "daCustomHint", kw: "comando personalizado custom command flatpak" }
          ] },
        { titleKey: "daIpcTitle", hintKey: "daIpcHint",
          kw: "ipc atajos bind keybind mango mangowm niri spawn quickshell qs apps abrir comando teclado",
          rows: [
            { labelKey: "daIpcCommand", kw: "comando shell qs quickshell ipc call apps open" },
            { labelKey: "daIpcMango",   kw: "mango mangowm bind spawn config" },
            { labelKey: "daIpcNiri",    kw: "niri bind spawn spawn-sh kdl config" },
            { labelKey: "daIpcFull",    kw: "comando completo qs quickshell ipc -p ruta" },
            { labelKey: "daIpcInstall", kw: "instalar oozeshell comando path enlace symlink ln local bin" }
          ] }
      ] },

    { id: "services", group: "system",   icon: "󰆍", titleKey: "advCatServices",    page: "pages/ServicesPage.qml",
      sections: [
        { titleKey: "advTachideskTitle", hintKey: "advTachideskHint",
          kw: "manga servidor server systemd servicio service",
          rows: [
            { labelKey: "advTachideskStart",       kw: "iniciar start encender tachidesk" },
            { labelKey: "advTachideskStop",        kw: "detener stop apagar tachidesk" },
            { labelKey: "advTachideskRestart",     kw: "reiniciar restart tachidesk" },
            { labelKey: "advTachideskOutputTitle", kw: "salida output estado status log" }
          ] }
      ] },

    { id: "agents", group: "system", icon: "󰚩", titleKey: "advCatAgents", page: "pages/AgentsPage.qml", hidden: true,
      sections: [
        { titleKey: "agentsActiveTitle", hintKey: "agentsActiveHint",
          kw: "agente ia ai asistente chat modelo claude openai gemini ollama globo",
          rows: [
            { labelKey: "agentsPick",   kw: "agente elegir claude openai gemini openrouter ollama codex cli" },
            { labelKey: "agentsModel",  kw: "modelo model nombre" },
            { labelKey: "agentsSystem", kw: "instruccion sistema prompt idioma" }
          ] },
        { titleKey: "agentsAccountsTitle", hintKey: "agentsAccountsHint",
          kw: "api key clave token cuenta login sesion cifrado llavero secret",
          rows: [
            { labelKey: "agentsKeyField", kw: "api key clave pegar guardar" }
          ] },
        { titleKey: "agentsCliTitle", hintKey: "agentsCliHint",
          kw: "cli claude code gemini codex ollama iniciar sesion login terminal local",
          rows: [] },
        { titleKey: "agentsIpcTitle", hintKey: "agentsIpcHint",
          kw: "ipc comando atajo keybind qs quickshell globo abrir toggle ask",
          rows: [] }
      ] },

    { id: "about", group: "about",      icon: "󰋽", titleKey: "advCatAbout",       page: "pages/AboutPage.qml",
      sections: [
        { titleKey: "advAboutSysInfoTitle", kw: "sistema system info hostname kernel uname cpu ram quickshell qt version",
          rows: [
            { labelKey: "advAboutCopy", kw: "copiar copy portapapeles clipboard reporte bug info sistema" }
          ] },
        { titleKey: "advAboutPathsTitle", kw: "carpeta carpetas ruta paths config cache shell directorio abrir folder" },
        { titleKey: "advAboutRepoTitle", kw: "github git repositorio repos dotfiles codigo",
          rows: [
            { labelKey: "advAboutRepoDotfilesTitle", kw: "dotfiles hyprland github git" },
            { labelKey: "advAboutRepoNixTitle",      kw: "nixos nix home configuracion github git" }
          ] }
      ] }
  ]


  readonly property var groupOrder: ["personal", "look", "desktop", "system", "about"]
  function groupLabel(id) {
    const k = { personal: "setGroupUser", look: "setGroupLook", desktop: "setGroupDesktop", system: "setGroupSystem" }[id]
    return k ? Translations.t(k) : ""
  }

  readonly property var categories: root.allCategories.filter(c => (!c.requires || WM.has(c.requires)) && (!c.hidden || AgentsService.unlocked))

  // ── Consultas ────────────────────────────────────────────────────────
  function byId(id) {
    for (const c of root.categories) if (c.id === id) return c
    return null
  }
  function iconOf(id)     { const c = root.byId(id); return c ? c.icon : "" }
  function titleKeyOf(id) { const c = root.byId(id); return c ? c.titleKey : "" }
  function pageOf(id)     { const c = root.byId(id); return (c && c.page) ? c.page : "" }


  readonly property var searchEntries: {
    const out = []
    for (const c of root.categories) {
      for (const s of (c.sections ?? [])) {
        out.push({ cat: c.id, key: s.titleKey, text: "", hint: s.hintKey ?? "",
                   kw: s.kw ?? "", sec: "", anchor: s.anchor ?? "" })
        for (const r of (s.rows ?? []))
          out.push({ cat: c.id, key: r.labelKey, text: "", hint: r.hintKey ?? "",
                     kw: r.kw ?? "", sec: s.titleKey, anchor: r.anchor ?? "" })
      }
    }
    return out
  }
}
