// MprisPage

import QtQuick
import QtQuick.Layouts
import ".."
import "../../COMMON"
import "../../Services/Lang"

SettingsPage {
  id: page
  catId: "mpris"

  function styles(list) {
    return list.map(v => ({ value: v, label: Translations.t("mprisSty_" + v) }))
  }

  // ─── Barra ───
  SettingsSection {
    titleKey: "mprisBarTitle"
    hintKey: "mprisBarHint"

    SettingsRow {
      titleKey: "mprisStyleBarH"
      SettingsChoice {
        model: page.styles(Theme.mprisBarStyles)
        current: Theme.mprisBarStyle
        onPicked: v => Theme.setMprisStyle("bar", v)
      }
    }

    SettingsRow {
      titleKey: "mprisStyleBarV"
      SettingsChoice {
        model: page.styles(Theme.mprisBarVStyles)
        current: Theme.mprisBarVStyle
        onPicked: v => Theme.setMprisStyle("barV", v)
      }
    }

    SettingsNote {
      kind: "accent"
      text: Translations.t(Theme.barVertical ? "mprisBarNowV" : "mprisBarNowH")
    }
  }

  // ─── Dashboard ───
  SettingsSection {
    titleKey: "mprisDashTitle"

    SettingsRow {
      titleKey: "mprisStyleDash"
      SettingsChoice {
        model: page.styles(Theme.mprisDashStyles)
        current: Theme.mprisDashStyle
        onPicked: v => Theme.setMprisStyle("dash", v)
      }
    }
  }

  // ─── Popup de la barra ───
  SettingsSection {
    titleKey: "mprisPopupTitle"
    hintKey: "mprisPopupHint"

    SettingsRow {
      titleKey: "mprisStylePopup"
      SettingsChoice {
        model: page.styles(Theme.mprisPopupStyles)
        current: Theme.mprisPopupStyle
        onPicked: v => Theme.setMprisStyle("popup", v)
      }
    }
  }
}
