// TerminalPage — categoría "Terminal": dotfiles, opacidad de terminales y starship.

import QtQuick
import QtQuick.Layouts
import ".."
import "../../COMMON"
import "../../Services/Lang"
import "../../Services/Terminal"

SettingsPage {
  id: page
  catId: "terminal"

  readonly property var foundTerminals: TerminalConfig.terminals.filter(t => t.found)
  readonly property var sv: TerminalConfig.starship.values ?? ({})
  readonly property bool starshipReady: TerminalConfig.starship.found === true

  Component.onCompleted: TerminalConfig.refresh()

  // ─── FUNCIONES ───
  function errorMessage(code) {
    if (code === "tool") return Translations.t("termErrTool")
    if (code.indexOf("io:") === 0) return Translations.t("termErrIo")
    if (code === "unsupported") return Translations.t("termErrUnsupported")
    return Translations.t("termErrGeneric") + " (" + code + ")"
  }

  function itemHint(info) {
    if (!info.exists) return Translations.t("termItemMissing")
    const base = info.linked ? "→ " + TerminalConfig.shortPath(info.real) : Translations.t("termItemLocal")
    return info.writable ? base : base + " · " + Translations.t("termItemReadOnly")
  }

  function terminalHint(info) {
    const base = TerminalConfig.shortPath(info.path)
    const parts = [base]
    if (!info.installed) parts.push(Translations.t("termNotInstalled"))
    if (!info.writable) parts.push(Translations.t("termItemReadOnly"))
    return parts.join(" · ")
  }

  // ─── COMPONENTES ───
  component DotItem: SettingsRow {
    id: di
    required property var info
    title: TerminalConfig.shortPath(di.info.path)
    hint: page.itemHint(di.info)

    SettingsBtn {
      visible: di.info.exists
      icon: "󰏫"
      text: Translations.t("termEdit")
      onClicked: TerminalConfig.openInEditor(di.info.path)
    }
  }

  // ─── AVISO DE ERROR ───
  SettingsNote {
    visible: TerminalConfig.lastError !== ""
    kind: "error"
    text: page.errorMessage(TerminalConfig.lastError)
  }

  // ─── DOTFILES ───
  SettingsSection {
    titleKey: "termDotfilesTitle"
    hintKey: "termDotfilesHint"

    SettingsRow {
      titleKey: "termDotfilesFolder"
      hint: TerminalConfig.dotfilesRoot !== ""
        ? TerminalConfig.shortPath(TerminalConfig.dotfilesRoot)
        : Translations.t("termDotfilesNone")

      SettingsIconBtn {
        spinning: TerminalConfig.busy
        onClicked: TerminalConfig.refresh()
      }
      SettingsBtn {
        visible: TerminalConfig.dotfilesRoot !== ""
        icon: "󰉋"
        text: Translations.t("termOpenFolder")
        onClicked: TerminalConfig.openFolder(TerminalConfig.dotfilesRoot)
      }
    }

    Repeater {
      model: TerminalConfig.items
      delegate: DotItem {
        required property var modelData
        info: modelData
      }
    }
  }

  // ─── OPACIDAD ───
  SettingsSection {
    titleKey: "termOpacityTitle"
    hintKey: "termOpacityHint"

    SettingsNote {
      visible: TerminalConfig.loaded && page.foundTerminals.length === 0
      text: Translations.t("termOpacityNone")
    }

    Repeater {
      model: page.foundTerminals
      delegate: SettingsRow {
        required property var modelData
        title: modelData.name
        hint: page.terminalHint(modelData)
        enabled: modelData.writable

        ScaleSlider {
          Layout.fillWidth: false
          Layout.preferredWidth: 240
          value: TerminalConfig.opacityOf(modelData.id)
          min: 10
          max: 100
          step: 5
          defaultValue: 100
          onEdited: v => TerminalConfig.setOpacity(modelData.id, v)
        }
      }
    }
  }

  // ─── STARSHIP ───
  SettingsSection {
    titleKey: "termStarshipTitle"
    hintKey: "termStarshipHint"

    SettingsNote {
      visible: TerminalConfig.loaded && !page.starshipReady
      kind: "warn"
      text: Translations.t("termStarshipMissing")
    }

    SettingsRow {
      titleKey: "termStarshipNewline"
      enabled: page.starshipReady

      SettingsSwitch {
        checked: page.sv.newline ?? true
        onToggled: TerminalConfig.setStarship("newline", !(page.sv.newline ?? true))
      }
    }

    SettingsRow {
      titleKey: "termStarshipTime"
      enabled: page.starshipReady

      SettingsSwitch {
        checked: page.sv.time ?? false
        onToggled: TerminalConfig.setStarship("time", !(page.sv.time ?? false))
      }
    }

    SettingsRow {
      titleKey: "termStarshipTimeFormat"
      enabled: page.starshipReady && (page.sv.time ?? false)

      SettingsChoice {
        model: [
          { value: "%H:%M", label: Translations.t("termTime24") },
          { value: "%I:%M %p", label: Translations.t("termTime12") }
        ]
        current: page.sv.timeFormat ?? "%H:%M"
        onPicked: v => TerminalConfig.setStarship("timeFormat", v)
      }
    }

    SettingsRow {
      titleKey: "termStarshipDuration"
      enabled: page.starshipReady

      SettingsSwitch {
        checked: page.sv.duration ?? true
        onToggled: TerminalConfig.setStarship("duration", !(page.sv.duration ?? true))
      }
    }

    SettingsRow {
      titleKey: "termStarshipDurationMin"
      enabled: page.starshipReady && (page.sv.duration ?? true)

      NumberStepper {
        Layout.fillWidth: false
        Layout.preferredWidth: 150
        value: Math.round((page.sv.durationMin ?? 2000) / 1000)
        min: 0
        max: 60
        step: 1
        suffix: " s"
        onEdited: v => TerminalConfig.setStarship("durationMin", v * 1000)
      }
    }

    SettingsRow {
      titleKey: "termStarshipDirDepth"
      enabled: page.starshipReady

      NumberStepper {
        Layout.fillWidth: false
        Layout.preferredWidth: 150
        value: page.sv.dirDepth ?? 3
        min: 1
        max: 10
        step: 1
        onEdited: v => TerminalConfig.setStarship("dirDepth", v)
      }
    }

    SettingsRow {
      stacked: true
      divider: false

      Flow {
        Layout.fillWidth: true
        spacing: 8

        SettingsBtn {
          icon: "󰏫"
          text: Translations.t("termStarshipEditFile")
          enabled: page.starshipReady
          onClicked: TerminalConfig.openInEditor(TerminalConfig.starship.path)
        }
        SettingsBtn {
          icon: "󰏫"
          text: Translations.t("termStarshipEditTemplate")
          enabled: TerminalConfig.starship.templateFound === true
          onClicked: TerminalConfig.openInEditor(TerminalConfig.starship.templatePath)
        }
      }
    }
  }
}
