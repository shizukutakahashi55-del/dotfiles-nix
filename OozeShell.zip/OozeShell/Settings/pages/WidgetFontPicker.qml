// WidgetFontPicker — selector de fuente compacto para las opciones de un widget (cabecera + lista con buscador).

import QtQuick
import QtQuick.Layouts
import "../../COMMON"
import "../../Services/Lang"
import ".."

ColumnLayout {
  id: root
  spacing: 8

  property string value: ""
  property bool open: false
  property string query: ""
  property var suggested: ["Playfair Display", "Cormorant Garamond", "Libre Baskerville", "Noto Serif", "DejaVu Serif"]

  signal picked(string name)

  readonly property string currentFont: Theme.resolveFont(root.value)
  readonly property string currentLabel: root.currentFont !== "" ? root.currentFont : Translations.t("wgFontAuto")

  readonly property var entries: {
    const out = []
    const q = Theme.normFont(root.query)
    const match = name => q === "" || Theme.normFont(name).indexOf(q) >= 0
    const used = ({})
    if (q === "") out.push({ id: "", label: Translations.t("wgFontAuto"), family: "", special: true, hint: false })
    for (let i = 0; i < root.suggested.length; i++) {
      const r = Theme.resolveFont(root.suggested[i])
      if (r === "" || used[r] || !match(r)) continue
      used[r] = true
      out.push({ id: r, label: r, family: r, special: false, hint: true })
    }
    const all = Theme.fontChoices
    for (let i = 0; i < all.length; i++) {
      const f = all[i]
      if (used[f] || !match(f)) continue
      out.push({ id: f, label: f, family: f, special: false, hint: false })
    }
    return out
  }

  RowLayout {
    Layout.fillWidth: true
    spacing: 8
    Text {
      Layout.fillWidth: true
      text: root.currentLabel
      elide: Text.ElideRight
      color: Theme.text
      font.pixelSize: Theme.sfs(14)
      font.family: root.currentFont !== "" ? root.currentFont : Theme.fontFamily
    }
    SettingsBtn {
      icon: "󰛖"
      text: root.open ? Translations.t("wgFontDone") : Translations.t("wgFontChange")
      primary: root.open
      onClicked: root.open = !root.open
    }
  }

  SkinRect {
    visible: root.open
    Layout.fillWidth: true
    Layout.preferredHeight: 34
    radius: 12
    color: Theme.surface
    border.width: Theme.bw1
    border.color: search.activeFocus ? Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.6) : Theme.divider

    TextInput {
      id: search
      anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
      verticalAlignment: TextInput.AlignVCenter
      color: Theme.text
      selectionColor: Theme.primary
      selectedTextColor: Theme.textOnPrimary
      font.pixelSize: Theme.sfs(12)
      font.family: Theme.fontFamily
      clip: true
      selectByMouse: true
      inputMethodHints: Qt.ImhNoPredictiveText
      onTextChanged: root.query = text

      Text {
        visible: search.text === "" && !search.activeFocus
        text: Translations.t("fontSearch")
        color: Theme.subtext
        font.pixelSize: Theme.sfs(12)
        font.family: Theme.fontFamily
      }
    }
  }

  SkinRect {
    visible: root.open
    Layout.fillWidth: true
    Layout.preferredHeight: 232
    radius: Theme.cardRadius
    color: Theme.surface
    border.width: Theme.bw1
    border.color: Theme.edge
    clip: true

    ListView {
      id: list
      anchors.fill: parent
      anchors.margins: 6
      model: root.entries
      clip: true
      spacing: 2
      boundsBehavior: Flickable.StopAtBounds
      reuseItems: true
      cacheBuffer: 400

      delegate: Rectangle {
        id: row
        required property var modelData
        readonly property bool active: row.modelData.id === root.currentFont
        width: list.width
        height: 34
        radius: Theme.cozy ? 3 : 9
        color: row.active ? Theme.primary : (area.containsMouse ? Theme.surfaceHigh : "transparent")

        RowLayout {
          anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
          spacing: 8
          Text {
            Layout.fillWidth: true
            text: row.modelData.label
            elide: Text.ElideRight
            color: row.active ? Theme.textOnPrimary : Theme.text
            font.bold: row.active || row.modelData.special
            font.pixelSize: Theme.sfs(13)
            font.family: row.modelData.special ? Theme.fontFamily : row.modelData.family
          }
          Text {
            visible: row.modelData.hint
            text: Translations.t("fontSuggested")
            color: row.active ? Theme.textOnPrimary : Theme.subtext
            opacity: 0.8
            font.pixelSize: Theme.sfs(9)
            font.family: Theme.fontFamily
          }
        }

        MouseArea {
          id: area
          anchors.fill: parent
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onClicked: root.picked(row.modelData.id)
        }
      }
    }
  }
}
