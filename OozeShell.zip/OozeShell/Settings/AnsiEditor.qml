import QtQuick
import QtQuick.Layouts
import "../COMMON"
import "../Services/Lang"
import "../Services/Terminal"
import "../Services/Terminal/Ansi.js" as Ansi

ColumnLayout {
  id: root

  property bool bgMode: false

  readonly property string current: edit.text
  readonly property bool dirty: FastfetchConfig.renderDirty

  Layout.fillWidth: true
  spacing: 10

  // ─── Utilidades ──────────────────────────────────────────────────

  function insertCode(code) {
    if (code === "") return
    edit.forceActiveFocus()
    edit.insert(edit.cursorPosition, code)
  }
  function sync() {
    if (edit.text === "" && FastfetchConfig.ansiText !== "") edit.text = FastfetchConfig.ansiText
  }
  function expand(path) {
    return path.trim().replace(/^~(?=\/|$)/, FastfetchConfig.home)
  }

  Component.onCompleted: {
    root.sync()
    FastfetchConfig.render(edit.text)
  }
  Timer {
    id: settle
    interval: 220
    onTriggered: FastfetchConfig.render(edit.text)
  }
  Connections {
    target: FastfetchConfig
    function onAnsiTextChanged() { root.sync() }
    function onImportSeqChanged() { edit.text = FastfetchConfig.imported }
  }

  // ─── Paleta ──────────────────────────────────────────────────────

  RowLayout {
    Layout.fillWidth: true
    spacing: 8

    SettingsChoice {
      model: [
        { value: false, label: Translations.t("termAnsiFg") },
        { value: true,  label: Translations.t("termAnsiBg") }
      ]
      current: root.bgMode
      onPicked: v => root.bgMode = v
    }
    SettingsBtn {
      text: Translations.t("termAnsiBold")
      onClicked: root.insertCode(Ansi.sgr("bold"))
    }
    SettingsBtn {
      text: Translations.t("termAnsiReset")
      onClicked: root.insertCode(Ansi.sgr("reset"))
    }
  }

  GridLayout {
    Layout.fillWidth: true
    columns: 8
    rowSpacing: 6
    columnSpacing: 6

    Repeater {
      model: 16

      delegate: SkinRect {
        id: cell
        required property int index

        Layout.preferredWidth: 26
        Layout.preferredHeight: 26
        radius: Theme.cozy ? 4 : 8
        color: Ansi.paletteColor(cell.index)
        border.width: 1
        border.color: Theme.edge
        scale: cellArea.containsMouse ? 1.12 : 1
        Behavior on scale { NumberAnimation { duration: Theme.animDuration(120); easing.type: Easing.OutBack } }

        MouseArea {
          id: cellArea
          anchors.fill: parent
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onClicked: root.insertCode(Ansi.sgr(root.bgMode ? "bg" : "fg", cell.index))
        }
      }
    }
  }

  RowLayout {
    Layout.fillWidth: true
    spacing: 8

    SettingsField {
      id: hexField
      mono: true
      placeholder: "#b083f0"
      Layout.preferredWidth: 140
    }
    SettingsBtn {
      text: Translations.t("termAnsiInsert")
      onClicked: root.insertCode(Ansi.hexSgr(hexField.input.text, root.bgMode))
    }
  }

  // ─── Editor ──────────────────────────────────────────────────────

  SkinRect {
    Layout.fillWidth: true
    Layout.preferredHeight: 160
    radius: Theme.cozy ? 4 : 12
    color: Theme.surfaceHigh
    border.width: edit.activeFocus ? 1 : 0
    border.color: Theme.primary
    clip: true

    Flickable {
      id: flick
      anchors.fill: parent
      anchors.margins: 8
      contentWidth: edit.width
      contentHeight: edit.height
      boundsBehavior: Flickable.StopAtBounds
      clip: true

      function ensureVisible(r) {
        if (flick.contentX >= r.x) flick.contentX = r.x
        else if (flick.contentX + flick.width <= r.x + r.width) flick.contentX = r.x + r.width - flick.width
        if (flick.contentY >= r.y) flick.contentY = r.y
        else if (flick.contentY + flick.height <= r.y + r.height) flick.contentY = r.y + r.height - flick.height
      }

      TextEdit {
        id: edit
        width: Math.max(flick.width, edit.paintedWidth + 8)
        height: Math.max(flick.height, edit.paintedHeight + 8)
        color: Theme.text
        selectionColor: Theme.primary
        selectedTextColor: Theme.textOnPrimary
        selectByMouse: true
        persistentSelection: true
        wrapMode: TextEdit.NoWrap
        textFormat: TextEdit.PlainText
        font.family: Theme.monoFamily
        font.pixelSize: Theme.sfs(12)
        onCursorRectangleChanged: flick.ensureVisible(edit.cursorRectangle)
        onTextChanged: settle.restart()

        Text {
          visible: edit.text === "" && !edit.activeFocus
          text: Translations.t("termAnsiEmpty")
          color: Theme.subtext
          font.family: Theme.fontFamily
          font.pixelSize: Theme.sfs(12)
        }
      }
    }
  }

  // ─── Vista previa ────────────────────────────────────────────────

  SkinRect {
    Layout.fillWidth: true
    Layout.preferredHeight: 150
    radius: Theme.cozy ? 4 : 12
    color: "#14141c"
    clip: true

    Flickable {
      anchors.fill: parent
      anchors.margins: 12
      contentWidth: ansiPreview.implicitWidth
      contentHeight: ansiPreview.implicitHeight
      boundsBehavior: Flickable.StopAtBounds
      clip: true

      AnsiView {
        id: ansiPreview
        html: FastfetchConfig.renderHtml
      }
    }
  }

  Text {
    Layout.fillWidth: true
    color: root.dirty ? Theme.primary : Theme.subtext
    font.pixelSize: Theme.sfs(10)
    font.family: Theme.fontFamily
    text: FastfetchConfig.renderLines + " " + Translations.t("termAnsiLines") + " × " + FastfetchConfig.renderCols + " " + Translations.t("termAnsiCols")
      + (root.dirty ? " · " + Translations.t("termAnsiUnsaved") : "")
  }

  // ─── Acciones ────────────────────────────────────────────────────

  RowLayout {
    Layout.fillWidth: true
    spacing: 8

    SettingsBtn {
      text: Translations.t("termAnsiSave")
      icon: "󰆓"
      primary: true
      enabled: root.dirty || settle.running || FastfetchConfig.source !== "ansi"
      onClicked: {
        settle.stop()
        FastfetchConfig.saveAnsi(edit.text)
      }
    }
    SettingsBtn {
      text: Translations.t("termAnsiSample")
      onClicked: edit.text = Ansi.sample()
    }
    SettingsBtn {
      text: Translations.t("termAnsiClear")
      onClicked: edit.text = ""
    }
    Item { Layout.fillWidth: true }
  }

  RowLayout {
    Layout.fillWidth: true
    spacing: 8

    SettingsField {
      id: importField
      mono: true
      placeholder: "~/logo.ans"
      Layout.fillWidth: true
      onSubmitted: text => FastfetchConfig.importAnsi(root.expand(text))
    }
    SettingsBtn {
      text: Translations.t("termAnsiImport")
      icon: "󰈔"
      onClicked: FastfetchConfig.importAnsi(root.expand(importField.input.text))
    }
  }
}
