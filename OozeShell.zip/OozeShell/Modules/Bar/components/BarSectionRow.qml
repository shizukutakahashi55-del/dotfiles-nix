// BarSectionRow — contenido de una isla de la barra, armado desde la distribución elegida en Ajustes → Barra → Módulos (Theme.barModulesOf).

import QtQuick
import QtQuick.Layouts

import "../../../COMMON"
import "../modules"

BarFlow {
  id: row

  property string side: "left"
  property var host: null

  readonly property var ids: Theme.barModulesOf(row.side)

  property int visibleCount: 0
  readonly property bool occupied: row.visibleCount > 0

  property var sepFlags: []
  property real othersHeight: 0

  readonly property bool pills: Theme.barPillBack
  readonly property real padPx: 6
  readonly property int leftCount: Theme.barModulesOf("left").length
  readonly property int centerCount: Theme.barModulesOf("center").length
  readonly property int rightCount: Theme.barModulesOf("right").length
  readonly property int totalCount: row.leftCount + row.centerCount + row.rightCount
  readonly property int baseIndex: row.side === "left" ? 0 : (row.side === "center" ? row.leftCount : row.leftCount + row.centerCount)

  gap: row.pills ? 2 * row.padPx + (Theme.barVertical ? 2 : 4) : 2

  readonly property var glue: ({})

  function refresh() {
    let seen = false
    let prevId = ""
    let count = 0
    let others = 0
    const flags = []
    for (let i = 0; i < rep.count; i++) {
      const s = rep.itemAt(i)
      const vis = !!s && s.slotVisible
      const glued = vis && seen && row.glue[s.moduleId] === prevId
      flags.push(vis && seen && !glued)
      if (!vis) continue
      seen = true
      prevId = s.moduleId
      count++
      if (s.moduleId !== "taskbar") others += s.implicitHeight + 10
    }
    row.sepFlags = flags
    row.visibleCount = count
    row.othersHeight = others
  }

  onIdsChanged: Qt.callLater(row.refresh)

  Component.onCompleted: { Qt.callLater(row.refresh); settle.restart() }
  Timer { id: settle; interval: 350; repeat: false; onTriggered: row.refresh() }

  Component { id: cPower; PowerModule { host: row.host } }
  Component { id: cLang; LangModule { host: row.host } }
  Component { id: cMpris; MprisModule { host: row.host } }
  Component { id: cNotifications; NotificationsModule { host: row.host } }
  Component { id: cWorkspaces; WorkspacesModule { host: row.host } }
  Component { id: cClock; ClockModule { host: row.host } }
  Component { id: cAudio; AudioModule { host: row.host } }
  Component { id: cBattery; BatteryModule { host: row.host } }
  Component { id: cPrivacy; PrivacyModule { host: row.host } }
  Component { id: cTaskbar; TaskbarModule { host: row.host } }
  Component { id: cTray; TrayModule { host: row.host } }
  Component { id: cMenu; MenuModule { host: row.host } }

  function componentFor(id) {
    switch (id) {
      case "power": return cPower
      case "lang": return cLang
      case "mpris": return cMpris
      case "notifications": return cNotifications
      case "workspaces": return cWorkspaces
      case "clock": return cClock
      case "audio": return cAudio
      case "battery": return cBattery
      case "privacy": return cPrivacy
      case "taskbar": return cTaskbar
      case "tray": return cTray
      case "menu": return cMenu
    }
    return null
  }

  Repeater {
    id: rep
    model: row.ids

    onItemAdded: Qt.callLater(row.refresh)
    onItemRemoved: Qt.callLater(row.refresh)

    delegate: BarFlow {
      id: slot

      readonly property string moduleId: modelData
      readonly property bool slotVisible: loader.item !== null && loader.item.shown === true

      gap: 2
      visible: slot.slotVisible

      onSlotVisibleChanged: Qt.callLater(row.refresh)
      onImplicitHeightChanged: Qt.callLater(row.refresh)

      Rectangle {
        visible: row.sepFlags[index] === true && !row.pills
        Layout.preferredWidth: Theme.barVertical ? 18 : 1
        Layout.preferredHeight: Theme.barVertical ? 1 : 15
        Layout.alignment: Qt.AlignCenter
        radius: 1
        color: Theme.primary
        opacity: 0.25
      }

      Binding {
        target: loader.item
        property: "hoverColor"
        value: Theme.barHover(row.side, row.baseIndex + index, row.totalCount)
        when: loader.item !== null
      }

      Loader {
        id: loader
        sourceComponent: row.componentFor(slot.moduleId)

        Rectangle {
          id: pillBg
          z: -1
          visible: row.pills && slot.slotVisible
          anchors.fill: parent
          anchors.leftMargin: Theme.barVertical ? (parent.width - Theme.barPillFace) / 2 : -row.padPx
          anchors.rightMargin: Theme.barVertical ? (parent.width - Theme.barPillFace) / 2 : -row.padPx
          anchors.topMargin: Theme.barVertical ? -row.padPx : (parent.height - Theme.barPillFace) / 2
          anchors.bottomMargin: Theme.barVertical ? -row.padPx : (parent.height - Theme.barPillFace) / 2
          radius: Math.min(width, height) / 2
          readonly property color base: Theme.pillColor(row.side, row.baseIndex + index, row.totalCount)
          border.width: 1
          border.color: Qt.rgba(1, 1, 1, 0.10)
          gradient: Gradient {
            orientation: Theme.barVertical ? Gradient.Horizontal : Gradient.Vertical
            GradientStop { position: 0; color: Qt.lighter(pillBg.base, 1.16) }
            GradientStop { position: 1; color: pillBg.base }
          }
        }

        Rectangle {
          z: -1
          visible: Theme.barMixed && Theme.barMixedStyle === "lines" && slot.slotVisible
          readonly property real thick: 3
          width: Theme.barVertical ? thick : parent.width * 0.6
          height: Theme.barVertical ? parent.height * 0.6 : thick
          x: Theme.barVertical ? (Theme.barAtRight ? (parent.width + Theme.barPillFace) / 2 + 1 : (parent.width - Theme.barPillFace) / 2 - thick - 1) : (parent.width - width) / 2
          y: Theme.barVertical ? (parent.height - height) / 2 : (parent.height + Theme.barPillFace) / 2 - thick + 1
          radius: thick / 2
          color: Theme.mixedAccent(((row.baseIndex + index) % 6) / 5)
        }
      }
    }
  }
}
