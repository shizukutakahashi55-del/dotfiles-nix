// WidgetText

import QtQuick

Text {
  readonly property int curveFrom: 24
  renderType: font.pixelSize >= curveFrom ? Text.CurveRendering : Text.QtRendering
}
