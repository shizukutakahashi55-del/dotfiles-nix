// AudioBgService

pragma Singleton
import Quickshell
import Quickshell.Io
import QtQuick
import "../../COMMON"

Singleton {
  id: root

  // ─── Datos ───
  property var values: []
  property var peaks: []
  property string status: "off"
  property string error: ""
  property int frames: 0

  readonly property bool live: root.status === "active" || root.status === "starting"
  readonly property bool running: backend.running

  // ─── Quién lo necesita ───
  property bool wanted: false

  function reset() {
    root.values = []
    root.peaks = []
    if (root.status !== "error") root.status = "off"
  }

  function ingest(line) {
    if (line.length < 2) return
    const c = line.charCodeAt(0)
    if (c === 68) {
      const cut = line.indexOf("|")
      const head = cut < 0 ? line.substring(2) : line.substring(2, cut)
      root.values = head === "" ? [] : head.split(" ").map(Number)
      if (cut >= 0) root.peaks = line.substring(cut + 1).split(" ").map(Number)
      else if (root.peaks.length > 0) root.peaks = []
      root.frames++
    } else if (c === 83) {
      const msg = line.substring(2)
      if (msg.startsWith("error")) {
        root.status = "error"
        root.error = msg.substring(6)
      } else {
        root.status = msg
        root.error = ""
      }
    }
  }

  // ─── Proceso ───
  Process {
    id: backend
    running: root.wanted && AudioBgConfig.loaded
    command: ["python3", Quickshell.shellDir + "/Backends/python/ooze-audiobg.py", "--config", AudioBgConfig.file]
    stdout: SplitParser { onRead: line => root.ingest(line) }
    stderr: SplitParser { onRead: line => console.log("[audiobg]", line) }
    onRunningChanged: {
      if (running) { root.status = "starting"; root.error = "" }
      else root.reset()
    }
    onExited: (code) => {
      if (code === 3) { root.status = "error"; root.error = "nocava" }
      else if (code === 2) { root.status = "error"; root.error = "python" }
    }
  }
}
