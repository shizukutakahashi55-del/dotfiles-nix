// AudioBgRadial

import QtQuick
import QtQuick.Shapes
import "../../COMMON"

Item {
  id: radial

  // ─── Entrada ───
  property bool active: true

  // ─── Derivados ───
  readonly property bool on: AudioBgConfig.style === "radial"
  readonly property var vals: (radial.active && radial.on) ? AudioBgService.values : []
  readonly property int n: radial.vals.length
  readonly property int count: radial.n * 2
  readonly property int groups: 16
  readonly property real outer: Math.min(radial.width, radial.height) / 2 * (0.25 + 0.75 * AudioBgConfig.thickness / 100)
  readonly property real inner: radial.outer * AudioBgConfig.inner / 100
  readonly property real arc: radial.count > 0 ? 2 * Math.PI * radial.inner / radial.count : 0
  readonly property real gapFrac: Math.min(0.85, AudioBgConfig.gap / Math.max(1, radial.arc))
  readonly property real half: radial.count > 0 ? Math.PI / radial.count * (1 - radial.gapFrac) : 0

  // ─── Geometría ───
  function val(i) {
    const x = radial.vals[i]
    return x === undefined ? 0 : x / 1000
  }

  function quads(g) {
    const total = radial.count
    const n = radial.n
    const out = []
    if (total === 0) return out
    const cx = radial.width / 2
    const cy = radial.height / 2
    const r0 = radial.inner
    const span = radial.outer - r0
    const h = radial.half
    for (let k = 0; k < total; k++) {
      const band = k < n ? k : total - 1 - k
      if (Math.floor(band * radial.groups / n) !== g) continue
      const l = radial.val(band)
      if (l < 0.004) continue
      const a = -Math.PI / 2 + (k + 0.5) * 2 * Math.PI / total
      const r1 = r0 + Math.max(2, l * span)
      const c0 = Math.cos(a - h), s0 = Math.sin(a - h)
      const c1 = Math.cos(a + h), s1 = Math.sin(a + h)
      out.push([
        Qt.point(cx + r0 * c0, cy + r0 * s0), Qt.point(cx + r0 * c1, cy + r0 * s1),
        Qt.point(cx + r1 * c1, cy + r1 * s1), Qt.point(cx + r1 * c0, cy + r1 * s0)
      ])
    }
    return out
  }

  // ─── Dibujo ───
  component Wedges: ShapePath {
    id: seg
    property var host: null
    property int g: 0
    strokeColor: "transparent"
    strokeWidth: 0
    fillColor: seg.host ? AudioBgConfig.colorAt((seg.g + 0.5) / seg.host.groups) : "transparent"
    PathMultiline { paths: seg.host ? seg.host.quads(seg.g) : [] }
  }

  Loader {
    anchors.fill: parent
    active: radial.on
    sourceComponent: Shape {
      preferredRendererType: Shape.CurveRenderer
      Wedges { host: radial; g: 0 }
      Wedges { host: radial; g: 1 }
      Wedges { host: radial; g: 2 }
      Wedges { host: radial; g: 3 }
      Wedges { host: radial; g: 4 }
      Wedges { host: radial; g: 5 }
      Wedges { host: radial; g: 6 }
      Wedges { host: radial; g: 7 }
      Wedges { host: radial; g: 8 }
      Wedges { host: radial; g: 9 }
      Wedges { host: radial; g: 10 }
      Wedges { host: radial; g: 11 }
      Wedges { host: radial; g: 12 }
      Wedges { host: radial; g: 13 }
      Wedges { host: radial; g: 14 }
      Wedges { host: radial; g: 15 }
    }
  }
}
