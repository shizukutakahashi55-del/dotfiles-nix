// AudioBgWindow

import Quickshell
import Quickshell.Wayland
import QtQuick
import "../../COMMON"

PanelWindow {
  id: win

  // ─── Resolución de modo ───
  readonly property string edgeEff: {
    if (AudioBgConfig.edge !== "auto") return AudioBgConfig.edge
    if (Theme.barVertical) return Theme.barAtRight ? "left" : "right"
    return Theme.barAtBottom ? "top" : "bottom"
  }
  readonly property bool behind: AudioBgConfig.fit === "behind" || (AudioBgConfig.fit === "auto" && Theme.glassMode)
  readonly property bool radial: AudioBgConfig.style === "radial"
  readonly property bool suppressed: FullscreenState.isOn(win.screen)
  readonly property bool shown: AudioBgService.live && !win.suppressed

  readonly property var sides: {
    if (win.radial) return ["center"]
    if (win.edgeEff === "both") return ["bottom", "top"]
    if (win.edgeEff === "sides") return ["left", "right"]
    return [win.edgeEff]
  }
  readonly property bool split: win.sides.length > 1

  // ─── Superficie ───
  color: "transparent"
  anchors { top: true; bottom: true; left: true; right: true }
  exclusionMode: ExclusionMode.Normal
  exclusiveZone: win.behind ? -1 : 0

  WlrLayershell.layer: AudioBgConfig.layer === "background" ? WlrLayer.Background : WlrLayer.Bottom
  WlrLayershell.namespace: "oozeshell-audiobg"
  WlrLayershell.keyboardFocus: WlrKeyboardFocus.None

  property Region noInput: Region {}
  mask: win.noInput

  // ─── Contenido ───
  Item {
    id: content
    anchors.fill: parent
    opacity: win.shown ? AudioBgConfig.opacity / 100 : 0
    visible: opacity > 0.01
    Behavior on opacity { NumberAnimation { duration: Theme.animDuration(win.shown ? 220 : 650); easing.type: Easing.OutCubic } }

    Repeater {
      model: win.sides

      delegate: Item {
        id: slot
        required property string modelData
        width: content.width
        height: content.height
        readonly property bool horiz: slot.modelData === "bottom" || slot.modelData === "top" || slot.modelData === "center"
        readonly property real across: slot.horiz ? content.height : content.width
        readonly property real along: slot.horiz ? content.width : content.height
        readonly property real pct: Math.min(AudioBgConfig.thickness, win.split ? 50 : 100) / 100
        readonly property real thick: Math.max(4, Math.round(slot.across * slot.pct))

        AudioBgRadial {
          anchors.fill: parent
          active: win.shown
        }

        AudioBgStage {
          id: stageItem
          width: slot.along
          height: slot.thick
          x: slot.modelData === "left" ? slot.thick
             : (slot.modelData === "right" ? content.width - slot.thick : 0)
          y: slot.modelData === "bottom" ? content.height - slot.thick
             : (slot.modelData === "center" ? Math.round((content.height - slot.thick) / 2)
             : (slot.modelData === "right" ? content.height : 0))
          rotation: slot.modelData === "top" ? 180
                    : (slot.modelData === "left" ? 90 : (slot.modelData === "right" ? -90 : 0))
          transformOrigin: (slot.modelData === "left" || slot.modelData === "right") ? Item.TopLeft : Item.Center
          reversed: slot.modelData === "top" || slot.modelData === "right"
          mirror: slot.modelData === "center"
          active: win.shown
        }
      }
    }
  }
}
