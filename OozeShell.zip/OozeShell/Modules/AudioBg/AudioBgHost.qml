// AudioBgHost

import Quickshell
import Quickshell.Io
import QtQuick
import "../../COMMON"

Scope {
  id: host

  // ─── IPC ───
  IpcHandler {
    target: "audiobg"

    function get(): string {
      return JSON.stringify(Object.assign({}, AudioBgConfig.values, { status: AudioBgService.status, error: AudioBgService.error }))
    }
    function styles(): string { return AudioBgConfig.styles.join(" | ") }
    function edges(): string { return AudioBgConfig.edges.join(" | ") }
    function enable(on: bool): bool { return AudioBgConfig.set("enabled", on) }
    function toggle(): bool { return AudioBgConfig.toggleEnabled() }
    function demo(on: bool): bool { return AudioBgConfig.set("demo", on) }
    function style(name: string): bool { return AudioBgConfig.set("style", name) }
    function edge(name: string): bool { return AudioBgConfig.set("edge", name) }
    function fit(name: string): bool { return AudioBgConfig.set("fit", name) }
    function layer(name: string): bool { return AudioBgConfig.set("layer", name) }
    function monitor(name: string): bool { return AudioBgConfig.set("monitor", name) }
    function option(key: string, value: string): bool { return AudioBgConfig.set(key, value) }
    function raise(): void { AudioBgConfig.raiseRequested() }
  }

  // ─── Pantallas ───
  readonly property var targets: {
    const all = Quickshell.screens
    const pick = all.filter(s => AudioBgConfig.monitor === "" || s.name === AudioBgConfig.monitor)
    return pick.length > 0 ? pick : all.slice(0, 1)
  }
  readonly property bool anyVisible: host.targets.some(s => !FullscreenState.isOn(s))

  Binding {
    target: AudioBgService
    property: "wanted"
    value: AudioBgConfig.enabled && host.anyVisible
  }

  // ─── Remapeo ───
  property bool mapped: true
  function raiseNow() { host.mapped = false; remap.restart() }
  Connections { target: AudioBgConfig; function onRaiseRequested() { host.raiseNow() } }
  Timer { id: remap; interval: 80; onTriggered: host.mapped = true }

  Variants {
    model: (AudioBgConfig.enabled && host.mapped) ? host.targets : []
    AudioBgWindow {
      required property var modelData
      screen: modelData
    }
  }
}
