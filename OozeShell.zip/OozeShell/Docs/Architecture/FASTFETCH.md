# FASTFETCH — categoría Fastfetch de Ajustes

- Qué es
  - Categoría **Ajustes avanzados → Fastfetch** (grupo Aspecto). Controla cómo se ve fastfetch al abrir una terminal: encendido, logo (imágenes, distro, ANSI propio o ninguno), tipo de entrada, márgenes, posición, estilo con vista previa y editor de logo ANSI.
  - OozeShell no ejecuta fastfetch: solo guarda ajustes en `~/.config/oozeshell/terminal.toml`. `random-fastfetch` (dotfiles) los lee y los traduce a flags. `~/.config/fastfetch/config.jsonc` no se modifica.
- Archivos
  - `Settings/pages/FastfetchPage.qml` → la página. Incluye `Cycler` (‹ valor ›) para tipo de entrada y estilo, e `ImageCell` (miniatura de imagen).
  - `Services/Terminal/FastfetchConfig.qml` → singleton de las opciones avanzadas, presets, vista previa y logo ANSI. Se activa con `ensure()` al abrir la página.
  - `Services/Terminal/TerminalConfig.qml` → compartido con Terminal: encendido, imagen aleatoria/fija y carpeta de imágenes.
  - `Backends/python/ooze-terminal.py` → backend de `FastfetchConfig` (`init`, `presets`, `save`, `preview`, `render`, `save-ansi`, `import`). `save` **mezcla** las claves recibidas con el archivo, no lo reemplaza.
  - `Settings/AnsiEditor.qml`, `Settings/AnsiView.qml`, `Services/Terminal/Ansi.js` → editor ANSI y su vista previa.
- Claves de `terminal.toml`

| clave | valores | quién la escribe |
|---|---|---|
| `fastfetch`, `fastfetchRandom`, `fastfetchImage` | bool, bool, nombre de archivo | `TerminalConfig` |
| `fastfetchSource` | `images` · `builtin` · `ansi` · `none` | `FastfetchConfig` |
| `fastfetchBuiltin` | nombre del logo de distro | `FastfetchConfig` |
| `fastfetchLogoType` | `detect`, `auto`, `sixel`, `kitty`, `kitty-direct`, `kitty-icat`, `iterm`, `chafa`, `raw` (imágenes) · `builtin`, `small` (distro) | `FastfetchConfig` |
| `fastfetchMargins` + `fastfetchPadTop/Bottom/Left/Right` | bool + enteros | `FastfetchConfig` |
| `fastfetchWidth` / `fastfetchHeight` | entero (0 = no pasar) | `FastfetchConfig` |
| `fastfetchPosition` | `config`, `auto`, `left`, `top`, `right` | `FastfetchConfig` |
| `fastfetchStyle` | `config` o preset (`neofetch`, `examples/10`…) | `FastfetchConfig` |

  - Logo ANSI: `~/.config/oozeshell/fastfetch-logo.ansi`; en el editor los escapes se ven como `\e[31m`.
- Diseño de la página
  - Solo filas estándar (`SettingsRow`, `SettingsChoice`, `NumberStepper`). Las listas largas (tipo y 37 presets) usan `Cycler` en vez de decenas de chips, así el costo no crece con las opciones.
  - Vista previa y editor ANSI se crean al pulsar «Mostrar» (`Loader`) y tienen alto fijo.
  - Los presets se piden 400 ms después de abrir y solo reemplazan el estado si cambiaron.
  - Guardado: 200 ms de espera, un solo proceso, solo las claves cambiadas.
- Dependencias
  - En ejecución: `python3`, `fastfetch` (presets y vista previa), `random-fastfetch`.
  - Añadir una opción = clave plana en `terminal.toml`, propiedad en `FastfetchConfig`, control en `FastfetchPage`, flag en el wrapper y fila en `SettingsRegistry`.
