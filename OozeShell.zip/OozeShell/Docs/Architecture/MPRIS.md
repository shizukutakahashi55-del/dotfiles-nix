# MPRIS — reproductor multimedia (backend D-Bus + popup + ondas)

- Qué es: popup de control multimedia y el único punto que lee/controla reproductores MPRIS. Ya no usa `playerctl`: lee directo del servicio MPRIS nativo de Quickshell por D-Bus y eventos.
- Archivos:
  - `Services/Mpris/MprisBackend.qml` → `pragma Singleton` (registrado en `qmldir`); expone `players`, `currentTitle/Artist/Art/Status/Position/Length`, `selectPlayer(i)`, `runCtl(args)` (`play-pause | next | previous | position <secs>`), `currentVolume`, `volumeMuted`, `volumeIcon`, `setVolume(v)`, `commitVolume()`, `toggleVolumeMute()` (volumen del sistema vía `AudioBackend`)
  - `Services/Mpris/Mpris.qml` → popup (`oozeshell-mpris`), delega todo al backend
  - `Services/Mpris/MprisWaves.qml` → visualización de ondas (puro `QtQuick.Shapes` + `COMMON`)
  - `Services/Mpris/MprisVolume.qml` → slider de volumen (horizontal en el popup, `vertical: true` en el dashboard)
  - `Services/Mpris/qmldir` → `singleton MprisBackend`, `Mpris`, `MprisWaves`, `MprisVolume`
- IPC (Core/Ipc/MprisIpc.qml, target `mpris`):

  | Función | Efecto |
  |---|---|
  | `toggle` | en modo píldora abre la sección `mpris` del dashboard; si no, popup propio |

  ```sh
  quickshell ipc -p .../shell.qml call -- mpris toggle
  ```
- Estado y datos: `MprisBackend` en memoria (`players`, `manualIndex`, `wanters`). Sin JSON. El polling de posición (Timer 500 ms) solo corre si hay interesados (`wanters`: el popup se registra con `setWanted("popup", …)`) y el estado es `Playing`; en modo rendimiento (`Theme.performanceMode`) `PillMedia` no carga la carátula.
- Dependencias: `Quickshell.Services.Mpris`, `COMMON`, `Services/Lang`, `Services/Audio`. Consumido por `Modules/Pill/PillMedia.qml`, `Modules/Dashboard/DashboardMpris.qml` y `Modules/Lock/LockMedia.qml` (que se registra con `setWanted("lock", …)` mientras la sesión está bloqueada).
- Notas: los controles (play/pausa/siguiente/anterior/seek) no son IPC: se llaman desde QML vía `MprisBackend.runCtl([...])`. Posición y duración en microsegundos.

- Rediseño Material (ver MATERIAL.md): la píldora (`PillMedia`), el módulo de barra (`MprisModule`) y el dashboard (`DashboardMpris`) muestran la carátula en un shape (`square`, cuadrado redondeado) y el avance como barra serpiente (`MdWavy`): ondula y avanza mientras suena y se aplana al pausar. Reaccionan al audio con `AudioLevels`. La píldora y la barra se registran como `setWanted("pill"|"bar", …)` para recibir la posición solo mientras se ven con un reproductor activo. En el dashboard, la barra sirve también de seek.

## Estilos intercambiables

Ajustes → Escritorio → Reproductor (MPRIS) (`Settings/pages/MprisPage.qml`) elige el estilo en cuatro superficies.

| Superficie | Preferencia (`Theme`) | Estilos |
|---|---|---|
| Barra horizontal | `mprisBarStyle` | `classic` (el de siempre), `controls` (anterior/play/siguiente), `progress` (barra fina bajo el texto + play) |
| Barra vertical | `mprisBarVStyle` | `cover`, `controls` (play + siguiente apilados), `ring` (aro de progreso alrededor de la carátula) |
| Dashboard | `mprisDashStyle` | `default` (el de siempre), `glass` |
| Popup de la barra | `mprisPopupStyle` | `default` (el de siempre), `glass`, `card`, `circle` |

- La barra usa `Theme.mprisActiveBarStyle`, que escoge el estilo horizontal o el vertical según `Theme.barVertical`. Se cambia con `Theme.setMprisStyle(kind, valor)` (`bar | barV | dash | popup`); las listas válidas están en `Theme.mprisBarStyles/BarVStyles/DashStyles/PopupStyles` y se guardan en `ui.toml`.
- `Services/Mpris/MprisView.qml` es la vista del Dashboard y del popup (`Mpris.qml`, que conserva cabecera y pie y solo cambia el cuerpo). Cada estilo se dibuja a un tamaño natural fijo (`MprisStyles.sizes`) y todo el escenario se escala (`fit`) para caber. `wantKey` registra la posición en `MprisBackend` solo mientras la vista se ve con algo sonando (Dashboard y popup ya se registran por su cuenta, por eso no pasan clave).
- Fondo: con `framed: true` (siempre en Dashboard y popup) la vista dibuja una tarjeta de superficie en la raíz, fuera del escenario escalado (`glass` suma borde). `cornerRadius` la iguala al radio del contenedor.
- Popup: `glass` escala al ancho útil; `card` y `circle` son verticales, usan su tamaño natural y el popup se estrecha a 340 px (`panelW`) para que no sobre espacio a los lados, creciendo en alto. El Dashboard solo ofrece estilos anchos porque su área es ancha y baja.
- `MprisModule` (barra) registra su propia clave de posición solo con los estilos `progress` y `ring`.
- A vigilar: el raíz de cada `Component` de estilo debe ser un `Item` simple. El `Loader` redimensiona el elemento raíz al tamaño del escenario, así que un `ColumnLayout` como raíz ignora su `x/y/width/height` y se desborda (se vio con un estilo de portada de fondo, ya retirado).
- A vigilar: al agregar un estilo hay que tocar `MprisStyles.sizes`, el `switch` de `MprisView.componentFor`, la lista correspondiente de `Theme` y las claves `mprisSty_*` en los dos idiomas. El volumen reutiliza `MprisVolume`, que escala con `Theme.ds` (escala del Dashboard).
- Pendiente: repetir y aleatorio de los mockups no están (el backend no los expone).
