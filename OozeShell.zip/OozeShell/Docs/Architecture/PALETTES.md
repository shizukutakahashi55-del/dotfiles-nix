# PALETTES — Paletas manuales

- Qué es: paletas fijas que reemplazan a matugen (Ajustes → Configuración avanzada → Apariencia → modo Paletas).
- Archivos:
  - `COMMON/Theme.qml` → `manualPalettes` (datos), `paletteOrder` (orden mostrado), `paletteIsDark`, `applyManualPalette`.
  - `Settings/PaletteGrid.qml` → rejilla agrupada con tarjetas de vista previa.
  - `Settings/pages/AppearancePage.qml` → arma el modelo del grid.
  - `Services/Lang/languages/Lang{Es,En}.qml` → claves `advPalGroup_*`, `advPalDark`, `advPalLight`.
- Grupos (`family`): `classic` (sin campo), `pastel`, `pink`, `nature`, `cozy` (solo con tema CoOzey, salvo la activa).
- Orden: dentro de cada grupo salvo `classic`, primero las claras y luego las oscuras.
- Tarjeta: miniatura con fondo, franja de superficie, círculo primario y punto terciario; etiqueta Clara/Oscura; la activa lleva borde de color primario y punto indicador.
- Añadir una paleta: agregar al FINAL de `manualPalettes` (el índice se guarda en las preferencias) con los 13 campos y `family`.
