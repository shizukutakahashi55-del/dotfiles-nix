// CORE — TerminalIpc
// IPC: target="terminal" fastfetch(on: bool), toggleFastfetch(), random(on: bool), toggleRandom(), opacity(terminal: string, percent: int): string, rescan()

import Quickshell
import Quickshell.Io
import QtQuick
import "../../Services/Terminal"

Item {
  id: self
  property var shell
  IpcHandler {
    target: "terminal"
    function fastfetch(on: bool): void { TerminalConfig.setFastfetch(on) }
    function toggleFastfetch(): void { TerminalConfig.toggleFastfetch() }
    function random(on: bool): void { TerminalConfig.setRandom(on) }
    function toggleRandom(): void { TerminalConfig.toggleRandom() }
    function opacity(terminal: string, percent: int): string {
      if (percent < 0 || percent > 100) return "invalid"
      TerminalConfig.applyOpacity(terminal, percent)
      return "ok"
    }
    function rescan(): void { TerminalConfig.refresh() }
  }
}
