// CORE — ScreenshotIpc
// IPC: target="screenshot" areaEdit(), colorPick(), fullSave(), areaCopy(), areaSave()

import Quickshell
import Quickshell.Io
import QtQuick
import "../../Services/Screenshot"

Item {
  id: self
  property var shell
  IpcHandler {
    target: "screenshot"
    function areaEdit(): void { ScreenshotBackend.areaEdit() }
    function colorPick(): void { ScreenshotBackend.colorPick() }
    function areaCopy(): void { ScreenshotBackend.areaCopy() }
    function fullSave(): void { ScreenshotBackend.fullSave() }
    function areaSave(): void { ScreenshotBackend.areaSave() }
  }
}
