// CORE — DashboardIpc
// IPC: target="dashboard" toggle(section), open(section), close(), section(): string

import Quickshell
import Quickshell.Io
import QtQuick
import "../../COMMON"
import "../../Modules/Dashboard"

Item {
  id: self
  property var shell

  DashboardSections { id: sections }

  readonly property var allowed: (Theme.pillMode ? sections.forPill : sections.forBar).map(e => e.id)

  IpcHandler {
    target: "dashboard"

    function toggle(section: string): void {
      if (self.allowed.indexOf(section) < 0) return
      const showing = AppState.dashboardOpen && AppState.dashboardSection === section
      self.shell.closeAllPopupsExceptAdvanced()
      if (showing) { AppState.closeDashboard(); return }
      self.shell.focusedMonitor = self.shell.resolveMonitor()
      AppState.openDashboard(section, self.shell.focusedMonitor)
    }

    function open(section: string): void {
      if (self.allowed.indexOf(section) < 0) return
      self.shell.closeAllPopupsExceptAdvanced()
      self.shell.focusedMonitor = self.shell.resolveMonitor()
      AppState.openDashboard(section, self.shell.focusedMonitor)
    }

    function close(): void { AppState.closeDashboard() }

    function section(): string { return AppState.dashboardOpen ? AppState.dashboardSection : "" }
  }
}
