// WorkspaceDots.qml — COMMON

import QtQuick
import QtQuick.Layouts


Item {
  id: root

  property var workspaces: []
  property bool vertical: false
  property int maxNameWidth: 170
  property bool useCapsule: false
  property string styleOverride: ""
  property color hoverColor: Theme.surfaceHigh

  readonly property string sty: root.styleOverride !== "" ? root.styleOverride : Theme.workspaceStyle
  readonly property bool textual: root.sty === "numbers" || root.sty === "kanji" || root.sty === "roman"
  readonly property bool capsule: root.useCapsule && !Theme.barPillBack
  readonly property real pad: root.capsule ? 8 : 0
  readonly property bool onFill: Theme.barMixedFilled
  readonly property color accent: root.onFill ? Theme.text : Theme.primary
  readonly property color onAccent: root.onFill ? Theme.bg : Theme.textOnPrimary
  readonly property bool showName: Theme.workspaceShowName && !root.textual && !root.vertical

  width: root.vertical ? (root.capsule ? 24 : 16) : grid.implicitWidth + root.pad * 2
  height: root.vertical ? grid.implicitHeight + root.pad * 2 : (root.capsule ? 24 : 16)

  Layout.preferredWidth: root.width
  Layout.preferredHeight: root.height

  readonly property var activeWs: {
    for (let i = 0; i < root.workspaces.length; i++)
      if (root.workspaces[i].active) return root.workspaces[i]
    return null
  }

  readonly property var kanjiDigits: ["", "一", "二", "三", "四", "五", "六", "七", "八", "九"]
  readonly property var romanMap: [[50, "L"], [40, "XL"], [10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"]]

  function toKanji(n) {
    if (n <= 0) return String(n)
    if (n === 10) return "十"
    if (n < 10) return root.kanjiDigits[n]
    if (n < 20) return "十" + root.kanjiDigits[n - 10]
    if (n < 100) return root.kanjiDigits[Math.floor(n / 10)] + "十" + root.kanjiDigits[n % 10]
    return String(n)
  }
  function toRoman(n) {
    if (n <= 0 || n >= 90) return String(n)
    let out = ""
    let left = n
    for (let i = 0; i < root.romanMap.length; i++) {
      while (left >= root.romanMap[i][0]) { out += root.romanMap[i][1]; left -= root.romanMap[i][0] }
    }
    return out
  }
  function glyph(w) {
    const n = parseInt(w.id)
    if (root.sty === "kanji") return root.toKanji(n)
    if (root.sty === "roman") return root.toRoman(n)
    return String(w.id)
  }

  function wsLabel(w) {
    if (!w) return ""
    const n = String(w.name ?? w.id)


    return (n !== "" && n !== String(w.id)) ? n : "Workspace " + w.id
  }


  readonly property var shown: root.workspaces.filter(
    w => w.active || w.urgent || w.occupied !== false)

  // ─── Cápsula ───
  Rectangle {
    visible: root.capsule
    anchors.fill: parent
    radius: Math.min(width, height) / 2
    border.width: 1
    border.color: Theme.tint(0.09)
    gradient: Gradient {
      orientation: Gradient.Vertical
      GradientStop { position: 0; color: Qt.lighter(Theme.mix(Theme.bg, Theme.surface, 0.7), 1.14) }
      GradientStop { position: 1; color: Theme.mix(Theme.bg, Theme.surface, 0.7) }
    }
  }

  // ─── Contenido ───
  GridLayout {
    id: grid
    anchors.centerIn: parent
    flow: root.vertical ? GridLayout.LeftToRight : GridLayout.TopToBottom
    columns: root.vertical ? 1 : -1
    rows: root.vertical ? -1 : 1
    columnSpacing: root.textual ? 2 : 5
    rowSpacing: root.textual ? 2 : 5

    Repeater {
      model: root.shown
      delegate: Item {
        id: cell
        required property var modelData
        readonly property bool isActive: !!cell.modelData.active
        readonly property bool isUrgent: !!cell.modelData.urgent && !cell.isActive
        readonly property bool hot: cellArea.containsMouse

        readonly property real along: root.textual ? Math.max(20, label.implicitWidth + 12)
          : (root.sty === "bubbles" ? (cell.isActive ? 14 : 10)
          : (root.sty === "lines" ? (cell.isActive ? 24 : 12)
          : (cell.isActive ? 22 : 8)))
        readonly property real across: root.textual ? 20 : (root.sty === "bubbles" ? (cell.isActive ? 14 : 10) : (root.sty === "lines" ? 4 : 8))

        Layout.preferredWidth: root.vertical ? 16 : cell.along
        Layout.preferredHeight: root.vertical ? cell.along : 16
        Behavior on Layout.preferredWidth { NumberAnimation { duration: Theme.animDuration(180); easing.type: Easing.OutCubic } }
        Behavior on Layout.preferredHeight { NumberAnimation { duration: Theme.animDuration(180); easing.type: Easing.OutCubic } }

        scale: cell.hot && !cell.isActive ? 1.14 : 1
        Behavior on scale { NumberAnimation { duration: Theme.animDuration(160); easing.type: Easing.OutBack } }

        Rectangle {
          visible: cell.isActive && !Theme.cozy
          anchors.centerIn: shape
          width: shape.width + 8
          height: shape.height + 8
          radius: Math.min(width, height) / 2
          color: root.accent
          opacity: 0.22
        }

        Rectangle {
          id: shape
          anchors.centerIn: parent
          width: root.vertical ? cell.across : (root.textual ? cell.along : parent.width)
          height: root.vertical ? (root.textual ? cell.along : parent.height) : cell.across
          radius: root.sty === "lines" ? 2 : Math.min(width, height) / 2
          readonly property bool hollow: root.sty === "bubbles" && !cell.isActive && !cell.isUrgent
          readonly property color tone: cell.isUrgent ? Theme.error : root.accent
          color: shape.hollow ? "transparent"
            : (root.textual ? (cell.isActive ? root.accent : (cell.hot ? root.hoverColor : "transparent"))
            : (cell.isActive || cell.isUrgent ? shape.tone : cell.hot ? Theme.text : Theme.subtext))
          border.width: shape.hollow ? 1.5 : 0
          border.color: cell.hot ? Theme.text : Theme.subtext
          opacity: (cell.isActive || cell.isUrgent || cell.hot || root.textual || shape.hollow) ? 1 : 0.55
          gradient: (cell.isActive && !root.textual && !Theme.cozy) ? activeGrad : null
          Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }

          Gradient {
            id: activeGrad
            orientation: Gradient.Vertical
            GradientStop { position: 0; color: Qt.lighter(root.accent, 1.22) }
            GradientStop { position: 1; color: root.accent }
          }
        }

        Text {
          id: label
          visible: root.textual
          anchors.centerIn: parent
          text: root.glyph(cell.modelData)
          color: cell.isActive ? root.onAccent : (cell.isUrgent ? Theme.error : (cell.hot ? Theme.text : Theme.subtext))
          font.family: Theme.fontFamily
          font.pixelSize: Theme.fs(root.sty === "kanji" ? 13 : 12)
          font.bold: cell.isActive
          Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }
        }

        MouseArea {
          id: cellArea
          anchors.fill: parent
          anchors.margins: -4
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          onClicked: WM.clickWorkspace(cell.modelData)
        }
      }
    }

    Text {
      id: nameText
      visible: root.showName && root.activeWs !== null
      Layout.leftMargin: 3
      Layout.preferredWidth: Math.min(nameText.implicitWidth, root.maxNameWidth)
      Layout.maximumWidth: root.maxNameWidth
      elide: Text.ElideRight
      text: root.wsLabel(root.activeWs)
      color: Theme.text
      font.pixelSize: Theme.fs(12)
      font.bold: true
      font.family: Theme.fontFamily
    }
  }
}
