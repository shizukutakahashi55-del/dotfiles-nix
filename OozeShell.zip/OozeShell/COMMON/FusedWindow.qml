// FusedWindow — ventana overlay para un popup que cuelga de la barra.
//
// Centraliza lo que antes estaba copiado (distinto) en Menu/Notify/Mpris:
//   • pantalla completa, transparente, capa Overlay
//   • clic afuera = cerrar. La franja de la barra queda LIBRE (mask), así
//     los botones de la barra (campana, ❄, reloj) siguen respondiendo
//     aunque haya un popup abierto.
//   • Esc = cerrar
//   • Cualquier otra tecla se reenvía por la señal keyPressed (para los
//     popups que se manejan con teclado, ej. el Overview). Con
//     exclusiveKeys: true la ventana toma el teclado apenas se abre, sin
//     esperar un clic (los atajos globales de Hyprland siguen funcionando).
//   • `active` decide si el popup captura input. Ponelo en
//     `open || panel.shown` para que la animación de cierre se vea entera.
//
// La ventana queda SIEMPRE montada (transparente y sin zona de clics
// mientras está cerrada), igual que la ventana del calendario. Antes se
// mostraba/ocultaba en cada apertura, y Hyprland le aplicaba su propia
// animación de layer (escala/fade): eso era el "spawn encima" y el
// corrimiento de 1-2px del panel.
//
// Modo Islas (Theme.islandsMode): las píldoras de la barra están en la capa
// Overlay y los popups nacen DE ellas (la tarjeta crece "detrás" de la isla,
// ver FusedPanel). Para que la isla quede siempre arriba del panel, esta
// ventana baja a la capa Top mientras haya islas; en fullscreen (`detached`,
// sin islas visibles) vuelve a Overlay para poder verse encima del juego.
// Además, con islas no hay franja de barra que dejar libre: cualquier clic
// fuera del panel lo cierra, y las islas (capa superior) igual reciben los suyos.
//
// Los hijos se colocan en un contenedor a pantalla completa; ahí va el
// FusedPanel, que se coloca solo según Theme.barPosition (ver FusedPanel).
import Quickshell
import Quickshell.Wayland
import QtQuick
import "../COMMON"

Item {
  id: root

  property bool active: false

  // ─── Montaje perezoso (EXPERIMENTAL, opt-in) ────────────────────────
  // Cada FusedWindow es una superficie layer-shell a PANTALLA COMPLETA que
  // se queda montada aunque el popup esté cerrado (hay ~21 en la shell): cada
  // una mantiene sus propios búferes ARGB del tamaño de la pantalla, más su
  // escena de Qt Quick. Con OOZESHELL_LAZY_WINDOWS=1 la ventana solo existe
  // mientras `active` (+ un margen para que termine la animación de cierre) y
  // el resto del tiempo no ocupa nada. Por defecto queda apagado porque el
  // montaje permanente se eligió a propósito (ver arriba: la animación de
  // capa de Hyprland al mapear la ventana). Prueba:
  //     OOZESHELL_LAZY_WINDOWS=1 quickshell
  //
  // MODO PERFORMANCE: con Performance activado (Ajustes avanzados) el montaje
  // perezoso se prende solo y se apaga al desactivarlo; así no hace falta lanzar
  // la shell con la variable. OOZESHELL_LAZY_WINDOWS=1 lo fuerza siempre y
  // OOZESHELL_LAZY_WINDOWS=0 lo apaga siempre (ni siquiera en Performance).
  readonly property string lazyEnv: Quickshell.env("OOZESHELL_LAZY_WINDOWS")
  readonly property bool lazyMount: root.lazyEnv === "1" || (root.lazyEnv !== "0" && Theme.performanceMode)
  readonly property bool mounted: !root.lazyMount || root.active || closeGrace.running
  Timer { id: closeGrace; interval: 900; repeat: false }
  onActiveChanged: { if (!root.active) closeGrace.restart() }

  // ─── Espera a la animación de mapeo del compositor (solo montaje perezoso) ───
  // El compositor (Hyprland, Mango) anima TODA superficie layer-shell nueva al
  // mapearla (slide / popin). Con montaje perezoso la ventana nace en cada
  // apertura y, si el panel empieza a crecer durante esa animación, parece salir
  // del borde de la pantalla en vez de la barra. La ventana es transparente
  // mientras el panel no crece, así que esa animación no se ve: solo hay que
  // esperar a que termine. `mapMs` debe ser >= la duración de la animación de
  // capas de tu compositor. Ajuste fino sin editar:
  //     OOZESHELL_MAP_MS=250 quickshell -c OozeShell
  // Lo ideal es apagar esa animación para estas capas en el compositor y poner
  // OOZESHELL_MAP_MS=0 (sin espera). Hyprland (Lua):
  //     hl.layer_rule({ name = "oozeshell-no-anim", match = { namespace = "^oozeshell-.*" }, no_anim = true })
  // (Un intento anterior mapeaba la ventana en 1×1 px y luego la estiraba; el
  //  compositor animaba ese cambio de tamaño y el panel parecía venir de la izquierda.)
  // En Performance las animaciones (shell y compositor) están apagadas: no hay
  // nada que esperar, así que `mapMs` es 0 salvo que lo pidas con la variable.
  readonly property int mapMs: {
    const v = parseInt(Quickshell.env("OOZESHELL_MAP_MS"))
    if (!isNaN(v)) return Math.max(0, v)
    return Theme.performanceMode ? 0 : 300
  }

  // ─── Listo para animar (solo importa con montaje perezoso) ───────────
  // Crear la superficie (+ escena + shaders del primer fotograma) tarda. Si el
  // FusedPanel empezara a animarse en cuanto `active` sube, la animación correría
  // "a ciegas" mientras la ventana nace, y al verse ya iría avanzada o terminada
  // (el panel no parece salir de la barra). Por eso el panel espera a `fusedReady`:
  // ventana visible + con tamaño + un instante para pintar. Ya montada (reapertura
  // dentro de closeGrace) sigue lista y no hay espera. Sin lazyMount: siempre true.
  // Ajuste fino sin editar: OOZESHELL_SETTLE_MS=150 quickshell -c OozeShell
  readonly property int settleMs: parseInt(Quickshell.env("OOZESHELL_SETTLE_MS")) || 80
  property bool fusedReady: !root.lazyMount
  readonly property bool surfaceUp: root.mounted && win.visible && host.width > 0 && host.height > 0
  onSurfaceUpChanged: {
    if (!root.lazyMount) return
    if (root.surfaceUp) settleTimer.restart()
    else { settleTimer.stop(); root.fusedReady = false }
  }
  Timer { id: settleTimer; interval: root.settleMs + root.mapMs; repeat: false; onTriggered: root.fusedReady = true }
  // `lazyMount` cambia en caliente (Performance on/off): `fusedReady` es una
  // propiedad que se asigna a mano, así que hay que resincronizarla.
  onLazyMountChanged: {
    settleTimer.stop()
    if (!root.lazyMount) root.fusedReady = true
    else if (root.surfaceUp) { root.fusedReady = false; settleTimer.restart() }
    else root.fusedReady = false
  }

  property string targetScreen: ""
  property string namespace: "oozeshell-popup"
  // true = mientras está abierta se queda con TODO el teclado (para popups
  // que se usan con teclas). false = solo lo toma al hacer clic.
  property bool exclusiveKeys: false
  signal closeRequested()
  // Tecla que no es Esc (key = Qt.Key_*, modifiers = Qt.*Modifier)
  signal keyPressed(int key, int modifiers, string text)

  // Hay islas y no estamos en fullscreen: esta ventana va en la capa Top
  // (Modo Píldora: lo mismo — la píldora central y la de Tray/Batería, en Overlay,
  //  quedan encima del panel que nace de ellas.)
  readonly property bool onIslands: (Theme.islandsMode || Theme.pillMode) && !root.detached

  readonly property real screenHeight: win.screen ? win.screen.height : 1080
  readonly property real screenWidth: win.screen ? win.screen.width : 1920

  default property alias content: host.data

  // La barra está oculta — por una ventana en fullscreen en esta pantalla, O
  // porque se está aplicando un wallpaper/esquema nuevo (Theme.wallpaperChanging,
  // ver Theme.qml) — así que el panel se dibuja flotante en vez de colgar de
  // ella (ver FusedPanel, "Modo flotante"). Lo lee el FusedPanel desde su
  // padre. Al terminar cualquiera de los dos (fullscreen o recarga de
  // wallpaper) vuelve solo a `false` y el panel se reengancha a la barra.
  readonly property bool detached: FullscreenState.isOn(win.screen) || Theme.wallpaperChanging

  PanelWindow {
    id: win

    screen: Quickshell.screens.find(s => s.name === root.targetScreen) ?? Quickshell.screens[0]
    visible: root.mounted
    color: "transparent"
    exclusiveZone: -1
    anchors { top: true; left: true; right: true; bottom: true }

    WlrLayershell.layer: root.onIslands ? WlrLayer.Top : WlrLayer.Overlay
    WlrLayershell.namespace: root.namespace
    // Cerrada no debe tocar el foco del teclado
    WlrLayershell.keyboardFocus: !root.active ? WlrKeyboardFocus.None
      : (root.exclusiveKeys ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.OnDemand)

    // Solo lo que está debajo de la barra captura input, y solo mientras
    // el popup está activo (cerrado: región vacía = todo click-through)
    mask: Region { item: backdrop }

    Connections {
      target: root
      function onActiveChanged() {
        if (root.active) keyCatcher.forceActiveFocus()
      }
    }
    // Con montaje perezoso la ventana aparece DESPUÉS de `active`: pedir el foco otra vez
    Connections {
      target: win
      function onVisibleChanged() {
        if (win.visible && root.active) keyCatcher.forceActiveFocus()
      }
    }

    Item {
      id: backdrop
      // La zona de "clic afuera" es todo MENOS la franja de la barra:
      //   arriba    → empieza debajo de ella
      //   abajo     → empieza en el borde de arriba y termina donde arranca la barra
      //   izquierda → empieza a la derecha de ella
      //   derecha   → empieza en el borde izquierdo y termina donde arranca la barra
      // (Con islas: pantalla completa; las islas quedan encima y responden solas)
      x: (Theme.barVertical && !Theme.barAtRight && !root.onIslands) ? Theme.barOffset : 0
      y: (!Theme.barVertical && !Theme.barAtBottom && !root.onIslands) ? Theme.barOffset : 0
      width: root.active ? (Theme.barVertical ? parent.width - Theme.barOffset : parent.width) : 0
      height: root.active
        ? (Theme.barVertical ? parent.height
                             : (root.onIslands ? parent.height : parent.height - Theme.barOffset))
        : 0

      MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.AllButtons
        onClicked: root.closeRequested()
      }
    }

    Item {
      id: host
      anchors.fill: parent
      // FusedPanel lee esto de su padre
      readonly property bool detached: root.detached
      // FusedPanel espera esto antes de animar (ver `fusedReady` arriba)
      readonly property bool fusedReady: root.fusedReady
      // FusedPanel lo lee para saber de qué isla (de qué pantalla) nace
      readonly property string screenName: win.screen ? win.screen.name : ""
    }

    Item {
      id: keyCatcher
      anchors.fill: parent
      focus: true
      Keys.onPressed: event => {
        if (event.key === Qt.Key_Escape) {
          root.closeRequested()
          event.accepted = true
        } else {
          root.keyPressed(event.key, event.modifiers, event.text)
        }
      }
    }
  }
}
