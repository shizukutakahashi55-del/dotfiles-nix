#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
QS="${QS:-quickshell}"
PREFIX="${OOZE_PREFIX:-${XDG_DATA_HOME:-$HOME/.local/share}/oozeshell/qml}"

if [ -f "$PREFIX/OozeShell/Native/qmldir" ]; then
  export QML_IMPORT_PATH="$PREFIX${QML_IMPORT_PATH:+:$QML_IMPORT_PATH}"
fi

shell_pids() {
  local p c cmd
  for p in $(pgrep -f 'shell\.qml' 2>/dev/null); do
    [ "$p" = "$$" ] && continue
    c=$(cat "/proc/$p/comm" 2>/dev/null) || continue
    case "$c" in *quickshell*|qs) ;; *) continue ;; esac
    cmd=$(tr '\0' ' ' <"/proc/$p/cmdline" 2>/dev/null)
    case "$cmd" in *" ipc "*) continue ;; esac
    echo "$p"
  done
}

"$QS" kill -p "$ROOT/shell.qml" >/dev/null 2>&1 || true
pids="$(shell_pids)"
if [ -n "$pids" ]; then
  kill $pids 2>/dev/null || true
  for _ in 1 2 3 4 5 6 7 8 9 10; do
    [ -z "$(shell_pids)" ] && break
    sleep 0.3
  done
  pids="$(shell_pids)"
  [ -n "$pids" ] && kill -9 $pids 2>/dev/null || true
fi

exec "$QS" -p "$ROOT/shell.qml" "$@"
