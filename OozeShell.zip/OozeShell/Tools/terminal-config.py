#!/usr/bin/env python3
# terminal-config.py — TERMINAL

import json
import os
import re
import shutil
import subprocess
import sys

HOME = os.path.expanduser("~")
CONFIG = os.environ.get("XDG_CONFIG_HOME") or os.path.join(HOME, ".config")
STATE_FILE = os.path.join(CONFIG, "oozeshell", "terminal.toml")
FASTFETCH_DIR = os.path.join(CONFIG, "fastfetch")
IMAGES_DIR = os.path.join(FASTFETCH_DIR, "images")
IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".gif", ".webp")
ZSHRC = os.path.join(HOME, ".zshrc")
RANDOM_SCRIPT = os.path.join(HOME, ".local", "bin", "random-fastfetch")
STARSHIP_FILE = os.environ.get("STARSHIP_CONFIG") or os.path.join(CONFIG, "starship.toml")
STARSHIP_TEMPLATE = os.path.join(CONFIG, "matugen", "templates", "starship.toml")

EXTRA_PATH = [
    os.path.join(HOME, ".local", "bin"),
    "/run/current-system/sw/bin",
    "/etc/profiles/per-user/" + os.environ.get("USER", ""),
    "/usr/local/bin",
    "/usr/bin",
]


# ─── RUTAS ─────────────────────────────────────────────────────────────────
def which(name):
    path = os.pathsep.join(EXTRA_PATH + [os.environ.get("PATH", "")])
    return shutil.which(name, path=path) is not None


def real(path):
    return os.path.realpath(path)


def writable(path):
    target = real(path)
    if os.path.exists(target):
        return os.access(target, os.W_OK)
    return os.access(os.path.dirname(target), os.W_OK)


def read_text(path):
    try:
        with open(real(path), "r", encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return ""


def write_text(path, text):
    target = real(path)
    folder = os.path.dirname(target)
    os.makedirs(folder, exist_ok=True)
    tmp = target + ".oozetmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        fh.write(text)
    if os.path.exists(target):
        shutil.copymode(target, tmp)
    os.replace(tmp, target)


# ─── TOML POR LÍNEAS ───────────────────────────────────────────────────────
SECTION_RE = re.compile(r"^\s*\[([A-Za-z0-9_.\-]+)\]\s*(#.*)?$")


def scan_lines(lines):
    section = None
    in_multiline = False
    for index, line in enumerate(lines):
        if in_multiline:
            if line.count('"""') % 2 == 1:
                in_multiline = False
            yield index, section, None
            continue
        match = SECTION_RE.match(line)
        if match:
            section = match.group(1)
            yield index, section, "header"
            continue
        if line.count('"""') % 2 == 1:
            in_multiline = True
        yield index, section, "line"


def toml_get(text, section, key):
    pattern = re.compile(r"^\s*" + re.escape(key) + r"\s*=\s*(.*?)\s*(#.*)?$")
    lines = text.split("\n")
    for index, current, kind in scan_lines(lines):
        if kind != "line" or current != section:
            continue
        match = pattern.match(lines[index])
        if match:
            return match.group(1)
    return None


def toml_set(text, section, key, literal):
    lines = text.split("\n")
    pattern = re.compile(r"^(\s*" + re.escape(key) + r"\s*=\s*)(.*?)(\s*#.*)?$")
    header_index = None
    first_header = None
    last_line_in_section = None
    for index, current, kind in scan_lines(lines):
        if kind == "header":
            if first_header is None:
                first_header = index
            if current == section:
                header_index = index
                last_line_in_section = index
            continue
        if current != section or kind is None:
            continue
        match = pattern.match(lines[index])
        if match:
            lines[index] = match.group(1) + literal + (match.group(3) or "")
            return "\n".join(lines)
        if lines[index].strip() and not lines[index].lstrip().startswith("#"):
            last_line_in_section = index
    entry = key + " = " + literal
    if section is None:
        position = first_header if first_header is not None else len(lines)
        while position > 0 and not lines[position - 1].strip():
            position -= 1
        lines.insert(position, entry)
        return "\n".join(lines)
    if header_index is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines.extend(["[" + section + "]", entry, ""])
        return "\n".join(lines)
    lines.insert((last_line_in_section or header_index) + 1, entry)
    return "\n".join(lines)


def parse_literal(raw):
    if raw is None:
        return None
    value = raw.strip()
    if value == "true":
        return True
    if value == "false":
        return False
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        return value[1:-1]
    cleaned = value.replace("_", "")
    try:
        return int(cleaned)
    except ValueError:
        try:
            return float(cleaned)
        except ValueError:
            return value


def quote(text):
    return '"' + str(text).replace("\\", "\\\\").replace('"', '\\"') + '"'


# ─── ESTADO DE FASTFETCH ───────────────────────────────────────────────────
def state_read():
    text = read_text(STATE_FILE)
    enabled = parse_literal(toml_get(text, None, "fastfetch"))
    random_on = parse_literal(toml_get(text, None, "fastfetchRandom"))
    image = parse_literal(toml_get(text, None, "fastfetchImage"))
    return {
        "enabled": enabled if isinstance(enabled, bool) else True,
        "random": random_on if isinstance(random_on, bool) else True,
        "image": image if isinstance(image, str) else "",
    }


def state_write(key, literal):
    text = read_text(STATE_FILE)
    if not text:
        text = "\n"
    write_text(STATE_FILE, toml_set(text, None, key, literal).rstrip("\n") + "\n")


def images_list():
    out = []
    try:
        names = sorted(os.listdir(IMAGES_DIR), key=str.lower)
    except OSError:
        return out
    for name in names:
        full = os.path.join(IMAGES_DIR, name)
        if name.lower().endswith(IMAGE_EXTS) and os.path.isfile(full):
            out.append({"name": name, "size": os.path.getsize(full)})
    return out


def safe_name(name):
    base = os.path.basename(str(name))
    return base if base and base == str(name) and not base.startswith(".") else ""


def unique_name(name):
    stem, ext = os.path.splitext(name)
    stem = re.sub(r"[^\w.\-]+", "_", stem).strip("._") or "image"
    candidate = stem + ext.lower()
    counter = 1
    while os.path.exists(os.path.join(IMAGES_DIR, candidate)):
        candidate = stem + "-" + str(counter) + ext.lower()
        counter += 1
    return candidate


# ─── TERMINALES ────────────────────────────────────────────────────────────
TERMINALS = [
    {"id": "kitty", "name": "Kitty", "bin": "kitty", "file": "kitty/kitty.conf",
     "kind": "line", "pattern": r"^(\s*background_opacity\s+)([0-9.]+)(.*)$",
     "template": "background_opacity {v}", "signal": ["pkill", "-USR1", "-x", "kitty"]},
    {"id": "ghostty", "name": "Ghostty", "bin": "ghostty", "file": "ghostty/config.ghostty",
     "kind": "line", "pattern": r"^(\s*background-opacity\s*=\s*)([0-9.]+)(.*)$",
     "template": "background-opacity = {v}", "signal": ["pkill", "-USR2", "-x", "ghostty"]},
    {"id": "foot", "name": "Foot", "bin": "foot", "file": "foot/foot.ini",
     "kind": "ini", "section": ["colors-dark", "colors"], "key": "alpha", "signal": None},
    {"id": "alacritty", "name": "Alacritty", "bin": "alacritty", "file": "alacritty/alacritty.toml",
     "kind": "ini", "section": ["window"], "key": "opacity", "signal": None},
    {"id": "wezterm", "name": "WezTerm", "bin": "wezterm", "file": "wezterm/wezterm.lua",
     "kind": "line", "pattern": r"^(\s*config\.window_background_opacity\s*=\s*)([0-9.]+)(.*)$",
     "template": "config.window_background_opacity = {v}", "signal": None},
]


def terminal_by_id(term_id):
    for term in TERMINALS:
        if term["id"] == term_id:
            return term
    return None


def terminal_path(term):
    return os.path.join(CONFIG, term["file"])


def format_opacity(percent):
    return "{:.2f}".format(max(0, min(100, int(percent))) / 100.0)


def opacity_read(term):
    text = read_text(terminal_path(term))
    if not text:
        return None
    if term["kind"] == "line":
        for line in text.split("\n"):
            match = re.match(term["pattern"], line)
            if match:
                return int(round(float(match.group(2)) * 100))
        return None
    for section in term["section"]:
        value = parse_literal(toml_get(text, section, term["key"]))
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return int(round(float(value) * 100))
    return None


def opacity_write(term, percent):
    path = terminal_path(term)
    text = read_text(path)
    if not text and not os.path.exists(real(path)):
        return "missing"
    value = format_opacity(percent)
    if term["kind"] == "line":
        lines = text.split("\n")
        for index, line in enumerate(lines):
            match = re.match(term["pattern"], line)
            if match:
                lines[index] = match.group(1) + value + match.group(3)
                write_text(path, "\n".join(lines))
                return ""
        entry = term["template"].format(v=value)
        if term["id"] == "wezterm":
            for index, line in enumerate(lines):
                if line.strip().startswith("return config"):
                    lines.insert(index, entry)
                    break
            else:
                return "nokey"
        else:
            lines.insert(0, entry)
        write_text(path, "\n".join(lines))
        return ""
    target = term["section"][0]
    for section in term["section"]:
        if toml_get(text, section, term["key"]) is not None:
            target = section
            break
    write_text(path, toml_set(text, target, term["key"], value))
    return ""


def terminal_reload(term):
    if term["signal"]:
        subprocess.run(term["signal"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


# ─── STARSHIP ──────────────────────────────────────────────────────────────
STARSHIP_KEYS = {
    "newline": {"section": None, "key": "add_newline", "type": "bool", "default": True},
    "time": {"section": "time", "key": "disabled", "type": "bool", "invert": True, "default": True},
    "timeFormat": {"section": "time", "key": "time_format", "type": "string", "default": "%R"},
    "duration": {"section": "cmd_duration", "key": "disabled", "type": "bool", "invert": True, "default": False},
    "durationMin": {"section": "cmd_duration", "key": "min_time", "type": "int", "default": 2000},
    "dirDepth": {"section": "directory", "key": "truncation_length", "type": "int", "default": 3},
}


def starship_values():
    text = read_text(STARSHIP_FILE) or read_text(STARSHIP_TEMPLATE)
    out = {}
    for name, spec in STARSHIP_KEYS.items():
        value = parse_literal(toml_get(text, spec["section"], spec["key"]))
        if value is None or (spec["type"] == "bool") != isinstance(value, bool):
            value = spec["default"]
        if spec.get("invert"):
            value = not value
        out[name] = value
    return out


def starship_write(name, raw):
    spec = STARSHIP_KEYS.get(name)
    if spec is None:
        return "unknown-key"
    if spec["type"] == "bool":
        flag = str(raw).lower() in ("1", "true", "on", "yes")
        if spec.get("invert"):
            flag = not flag
        literal = "true" if flag else "false"
    elif spec["type"] == "int":
        try:
            literal = str(max(0, int(raw)))
        except ValueError:
            return "invalid"
    else:
        literal = quote(raw)
    touched = False
    for path in (STARSHIP_FILE, STARSHIP_TEMPLATE):
        if not os.path.exists(real(path)):
            continue
        text = read_text(path)
        write_text(path, toml_set(text, spec["section"], spec["key"], literal))
        touched = True
    if not touched:
        return "missing"
    subprocess.run(["pkill", "-USR1", "-x", "zsh"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return ""


# ─── DETECCIÓN ─────────────────────────────────────────────────────────────
def tracked_items():
    return [
        {"id": "zshrc", "path": ZSHRC},
        {"id": "starship", "path": STARSHIP_FILE},
        {"id": "starshipTemplate", "path": STARSHIP_TEMPLATE},
        {"id": "fastfetch", "path": os.path.join(FASTFETCH_DIR, "config.jsonc")},
        {"id": "randomFastfetch", "path": RANDOM_SCRIPT},
    ] + [{"id": t["id"], "path": terminal_path(t)} for t in TERMINALS]


def dotfiles_root(items):
    for item in items:
        target = real(item["path"])
        marker = os.sep + ".config" + os.sep
        if target != item["path"] and marker in target:
            return target.split(marker)[0]
        if target != item["path"] and os.path.basename(target) in (".zshrc", "random-fastfetch"):
            return os.path.dirname(target)
    fallback = os.path.join(HOME, "dotfiles")
    return fallback if os.path.isdir(fallback) else ""


def scan():
    items = tracked_items()
    rows = []
    for item in items:
        exists = os.path.exists(item["path"])
        rows.append({
            "id": item["id"],
            "path": item["path"],
            "real": real(item["path"]) if exists else "",
            "exists": exists,
            "linked": exists and real(item["path"]) != os.path.abspath(item["path"]),
            "writable": writable(item["path"]) if exists else False,
        })
    terminals = []
    for term in TERMINALS:
        path = terminal_path(term)
        terminals.append({
            "id": term["id"],
            "name": term["name"],
            "installed": which(term["bin"]),
            "found": os.path.exists(path),
            "path": path,
            "writable": writable(path) if os.path.exists(path) else False,
            "opacity": opacity_read(term),
            "live": bool(term["signal"]) or term["id"] in ("alacritty", "wezterm"),
        })
    state = state_read()
    zshrc_text = read_text(ZSHRC)
    return {
        "dotfilesRoot": dotfiles_root(items),
        "items": rows,
        "terminals": terminals,
        "starship": {
            "installed": which("starship"),
            "found": os.path.exists(STARSHIP_FILE),
            "path": STARSHIP_FILE,
            "templatePath": STARSHIP_TEMPLATE,
            "templateFound": os.path.exists(STARSHIP_TEMPLATE),
            "writable": writable(STARSHIP_FILE) if os.path.exists(STARSHIP_FILE) else False,
            "values": starship_values(),
        },
        "fastfetch": {
            "installed": which("fastfetch"),
            "enabled": state["enabled"],
            "random": state["random"],
            "image": state["image"],
            "dir": FASTFETCH_DIR,
            "imagesDir": IMAGES_DIR,
            "configFound": os.path.exists(os.path.join(FASTFETCH_DIR, "config.jsonc")),
            "scriptFound": os.access(RANDOM_SCRIPT, os.X_OK),
            "zshrcHook": "fastfetch" in zshrc_text,
            "images": images_list(),
        },
    }


# ─── COMANDOS ──────────────────────────────────────────────────────────────
def cmd_opacity(args):
    term = terminal_by_id(args[0]) if len(args) >= 2 else None
    if term is None:
        return {"ok": False, "error": "unknown-terminal"}
    try:
        percent = int(args[1])
    except ValueError:
        return {"ok": False, "error": "invalid"}
    error = opacity_write(term, percent)
    if error:
        return {"ok": False, "error": error}
    terminal_reload(term)
    return {"ok": True}


def cmd_flag(key, args):
    if not args:
        return {"ok": False, "error": "invalid"}
    if args[0].lower() == "toggle":
        current = state_read()["enabled" if key == "fastfetch" else "random"]
        state_write(key, "false" if current else "true")
        return {"ok": True}
    state_write(key, "true" if args[0].lower() in ("1", "true", "on", "yes") else "false")
    return {"ok": True}


def cmd_image_use(args):
    name = args[0] if args else ""
    if name and (not safe_name(name) or not os.path.isfile(os.path.join(IMAGES_DIR, name))):
        return {"ok": False, "error": "missing"}
    state_write("fastfetchImage", quote(name))
    return {"ok": True}


def cmd_image_add(args):
    if not args:
        return {"ok": False, "error": "invalid"}
    src = args[0]
    if not os.path.isfile(src) or not src.lower().endswith(IMAGE_EXTS):
        return {"ok": False, "error": "unsupported"}
    os.makedirs(IMAGES_DIR, exist_ok=True)
    name = unique_name(os.path.basename(src))
    shutil.copyfile(src, os.path.join(IMAGES_DIR, name))
    return {"ok": True, "name": name}


def cmd_image_remove(args):
    name = args[0] if args else ""
    full = os.path.join(IMAGES_DIR, name)
    if not safe_name(name) or not os.path.isfile(full):
        return {"ok": False, "error": "missing"}
    os.remove(full)
    if state_read()["image"] == name:
        state_write("fastfetchImage", quote(""))
    return {"ok": True}


def cmd_starship(args):
    if len(args) < 2:
        return {"ok": False, "error": "invalid"}
    error = starship_write(args[0], args[1])
    return {"ok": False, "error": error} if error else {"ok": True}


def main(argv):
    command = argv[1] if len(argv) > 1 else "scan"
    args = argv[2:]
    try:
        if command == "scan":
            result = scan()
        elif command == "opacity":
            result = cmd_opacity(args)
        elif command == "fastfetch":
            result = cmd_flag("fastfetch", args)
        elif command == "random":
            result = cmd_flag("fastfetchRandom", args)
        elif command == "image-use":
            result = cmd_image_use(args)
        elif command == "image-add":
            result = cmd_image_add(args)
        elif command == "image-remove":
            result = cmd_image_remove(args)
        elif command == "starship":
            result = cmd_starship(args)
        else:
            result = {"ok": False, "error": "unknown-command"}
    except OSError as exc:
        result = {"ok": False, "error": "io:" + str(exc.strerror or exc)}
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
