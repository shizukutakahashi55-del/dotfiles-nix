// EditorSurface — SCREENSHOT EDITOR

import Quickshell
import QtQuick
import "../../COMMON"
import "../Lang"

Item {
  id: ed

  // ── Estado ──

  readonly property string source: ScreenshotBackend.editRaw
  readonly property string srcUrl: ed.source === "" ? "" : "file://" + ed.source
  readonly property real dpr: Math.max(1, ScreenshotBackend.editDpr)
  readonly property real imgW: img.implicitWidth
  readonly property real imgH: img.implicitHeight
  readonly property real topSpace: 24 + bar.height + 32
  readonly property real availW: Math.max(120, ed.width - 96)
  readonly property real availH: Math.max(120, ed.height - ed.topSpace - 40)
  readonly property real fit: ed.imgW > 0 ? Math.min(ed.availW / ed.imgW, ed.availH / ed.imgH, 1 / ed.dpr) : 1

  property string tool: CaptureConfig.opt("edTool", "pen")
  property string prevTool: "pen"
  property color ink: CaptureConfig.opt("edColor", "#ef4444")
  property int sizeIdx: CaptureConfig.opt("edSize", 1)
  property var items: []
  property var redoItems: []
  property var draft: null
  property bool texting: false
  property real textX: 0
  property real textY: 0
  property string hint: ""
  property string toast: ""

  readonly property real strokeW: [2, 4, 7][ed.sizeIdx] * ed.dpr
  readonly property real textPx: [18, 26, 38][ed.sizeIdx] * ed.dpr
  readonly property bool canUndo: ed.items.length > 0
  readonly property bool canRedo: ed.redoItems.length > 0

  onToolChanged: if (ed.tool !== "picker") CaptureConfig.set("edTool", ed.tool)
  onInkChanged: CaptureConfig.set("edColor", String(ed.ink))
  onSizeIdxChanged: CaptureConfig.set("edSize", ed.sizeIdx)

  // ── Acciones de edición ──

  function setTool(t) {
    if (ed.texting) ed.commitText()
    if (t === "picker" && ed.tool !== "picker") ed.prevTool = ed.tool
    ed.tool = t
  }

  function pushItem(it) {
    ed.items = ed.items.concat([it])
    ed.redoItems = []
  }

  function undo() {
    if (!ed.canUndo) return
    const a = ed.items.slice()
    const last = a.pop()
    ed.items = a
    ed.redoItems = ed.redoItems.concat([last])
  }

  function redo() {
    if (!ed.canRedo) return
    const r = ed.redoItems.slice()
    const it = r.pop()
    ed.redoItems = r
    ed.items = ed.items.concat([it])
  }

  function beginText(x, y) {
    ed.textX = x
    ed.textY = y
    ti.text = ""
    ed.texting = true
    Qt.callLater(function() { ti.forceActiveFocus() })
  }

  function commitText() {
    if (!ed.texting) return
    const s = ti.text
    ed.texting = false
    if (s.trim().length === 0) return
    ed.pushItem({ t: "text", c: String(ed.ink), px: ed.textPx, x: ed.textX, y: ed.textY, s: s })
  }

  function cancelText() { ed.texting = false }

  function showToast(s) {
    ed.toast = s
    toastTimer.restart()
  }

  function hex2(n) { return (n < 16 ? "0" : "") + n.toString(16) }

  function colorPicked(r, g, b) {
    const hex = "#" + ed.hex2(r) + ed.hex2(g) + ed.hex2(b)
    ed.ink = hex
    Quickshell.execDetached(["sh", "-c", "printf %s '" + hex + "' | wl-copy"])
    ed.showToast(Translations.t("edColorCopied") + " " + hex)
    ed.tool = ed.prevTool
  }

  // ── Exportar y cerrar ──

  property var pendingExport: null

  function exportTo(path, done) {
    ed.commitText()
    ed.draft = null
    cv.requestPaint()
    ed.pendingExport = { path: path, done: done }
    exportTimer.restart()
  }

  function outPath() { return ed.source.replace(/\.png$/, "_edit.png") }

  function doCopy() {
    ed.exportTo(ed.outPath(), function(out) {
      Quickshell.execDetached(CaptureConfig.editFinishCommand("copy", out, ed.source))
      Qt.callLater(function() { ScreenshotBackend.closeEditor(false) })
    })
  }

  function doSave() {
    ed.exportTo(ed.outPath(), function(out) {
      Quickshell.execDetached(CaptureConfig.editFinishCommand("save", out, ed.source))
      Qt.callLater(function() { ScreenshotBackend.closeEditor(false) })
    })
  }

  function cancel() { ScreenshotBackend.closeEditor(true) }

  Timer {
    id: exportTimer
    interval: 80
    onTriggered: {
      const job = ed.pendingExport
      if (!job) return
      content.grabToImage(function(res) {
        res.saveToFile(job.path)
        job.done(job.path)
      }, Qt.size(content.width, content.height))
    }
  }

  Timer {
    id: toastTimer
    interval: 1800
    onTriggered: ed.toast = ""
  }

  // ── Fondo ──

  Rectangle {
    anchors.fill: parent
    color: Qt.rgba(0, 0, 0, 0.62)
  }

  // ── Barra de herramientas ──

  EditorToolbar {
    id: bar
    editor: ed
    anchors.horizontalCenter: parent.horizontalCenter
    y: 24
  }

  Text {
    anchors.horizontalCenter: parent.horizontalCenter
    y: bar.y + bar.height + 8
    text: ed.texting ? Translations.t("edTextHint") : ed.hint
    color: Theme.subtext
    font.family: Theme.fontFamily
    font.pixelSize: Theme.fs(12)
  }

  // ── Escenario con la imagen ──

  Item {
    id: stage
    width: ed.imgW * ed.fit
    height: ed.imgH * ed.fit
    x: Math.round((ed.width - width) / 2)
    y: Math.round(ed.topSpace + (ed.availH - height) / 2)

    Rectangle {
      anchors.fill: parent
      anchors.margins: -1
      color: "transparent"
      border.width: 1
      border.color: Theme.withAlpha(Theme.text, 0.35)
    }

    Item {
      id: world
      width: ed.imgW
      height: ed.imgH
      scale: ed.fit
      transformOrigin: Item.TopLeft

      Item {
        id: content
        anchors.fill: parent

        Image {
          id: img
          source: ed.srcUrl
          cache: false
          asynchronous: false
        }

        EditorCanvas {
          id: cv
          anchors.fill: parent
          items: ed.items
          draft: ed.draft
          family: Theme.fontFamily
        }

        // ── Entrada del puntero ──

        MouseArea {
          anchors.fill: parent
          cursorShape: ed.tool === "text" ? Qt.IBeamCursor : Qt.CrossCursor

          onPressed: m => {
            if (ed.texting) ed.commitText()
            if (ed.tool === "picker") { sampler.sample(Math.round(m.x), Math.round(m.y)); return }
            if (ed.tool === "text") { ed.beginText(m.x, m.y); return }
            const t = ed.tool
            if (t === "pen" || t === "marker")
              ed.draft = { t: t, c: String(ed.ink), w: ed.strokeW * (t === "marker" ? 4 : 1), p: [[m.x, m.y]] }
            else
              ed.draft = { t: t, c: String(ed.ink), w: ed.strokeW, a: [m.x, m.y], b: [m.x, m.y] }
          }

          onPositionChanged: m => {
            if (!pressed || !ed.draft) return
            if (ed.draft.p) ed.draft.p.push([m.x, m.y])
            else ed.draft.b = [m.x, m.y]
            cv.requestPaint()
          }

          onReleased: m => {
            if (!ed.draft) return
            const d = ed.draft
            ed.draft = null
            const ok = d.p ? true : Math.hypot(d.b[0] - d.a[0], d.b[1] - d.a[1]) > 4 * ed.dpr
            if (ok) ed.pushItem(d)
          }
        }

        // ── Cuadro de texto ──

        Rectangle {
          visible: ed.texting
          x: ed.textX - 6
          y: ed.textY - 4
          width: Math.max(60, ti.contentWidth + 12)
          height: ti.contentHeight + 8
          color: Qt.rgba(0, 0, 0, 0.25)
          border.width: Math.max(1, ed.dpr)
          border.color: ed.ink
        }

        TextInput {
          id: ti
          visible: ed.texting
          x: ed.textX
          y: ed.textY
          color: ed.ink
          selectionColor: Theme.primary
          font.family: Theme.fontFamily
          font.pixelSize: Math.round(ed.textPx)
          onAccepted: ed.commitText()
        }
      }
    }
  }

  // ── Muestreo de color ──

  Canvas {
    id: sampler
    width: 1
    height: 1
    opacity: 0.01
    renderStrategy: Canvas.Immediate
    property real sx: 0
    property real sy: 0
    property bool armed: false

    function sample(x, y) {
      sampler.sx = x
      sampler.sy = y
      sampler.armed = true
      sampler.requestPaint()
    }

    Component.onCompleted: sampler.loadImage(ed.srcUrl)

    onPaint: {
      if (!sampler.armed || !sampler.isImageLoaded(ed.srcUrl)) return
      sampler.armed = false
      const ctx = sampler.getContext("2d")
      ctx.clearRect(0, 0, 1, 1)
      ctx.drawImage(ed.srcUrl, sampler.sx, sampler.sy, 1, 1, 0, 0, 1, 1)
      const d = ctx.getImageData(0, 0, 1, 1).data
      ed.colorPicked(d[0], d[1], d[2])
    }
  }

  // ── Aviso ──

  Rectangle {
    visible: ed.toast !== ""
    anchors.horizontalCenter: parent.horizontalCenter
    y: parent.height - height - 28
    width: toastText.implicitWidth + 28
    height: toastText.implicitHeight + 16
    radius: height / 2
    color: Theme.bg
    border.width: Theme.bw1
    border.color: Theme.edge
    Rectangle {
      anchors.left: parent.left
      anchors.leftMargin: 10
      anchors.verticalCenter: parent.verticalCenter
      width: 12
      height: 12
      radius: 6
      color: ed.ink
      border.width: 1
      border.color: Theme.edge
    }
    Text {
      id: toastText
      anchors.centerIn: parent
      anchors.horizontalCenterOffset: 8
      text: ed.toast
      color: Theme.text
      font.family: Theme.fontFamily
      font.pixelSize: Theme.fs(12)
    }
  }

  // ── Atajos ──

  Shortcut { sequence: "Escape"; onActivated: ed.texting ? ed.cancelText() : ed.cancel() }
  Shortcut { sequence: "Ctrl+Z"; enabled: !ed.texting; onActivated: ed.undo() }
  Shortcut { sequences: ["Ctrl+Shift+Z", "Ctrl+Y"]; enabled: !ed.texting; onActivated: ed.redo() }
  Shortcut { sequence: "Ctrl+C"; enabled: !ed.texting; onActivated: ed.doCopy() }
  Shortcut { sequence: "Ctrl+S"; onActivated: ed.doSave() }
  Shortcut { sequence: "P"; enabled: !ed.texting; onActivated: ed.setTool("pen") }
  Shortcut { sequence: "M"; enabled: !ed.texting; onActivated: ed.setTool("marker") }
  Shortcut { sequence: "A"; enabled: !ed.texting; onActivated: ed.setTool("arrow") }
  Shortcut { sequence: "R"; enabled: !ed.texting; onActivated: ed.setTool("rect") }
  Shortcut { sequence: "E"; enabled: !ed.texting; onActivated: ed.setTool("ellipse") }
  Shortcut { sequence: "T"; enabled: !ed.texting; onActivated: ed.setTool("text") }
  Shortcut { sequence: "I"; enabled: !ed.texting; onActivated: ed.setTool("picker") }
}
