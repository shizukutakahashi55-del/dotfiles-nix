// MprisView — reproductor MPRIS reutilizable (widget flotante y Dashboard). Cada estilo se dibuja a su tamaño natural y se escala para caber.

import QtQuick
import QtQuick.Layouts
import QtQuick.Shapes
import "../../COMMON"
import "../Lang"

Item {
  id: root

  property string style: "glass"
  property string wantKey: ""
  property bool framed: false
  property real cornerRadius: 18

  readonly property bool has: MprisBackend.activePlayers.length > 0
  readonly property bool playing: MprisBackend.currentStatus === "Playing"
  readonly property var nat: MprisStyles.sizeOf(root.style)
  readonly property real fit: Math.max(0.1, Math.min(root.width / root.nat[0], root.height / root.nat[1]))

  // ─── Posición: solo se sondea mientras la vista se ve con un reproductor sonando ───
  readonly property bool wantPos: root.wantKey !== "" && root.visible && root.has && root.playing
  onWantPosChanged: if (root.wantKey !== "") MprisBackend.setWanted(root.wantKey, root.wantPos)
  Component.onCompleted: if (root.wantKey !== "") MprisBackend.setWanted(root.wantKey, root.wantPos)
  Component.onDestruction: if (root.wantKey !== "") MprisBackend.setWanted(root.wantKey, false)

  // ─── Átomos ───
  component CtlBtn: Rectangle {
    id: b
    property string glyph: ""
    property real size: 40
    property bool main: false
    property color fg: Theme.text
    property color chip: Theme.withAlpha(Theme.text, 0.10)
    signal clicked()

    width: b.size
    height: b.size
    radius: b.size / 2
    color: b.main ? Theme.primary : (ma.containsMouse ? Theme.withAlpha(b.fg, 0.22) : b.chip)
    scale: ma.pressed ? 0.92 : 1
    Behavior on scale { NumberAnimation { duration: Theme.animDuration(120) } }
    Behavior on color { ColorAnimation { duration: Theme.animDuration(120) } }

    Text {
      anchors.centerIn: parent
      text: b.glyph
      font.family: Theme.monoFamily
      font.pixelSize: Math.round(b.size * 0.5)
      color: b.main ? Theme.bg : b.fg
    }
    MouseArea {
      id: ma
      anchors.fill: parent
      hoverEnabled: true
      cursorShape: Qt.PointingHandCursor
      onClicked: b.clicked()
    }
  }

  component Transport: Item {
    id: t
    property real unit: 40
    property bool column: false
    property color fg: Theme.text
    property color chip: Theme.withAlpha(Theme.text, 0.10)
    readonly property real gap: t.unit * 0.3

    implicitWidth: t.column ? t.unit : t.unit * 0.8 * 2 + t.unit + t.gap * 2
    implicitHeight: t.column ? t.unit * 0.8 * 2 + t.unit + t.gap * 2 : t.unit

    GridLayout {
      anchors.centerIn: parent
      columns: t.column ? 1 : 3
      rowSpacing: t.gap
      columnSpacing: t.gap

      CtlBtn {
        glyph: "󰒮"
        size: t.unit * 0.8
        fg: t.fg
        chip: t.chip
        Layout.alignment: Qt.AlignCenter
        onClicked: MprisBackend.runCtl(["previous"])
      }
      CtlBtn {
        glyph: MprisBackend.currentStatus === "Playing" ? "󰏤" : "󰐊"
        size: t.unit
        main: true
        Layout.alignment: Qt.AlignCenter
        onClicked: MprisBackend.runCtl(["play-pause"])
      }
      CtlBtn {
        glyph: "󰒭"
        size: t.unit * 0.8
        fg: t.fg
        chip: t.chip
        Layout.alignment: Qt.AlignCenter
        onClicked: MprisBackend.runCtl(["next"])
      }
    }
  }

  component Seek: Item {
    id: s
    property real thickness: 5
    property color fg: Theme.text
    property bool dragging: false
    property real dragRatio: 0
    readonly property real shown: s.dragging ? s.dragRatio : MprisBackend.progressRatio

    implicitHeight: 18

    Rectangle {
      id: track
      width: s.width
      height: s.thickness
      anchors.verticalCenter: parent.verticalCenter
      radius: height / 2
      color: Theme.withAlpha(s.fg, 0.18)

      Rectangle {
        width: track.width * s.shown
        height: parent.height
        radius: parent.radius
        color: Theme.primary
      }
    }
    Rectangle {
      visible: ma.containsMouse || s.dragging
      x: track.width * s.shown - width / 2
      anchors.verticalCenter: parent.verticalCenter
      width: 12
      height: 12
      radius: 6
      color: s.fg
    }
    MouseArea {
      id: ma
      anchors.fill: parent
      hoverEnabled: true
      cursorShape: Qt.PointingHandCursor

      function ratioAt(x) { return Math.max(0, Math.min(1, x / width)) }

      onPressed: m => { s.dragging = true; s.dragRatio = ma.ratioAt(m.x) }
      onPositionChanged: m => { if (pressed) s.dragRatio = ma.ratioAt(m.x) }
      onReleased: {
        if (MprisBackend.currentLength > 0)
          MprisBackend.runCtl(["position", (s.dragRatio * MprisBackend.currentLength / 1000000).toFixed(2)])
        s.dragging = false
      }
    }
  }

  component Times: Item {
    id: tm
    property color fg: Theme.subtext
    implicitHeight: 14

    Text {
      anchors.left: parent.left
      text: MprisBackend.formatTime(MprisBackend.currentPosition)
      color: tm.fg
      font.family: Theme.fontFamily
      font.pixelSize: 11
    }
    Text {
      anchors.right: parent.right
      text: "-" + MprisBackend.formatTime(Math.max(0, MprisBackend.currentLength - MprisBackend.currentPosition))
      color: tm.fg
      font.family: Theme.fontFamily
      font.pixelSize: 11
    }
  }

  component Titles: Column {
    id: tt
    property real titleSize: 16
    property int align: Text.AlignLeft
    property color fg: Theme.text
    property color accent: Theme.primary
    spacing: 2

    Text {
      width: tt.width
      text: MprisBackend.currentTitle !== "" ? MprisBackend.currentTitle : Translations.t("mprisNoPlaying")
      elide: Text.ElideRight
      horizontalAlignment: tt.align
      color: tt.fg
      font.family: Theme.fontFamily
      font.pixelSize: tt.titleSize
      font.bold: true
    }
    Text {
      width: tt.width
      visible: MprisBackend.currentArtist !== ""
      text: MprisBackend.currentArtist
      elide: Text.ElideRight
      horizontalAlignment: tt.align
      color: tt.accent
      font.family: Theme.fontFamily
      font.pixelSize: Math.round(tt.titleSize * 0.82)
    }
  }

  component Cover: MdCover {
    source: MprisBackend.currentArt
    decodeSize: 256
    dimmed: MprisBackend.currentStatus !== "Playing"
    glyph: MprisBackend.currentStatus === "Playing" ? "󰎈" : "󰝛"
  }

  // ─── Estilos ───
  Component {
    id: cGlass
    Item {
      Cover { x: 16; y: 16; width: 128; height: 128; shape: "square" }
      ColumnLayout {
        x: 160; y: 16; width: 224; height: 128
        spacing: 4
        Titles { Layout.fillWidth: true; titleSize: 16 }
        Item { Layout.fillHeight: true }
        Seek { Layout.fillWidth: true }
        Times { Layout.fillWidth: true }
        Transport { Layout.alignment: Qt.AlignHCenter; unit: 38 }
      }
    }
  }

  Component {
    id: cCard
    Item {
      Cover { x: 50; y: 18; width: 150; height: 150; shape: "square" }
      ColumnLayout {
        x: 18; y: 180; width: 214; height: 152
        spacing: 4
        Titles { Layout.fillWidth: true; titleSize: 17; align: Text.AlignHCenter }
        Seek { Layout.fillWidth: true }
        Times { Layout.fillWidth: true }
        Transport { Layout.alignment: Qt.AlignHCenter; unit: 40 }
        MprisVolume { Layout.fillWidth: true; Layout.preferredHeight: 22; thickness: 22 }
      }
    }
  }

  Component {
    id: cCircle
    Item {
      Shape {
        x: 35; y: 20; width: 200; height: 200
        layer.enabled: true
        layer.samples: 4
        ShapePath {
          strokeColor: Theme.withAlpha(Theme.text, 0.16)
          strokeWidth: 5
          fillColor: "transparent"
          PathAngleArc { centerX: 100; centerY: 100; radiusX: 96; radiusY: 96; startAngle: 0; sweepAngle: 360 }
        }
        ShapePath {
          strokeColor: Theme.primary
          strokeWidth: 5
          capStyle: ShapePath.RoundCap
          fillColor: "transparent"
          PathAngleArc {
            centerX: 100; centerY: 100; radiusX: 96; radiusY: 96
            startAngle: -90
            sweepAngle: 360 * MprisBackend.progressRatio
          }
        }
      }
      Cover { x: 51; y: 36; width: 168; height: 168; shape: "circle" }
      ColumnLayout {
        x: 18; y: 232; width: 234; height: 126
        spacing: 6
        Titles { Layout.fillWidth: true; titleSize: 17; align: Text.AlignHCenter }
        Item { Layout.fillHeight: true }
        Transport { Layout.alignment: Qt.AlignHCenter; unit: 44 }
        MprisVolume { Layout.fillWidth: true; Layout.preferredHeight: 22; thickness: 22 }
      }
    }
  }

  function componentFor(s) {
    switch (s) {
      case "card":   return cCard
      case "circle": return cCircle
      default:       return cGlass
    }
  }

  // ─── Fondo de tarjeta (fuera del escenario escalado) ───
  Rectangle {
    visible: root.framed
    anchors.fill: parent
    radius: root.cornerRadius
    color: Theme.surface
    border.width: root.style === "glass" ? 1 : 0
    border.color: Theme.withAlpha(Theme.primary, 0.28)
  }

  // ─── Escenario escalado ───
  Item {
    id: stage
    visible: root.has
    width: root.nat[0]
    height: root.nat[1]
    scale: root.fit
    transformOrigin: Item.TopLeft
    x: (root.width - stage.width * stage.scale) / 2
    y: (root.height - stage.height * stage.scale) / 2

    Loader {
      anchors.fill: parent
      sourceComponent: root.componentFor(root.style)
    }
  }

  Text {
    visible: !root.has
    anchors.centerIn: parent
    text: Translations.t("mprisNoPlaying")
    color: Theme.subtext
    font.family: Theme.fontFamily
    font.pixelSize: Theme.fs(13)
  }
}
