// MprisStyles — tamaño natural de cada estilo de MprisView (Dashboard y popup de la barra); las listas de estilos viven en Theme.

pragma Singleton
import QtQuick
import Quickshell

Singleton {
  id: root

  // ─── Tamaño natural de MprisView (ancho, alto) ───
  readonly property var sizes: ({
    glass: [400, 160], card: [250, 350], circle: [270, 368]
  })

  function sizeOf(style) { return root.sizes[style] || root.sizes.glass }
}
