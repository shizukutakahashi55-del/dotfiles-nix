// TerminalConfig — TERMINAL

pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import "../DefaultApps"

Singleton {
  id: root

  // ─── ESTADO ───
  property var data: ({})
  property bool loaded: false
  property string lastError: ""
  property var queue: []
  property var drafts: ({})

  signal failed(string error)

  readonly property string tool: Quickshell.shellDir + "/Tools/terminal-config.py"
  readonly property string home: Quickshell.env("HOME") ?? ""

  readonly property var terminals: root.data.terminals ?? []
  readonly property var items: root.data.items ?? []
  readonly property var starship: root.data.starship ?? ({ values: {} })
  readonly property var fastfetch: root.data.fastfetch ?? ({ images: [] })
  readonly property string dotfilesRoot: root.data.dotfilesRoot ?? ""
  readonly property bool busy: worker.running || root.queue.length > 0

  readonly property bool fastfetchEnabled: root.fastfetch.enabled ?? true
  readonly property bool fastfetchRandom: root.fastfetch.random ?? true
  readonly property string fastfetchImage: root.fastfetch.image ?? ""
  readonly property var images: root.fastfetch.images ?? []
  readonly property string imagesDir: root.fastfetch.imagesDir ?? (root.home + "/.config/fastfetch/images")

  Component.onCompleted: root.refresh()

  // ─── CONSULTAS ───
  function terminalInfo(id) {
    return root.terminals.find(t => t.id === id) ?? null
  }

  function itemInfo(id) {
    return root.items.find(i => i.id === id) ?? null
  }

  function opacityOf(id) {
    if (root.drafts[id] !== undefined) return root.drafts[id]
    const info = root.terminalInfo(id)
    return (info && info.opacity !== null && info.opacity !== undefined) ? info.opacity : 100
  }

  function imageUrl(name) {
    return "file://" + encodeURI(root.imagesDir + "/" + name).replace(/#/g, "%23").replace(/\?/g, "%3F")
  }

  function shortPath(path) {
    const p = String(path ?? "")
    return root.home !== "" && p.indexOf(root.home + "/") === 0 ? "~" + p.slice(root.home.length) : p
  }

  // ─── COLA ───
  function enqueue(args) {
    root.queue = root.queue.concat([args])
    root.pump()
  }

  function pump() {
    if (worker.running || root.queue.length === 0) return
    worker.args = root.queue[0]
    worker.running = true
  }

  function refresh() {
    if (root.queue.some(a => a[0] === "scan")) return
    root.enqueue(["scan"])
  }

  function finish(sent, text) {
    let doc = null
    try { doc = JSON.parse(text) } catch (e) { doc = null }

    if (doc === null) {
      root.lastError = "tool"
      root.failed("tool")
      return
    }

    if (sent[0] === "scan") {
      root.data = doc
      root.loaded = true
      if (!opacityTimer.running) root.drafts = ({})
      return
    }

    if (doc.ok !== true) {
      root.lastError = String(doc.error ?? "error")
      root.failed(root.lastError)
    } else {
      root.lastError = ""
    }
    root.refresh()
  }

  // ─── ACCIONES ───
  function setFastfetch(on) { root.enqueue(["fastfetch", on ? "on" : "off"]) }
  function setRandom(on) { root.enqueue(["random", on ? "on" : "off"]) }
  function useImage(name) { root.enqueue(["image-use", String(name ?? "")]) }
  function addImage(path) { if (path) root.enqueue(["image-add", String(path)]) }
  function removeImage(name) { root.enqueue(["image-remove", String(name)]) }
  function setStarship(key, value) { root.enqueue(["starship", key, String(value)]) }

  function toggleFastfetch() { root.enqueue(["fastfetch", "toggle"]) }
  function toggleRandom() { root.enqueue(["random", "toggle"]) }

  function applyOpacity(id, percent) {
    root.enqueue(["opacity", id, String(Math.max(0, Math.min(100, Math.round(percent))))])
  }

  function setOpacity(id, percent) {
    const next = Object.assign({}, root.drafts)
    next[id] = Math.max(0, Math.min(100, Math.round(percent)))
    root.drafts = next
    opacityTimer.restart()
  }

  function openInEditor(path) {
    if (path) DefaultApps.run("editor", [path], false)
  }

  function openFolder(path) {
    if (path) DefaultApps.openDir(path)
  }

  // ─── TRABAJADOR ───
  Timer {
    id: opacityTimer
    interval: 350
    onTriggered: {
      for (const id of Object.keys(root.drafts))
        root.enqueue(["opacity", id, String(root.drafts[id])])
    }
  }

  Process {
    id: worker
    property var args: []
    property string buffer: ""
    command: ["python3", root.tool].concat(worker.args)
    running: false
    stdout: SplitParser { onRead: line => worker.buffer += line }
    stderr: SplitParser { onRead: line => console.log("[terminal]", line) }
    onRunningChanged: {
      if (running) return
      const text = worker.buffer.trim()
      worker.buffer = ""
      const sent = root.queue.length > 0 ? root.queue[0] : worker.args
      root.queue = root.queue.slice(1)
      root.finish(sent, text)
      root.pump()
    }
  }
}
