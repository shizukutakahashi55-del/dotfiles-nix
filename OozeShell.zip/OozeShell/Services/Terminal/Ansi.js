.pragma library

const BASE = ["#1e1e2e", "#e5534b", "#57ab5a", "#c69026", "#539bf5", "#b083f0", "#39c5cf", "#adbac7",
              "#545d68", "#ff938a", "#6bc46d", "#daaa3f", "#6cb6ff", "#dcbdfb", "#56d4dd", "#cdd9e5"]

function sgr(kind, value) {
  if (kind === "reset") return "\\e[0m"
  if (kind === "bold") return "\\e[1m"
  if (kind === "fg") return "\\e[" + (value < 8 ? 30 + value : 82 + value) + "m"
  if (kind === "bg") return "\\e[" + (value < 8 ? 40 + value : 92 + value) + "m"
  return ""
}

function hexSgr(hex, background) {
  const m = /^#?([0-9a-fA-F]{6})$/.exec(String(hex || "").trim())
  if (!m) return ""
  const n = parseInt(m[1], 16)
  return "\\e[" + (background ? 48 : 38) + ";2;" + ((n >> 16) & 255) + ";" + ((n >> 8) & 255) + ";" + (n & 255) + "m"
}

function paletteColor(i) {
  return BASE[i]
}

function sample() {
  return [
    "\\e[38;2;176;131;240m   ▄▄▄▄▄▄▄   \\e[0m",
    "\\e[38;2;176;131;240m ▄█\\e[1;97m ●   ● \\e[0;38;2;176;131;240m█▄ \\e[0m",
    "\\e[38;2;176;131;240m ██\\e[1;97m   ▽   \\e[0;38;2;176;131;240m██ \\e[0m",
    "\\e[38;2;176;131;240m  ▀███████▀  \\e[0m",
    "\\e[90m   ▀▀   ▀▀   \\e[0m"
  ].join("\n")
}
