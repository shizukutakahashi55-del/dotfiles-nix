// LauncherHistory

import Quickshell
import Quickshell.Io
import QtQuick

Item {
  id: root

  width: 0
  height: 0

  // ─── Estado ─────────────────────────────────────────────────────
  property var launches: ({})
  property var last: ({})
  property var favorites: []
  property int rev: 0
  property bool saveAgain: false

  readonly property int recentLimit: 5
  readonly property int maxEntries: 200
  readonly property string dir: Quickshell.env("HOME") + "/.config/oozeshell"
  readonly property string file: root.dir + "/launcher-history.json"

  // ─── Consultas ──────────────────────────────────────────────────
  function isFavorite(id) {
    void root.rev
    return root.favorites.indexOf(id) >= 0
  }

  function lastUsed(id) {
    void root.rev
    return root.last[id] ?? 0
  }

  function boost(id) {
    void root.rev
    const n = Math.min(root.launches[id] ?? 0, 20)
    return (root.favorites.indexOf(id) >= 0 ? 80 : 0) + n * 5
  }

  function favoriteOrder(id) {
    void root.rev
    return root.favorites.indexOf(id)
  }

  // ─── Escritura ──────────────────────────────────────────────────
  function record(id) {
    if (!id) return
    const l = Object.assign({}, root.launches)
    const t = Object.assign({}, root.last)
    l[id] = (l[id] ?? 0) + 1
    t[id] = Date.now()
    root.launches = l
    root.last = t
    root.prune()
    root.commit()
  }

  function toggleFavorite(id) {
    if (!id) return
    const i = root.favorites.indexOf(id)
    const next = root.favorites.slice()
    if (i >= 0) next.splice(i, 1)
    else next.push(id)
    root.favorites = next
    root.commit()
  }

  function prune() {
    const ids = Object.keys(root.last)
    if (ids.length <= root.maxEntries) return
    ids.sort((a, b) => root.last[a] - root.last[b])
    const l = Object.assign({}, root.launches)
    const t = Object.assign({}, root.last)
    for (let i = 0; i < ids.length - root.maxEntries; i++) {
      if (root.favorites.indexOf(ids[i]) >= 0) continue
      delete l[ids[i]]
      delete t[ids[i]]
    }
    root.launches = l
    root.last = t
  }

  function commit() {
    root.rev++
    saveProc.text = JSON.stringify({
      launches: root.launches,
      last: root.last,
      favorites: root.favorites
    })
    if (saveProc.running) root.saveAgain = true
    else saveProc.running = true
  }

  // ─── Persistencia ───────────────────────────────────────────────
  Process {
    id: saveProc
    property string text: ""
    command: ["sh", "-c",
      'mkdir -p "$2" && printf "%s" "$1" > "$3.tmp" && mv -f "$3.tmp" "$3"',
      "sh", saveProc.text, root.dir, root.file]
    running: false
    onRunningChanged: {
      if (running || !root.saveAgain) return
      root.saveAgain = false
      Qt.callLater(() => { saveProc.running = true })
    }
  }

  Process {
    id: loadProc
    property string buffer: ""
    command: ["sh", "-c", 'cat "$1" 2>/dev/null; exit 0', "sh", root.file]
    running: true
    stdout: SplitParser { onRead: line => loadProc.buffer += line }
    onRunningChanged: {
      if (running) return
      const raw = loadProc.buffer.trim()
      loadProc.buffer = ""
      if (raw === "") return
      try {
        const j = JSON.parse(raw)
        root.launches = (j.launches && typeof j.launches === "object") ? j.launches : ({})
        root.last = (j.last && typeof j.last === "object") ? j.last : ({})
        root.favorites = Array.isArray(j.favorites) ? j.favorites.filter(x => typeof x === "string") : []
        root.rev++
      } catch (e) {
      }
    }
  }
}
