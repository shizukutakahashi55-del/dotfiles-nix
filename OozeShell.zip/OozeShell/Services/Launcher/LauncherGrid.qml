// LauncherGrid

import Quickshell
import QtQuick
import "../../COMMON"

Item {
  id: root

  property var values: []
  property int selected: 0
  property string mode: "apps"
  property bool glass: false
  property bool glow: false
  property bool doubleClick: false
  property var favorites: []
  property bool entering: false
  property string enterAnim: "slide"
  property int tileMin: 104
  readonly property int cols: Math.max(3, Math.floor(root.width / root.tileMin))
  readonly property real cellW: root.width / root.cols
  readonly property real cellH: Math.round(root.cellW * 0.98)

  signal picked(int index)
  signal activated(int index)
  signal favorited(int index)

  function follow() {
    view.positionViewAtIndex(Math.max(0, Math.min(root.selected, view.count - 1)), GridView.Contain)
  }
  onSelectedChanged: root.follow()

  // ─── Rejilla ────────────────────────────────────────────────────
  GridView {
    id: view
    anchors.fill: parent
    cellWidth: root.cellW
    cellHeight: root.cellH
    clip: true
    boundsBehavior: Flickable.StopAtBounds
    interactive: contentHeight > height

    model: ScriptModel {
      values: root.values
      objectProp: "id"
    }

    delegate: Item {
      id: tile
      required property var modelData
      required property int index

      readonly property bool isCurrent: tile.index === root.selected
      readonly property bool fav: root.favorites.indexOf(tile.modelData.id) >= 0
      property bool revealed: false
      property bool instant: false

      width: root.cellW
      height: root.cellH

      Timer {
        id: revealTimer
        interval: 1 + Math.min(tile.index, 24) * 22
        repeat: false
        onTriggered: tile.revealed = true
      }
      Component.onCompleted: {
        if (root.entering) revealTimer.start()
        else { tile.instant = true; tile.revealed = true }
      }

      Item {
        id: card
        anchors { fill: parent; margins: 5 }
        opacity: tile.revealed ? 1 : 0
        scale: !tile.revealed ? (root.enterAnim === "zoom" || root.enterAnim === "slide" ? 0.55 : 1)
             : tile.isCurrent ? 1.07 : (area.containsMouse ? 1.03 : 1)
        transform: Translate {
          y: tile.revealed ? 0 : (root.enterAnim === "slide" ? 18 : 0)
          Behavior on y {
            enabled: !tile.instant
            NumberAnimation { duration: Theme.animDuration(320); easing.type: Easing.OutCubic }
          }
        }
        Behavior on opacity {
          enabled: !tile.instant
          NumberAnimation { duration: Theme.animDuration(240) }
        }
        Behavior on scale {
          NumberAnimation { duration: Theme.animDuration(tile.revealed ? 200 : 380); easing.type: Easing.OutBack; easing.overshoot: 1.6 }
        }

        Rectangle {
          anchors.fill: parent
          radius: Theme.cardRadius
          color: tile.isCurrent ? (root.glass ? Qt.alpha(Theme.surfaceHigh, 0.7) : Theme.surfaceHigh)
               : area.containsMouse ? (root.glass ? Qt.alpha(Theme.surface, 0.55) : Theme.surface)
               : "transparent"
          border.width: tile.isCurrent ? 1 : 0
          border.color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.7)
          Behavior on color { ColorAnimation { duration: Theme.animDuration(140) } }
        }

        Rectangle {
          anchors { fill: parent; margins: -3 }
          radius: Theme.cardRadius + 3
          color: "transparent"
          border.width: 2
          border.color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.4)
          visible: tile.isCurrent && root.glow
          opacity: 0.2
          SequentialAnimation on opacity {
            running: tile.isCurrent && root.glow && Theme.uiAnimationsEnabled
            loops: Animation.Infinite
            NumberAnimation { from: 0.15; to: 0.7; duration: Theme.animDuration(900); easing.type: Easing.InOutSine }
            NumberAnimation { from: 0.7; to: 0.15; duration: Theme.animDuration(900); easing.type: Easing.InOutSine }
          }
        }

        Column {
          anchors { centerIn: parent }
          width: parent.width - 10
          spacing: 6

          LauncherGlyph {
            anchors.horizontalCenter: parent.horizontalCenter
            item: tile.modelData
            mode: root.mode
            size: Math.round(root.cellW * 0.42)
          }
          Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            elide: Text.ElideRight
            maximumLineCount: 2
            wrapMode: Text.Wrap
            text: tile.modelData.isCalc ? "= " + tile.modelData.name : tile.modelData.name
            color: Theme.text
            font.pixelSize: Theme.fs(12)
            font.family: Theme.fontFamily
            font.bold: tile.isCurrent
          }
        }

        Text {
          visible: tile.fav
          anchors { top: parent.top; right: parent.right; topMargin: 8; rightMargin: 10 }
          text: "󰓎"
          color: Theme.primary
          font.pixelSize: Theme.fs(16)
          font.family: Theme.monoFamily
        }

        MouseArea {
          id: area
          anchors.fill: parent
          hoverEnabled: true
          cursorShape: Qt.PointingHandCursor
          acceptedButtons: Qt.LeftButton | Qt.RightButton
          onClicked: mouse => {
            root.picked(tile.index)
            if (mouse.button === Qt.RightButton) root.favorited(tile.index)
            else if (!root.doubleClick) root.activated(tile.index)
          }
          onDoubleClicked: mouse => {
            if (mouse.button === Qt.LeftButton && root.doubleClick) root.activated(tile.index)
          }
        }
      }
    }
  }
}
