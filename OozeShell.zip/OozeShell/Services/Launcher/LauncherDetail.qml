// LauncherDetail

import QtQuick
import QtQuick.Layouts
import "../../COMMON"
import "../Lang"

Item {
  id: root

  property var item: null
  property string cover: ""
  property string glyph: ""
  property bool isApp: false
  property bool favorite: false
  property int pad: 16

  signal launchRequested()
  signal favoriteRequested()

  // ─── Botón de acción ────────────────────────────────────────────
  component ActionButton: Rectangle {
    id: btn

    property string icon: ""
    property string label: ""
    property bool primary: false
    signal clicked()

    Layout.fillWidth: true
    Layout.preferredHeight: 36
    radius: Theme.cardRadius - 4
    color: btn.primary
      ? (area.containsMouse ? Qt.lighter(Theme.primary, 1.12) : Theme.primary)
      : (area.containsMouse ? Qt.lighter(Theme.surfaceHigh, 1.15) : Theme.surfaceHigh)
    scale: area.pressed ? 0.96 : 1.0
    Behavior on color { ColorAnimation { duration: Theme.animDuration(140) } }
    Behavior on scale { NumberAnimation { duration: Theme.animDuration(120); easing.type: Easing.OutBack } }

    Row {
      anchors.centerIn: parent
      spacing: 7

      Text {
        anchors.verticalCenter: parent.verticalCenter
        text: btn.icon
        color: btn.primary ? Theme.textOnPrimary : Theme.primary
        font.pixelSize: Theme.fs(15)
        font.family: Theme.monoFamily
      }
      Text {
        anchors.verticalCenter: parent.verticalCenter
        width: Math.min(implicitWidth, btn.width - 52)
        elide: Text.ElideRight
        text: btn.label
        color: btn.primary ? Theme.textOnPrimary : Theme.text
        font.pixelSize: Theme.fs(12)
        font.bold: true
        font.family: Theme.fontFamily
      }
    }

    MouseArea {
      id: area
      anchors.fill: parent
      hoverEnabled: true
      cursorShape: Qt.PointingHandCursor
      onClicked: btn.clicked()
    }
  }

  // ─── Panel ──────────────────────────────────────────────────────
  Rectangle {
    anchors {
      fill: parent
      topMargin: root.pad
      bottomMargin: root.pad
      rightMargin: root.pad
      leftMargin: 4
    }
    radius: Theme.cardRadius
    color: Theme.surface

    ColumnLayout {
      anchors { fill: parent; margins: 16 }
      spacing: 12

      // ── Vista previa ──
      Item {
        id: stage
        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.minimumHeight: 80

        Rectangle {
          anchors.centerIn: parent
          width: Math.min(stage.width, stage.height) * 0.85
          height: width
          radius: width / 2
          color: Qt.alpha(Theme.primary, 0.14)
          visible: root.cover === ""
        }

        Image {
          id: art
          anchors { fill: parent; margins: 4 }
          visible: root.cover !== ""
          source: root.cover
          fillMode: Image.PreserveAspectFit
          asynchronous: true
          smooth: true
          sourceSize.height: 600
          opacity: status === Image.Ready ? 1.0 : 0.0
          Behavior on opacity { NumberAnimation { duration: Theme.animDuration(260) } }
          onStatusChanged: { if (status === Image.Ready && Theme.effectsActive) zoomIn.restart() }

          NumberAnimation {
            id: zoomIn
            target: art
            property: "scale"
            from: 1.04
            to: 1.0
            duration: Theme.animDuration(280)
            easing.type: Easing.OutCubic
          }
        }

        AppIcon {
          anchors.centerIn: parent
          visible: root.cover === "" && root.isApp
          size: Math.min(112, stage.width, stage.height)
          icon: root.item ? (root.item.icon ?? "") : ""
        }

        Text {
          anchors.centerIn: parent
          visible: root.cover === "" && !root.isApp
          text: root.glyph
          color: Theme.primary
          font.pixelSize: Theme.fs(56)
          font.family: Theme.monoFamily
        }
      }

      // ── Nombre y descripción ──
      ColumnLayout {
        id: info
        Layout.fillWidth: true
        spacing: 4
        transform: Translate { id: infoShift }

        Connections {
          target: root
          function onItemChanged() { if (Theme.effectsActive) infoIn.restart() }
        }
        ParallelAnimation {
          id: infoIn
          NumberAnimation { target: info; property: "opacity"; from: 0; to: 1; duration: Theme.animDuration(200) }
          NumberAnimation { target: infoShift; property: "y"; from: 6; to: 0; duration: Theme.animDuration(240); easing.type: Easing.OutCubic }
        }

        Text {
          Layout.fillWidth: true
          horizontalAlignment: Text.AlignHCenter
          wrapMode: Text.Wrap
          maximumLineCount: 2
          elide: Text.ElideRight
          text: root.item ? (root.item.isCalc ? "= " + root.item.name : root.item.name) : ""
          color: Theme.text
          font.pixelSize: Theme.fs(17)
          font.bold: true
          font.family: Theme.titleFamily
        }
        Text {
          Layout.fillWidth: true
          horizontalAlignment: Text.AlignHCenter
          wrapMode: Text.Wrap
          maximumLineCount: 3
          elide: Text.ElideRight
          visible: text !== ""
          text: root.item ? (root.item.sub ?? "") : ""
          color: Theme.subtext
          font.pixelSize: Theme.fs(11)
          font.family: Theme.fontFamily
        }
      }

      // ── Acciones ──
      ColumnLayout {
        Layout.fillWidth: true
        spacing: 8
        visible: root.isApp

        ActionButton {
          primary: true
          icon: "󰐊"
          label: Translations.t("launcherDetailLaunch")
          onClicked: root.launchRequested()
        }
        ActionButton {
          icon: root.favorite ? "󰓎" : "󰓒"
          label: root.favorite ? Translations.t("launcherDetailFavRemove") : Translations.t("launcherDetailFavAdd")
          onClicked: root.favoriteRequested()
        }
      }
    }
  }
}
