// LauncherGlyph

import QtQuick
import "../../COMMON"

Item {
  id: root

  property var item: null
  property string mode: "apps"
  property real size: 40

  readonly property bool useGlyph: !!root.item && (root.mode !== "apps" || !!root.item.isCalc || !!root.item.glyph)
  readonly property string glyphText: !root.item ? ""
    : root.item.isCalc ? "󰃬"
    : root.item.glyph ? root.item.glyph
    : root.mode === "run" ? "󰆍"
    : (root.item.isDir ? "󰉋" : "󰈔")

  implicitWidth: root.size
  implicitHeight: root.size

  // ─── Contenido ──────────────────────────────────────────────────
  AppIcon {
    anchors.fill: parent
    visible: !!root.item && !root.useGlyph
    size: root.size
    icon: root.item ? (root.item.icon ?? "") : ""
  }

  Text {
    anchors.centerIn: parent
    visible: root.useGlyph
    text: root.glyphText
    color: (!!root.item && (root.item.isCalc || !!root.item.glyph || root.item.isDir)) ? Theme.primary : Theme.subtext
    font.pixelSize: Math.round(root.size * 0.8)
    font.family: Theme.monoFamily
  }
}
