// WallsCounter — WALLS

import QtQuick
import "../../COMMON"

Item {
  id: counter

  required property var walls
  property int pillHeight: 32
  property int fontSize: 11
  property bool plain: false

  readonly property bool busy: counter.walls.thumbsGenerating
                               || counter.walls.searchPending
                               || (counter.walls.onlineMode && counter.walls.onlineLoading)
  readonly property int dotSlot: counter.plain ? 0 : 12
  readonly property real textW: Math.ceil(Math.max(probe.width, counterText.implicitWidth))

  TextMetrics {
    id: probe
    text: "999 / 999"
    font.pixelSize: counter.fontSize
    font.family: Theme.fontFamily
  }

  implicitWidth: counter.textW + counter.dotSlot + (counter.plain ? 0 : 24)
  implicitHeight: counter.pillHeight

  SkinRect {
    anchors.fill: parent
    visible: !counter.plain
    notch: 4
    raised: Theme.cozy
    depth: 3
    inkColor: Theme.ink
    color: Qt.rgba(0, 0, 0, 0.55)
    border.color: Qt.rgba(1, 1, 1, 0.18)
    border.width: Theme.bw1
  }

  Rectangle {
    id: busyDot
    visible: !counter.plain
    anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
    width: 6
    height: 6
    radius: Theme.cozy ? 0 : 3
    color: Theme.primary
    opacity: counter.busy ? 1 : 0

    SequentialAnimation on opacity {
      running: counter.busy && counter.walls.open && Theme.uiAnimationsEnabled
      loops: Animation.Infinite
      NumberAnimation { from: 1; to: 0.25; duration: Theme.animDuration(520); easing.type: Easing.InOutSine }
      NumberAnimation { from: 0.25; to: 1; duration: Theme.animDuration(520); easing.type: Easing.InOutSine }
    }
  }

  Text {
    id: counterText
    anchors.verticalCenter: parent.verticalCenter
    x: counter.plain ? 0 : counter.dotSlot + 12 + Math.round((parent.width - counter.dotSlot - 24 - width) / 2)
    text: (counter.walls.activeModel.count > 0 ? counter.walls.currentIndex + 1 : 0) + " / " + counter.walls.activeModel.count
    color: counter.plain ? Theme.tint(0.7) : Qt.rgba(1, 1, 1, 0.75)
    font.pixelSize: counter.fontSize
    font.family: Theme.fontFamily
  }
}
