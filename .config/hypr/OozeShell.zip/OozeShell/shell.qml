// OozeShell Wallpapers and More

import Quickshell
import Quickshell.Io
import "./WALLS"

ShellRoot {
  id: root

  property bool wallsOpen:     false
  property int  currentWallIndex: 0

  Process {
    id: initColors
    command: ["bash", "-c",
      "WP=$(cat /home/oozenix/.cache/awww/last 2>/dev/null); " +
      "if [ -n \"$WP\" ] && [ -f \"$WP\" ]; then " +
      "  matugen image \"$WP\" --prefer lightness --json hex 2>/dev/null | " +
      "  python3 -c \"import sys,json; d=json.JSONDecoder(); obj,_=d.raw_decode(sys.stdin.read()); print(json.dumps(obj))\" " +
      "  > /tmp/matugen-colors.json; " +
      "fi"
    ]
    running: true
  }

  IpcHandler {
    target: "toggleWalls"
    function handle() { root.wallsOpen = !root.wallsOpen }
  }


  Walls {
    id: walls
    open: root.wallsOpen
    currentIndex: root.currentWallIndex
    onCurrentIndexChanged: root.currentWallIndex = walls.currentIndex
    onCloseRequested: root.wallsOpen = false
  }

}
