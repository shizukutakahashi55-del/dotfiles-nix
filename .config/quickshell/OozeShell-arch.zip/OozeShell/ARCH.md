# OozeShell en Arch Linux

Esta es la versión nueva de OozeShell adaptada de NixOS a Arch.

## Qué cambió respecto al original (NixOS)

| Área | Original | Arch |
|---|---|---|
| Buscador de paquetes | `NixSearch/` (nix-search, `nix shell`) | `PACSEARCH/` (paru o pacman + AUR) |
| IPC | `call -- nixsearch toggle` | `call -- pacsearch toggle` |
| `shell.qml` | `nixSearchOpen`, `nixStartQuery`, `gateNix` | `pacSearchOpen`, `pacStartQuery`, `gatePac` |
| Idiomas | claves `nix*` | claves `pac*` (Id/Ja caen al inglés) |
| `powerprofilesctl` | fallback `/run/current-system/...` | fallback `/usr/bin/powerprofilesctl` |
| Fuentes | `fonts.nix.example` | `tools/fonts/install-arch.sh` |

El resto (barra, dock, dashboard, CoOzey, lock screen, agenda, ajustes) es idéntico a la versión nueva.
Se dejaron fuera los `*.bak`, `*.pre-opti` y `LANG/languages/qmldir.txt`.

## Instalación

La ruta importa: `OozeAudio/data/AudioService.qml` usa `~/.config/quickshell/OozeShell/...`.

    mkdir -p ~/.config/quickshell
    cp -r OozeShell ~/.config/quickshell/
    bash ~/.config/quickshell/OozeShell/tools/fonts/install-arch.sh
    bash ~/.config/quickshell/OozeShell/tools/check.sh
    quickshell -c OozeShell

## Dependencias (referencia; verifica nombres con `pacman -Ss`)

Núcleo: `quickshell`, `hyprland`, `pipewire` + `wireplumber` (wpctl, pw-dump, pw-link), `networkmanager`,
`bluez` + `bluez-utils`, `brightnessctl`, `power-profiles-daemon`, `upower`, `libnotify`, `wl-clipboard`,
`grim` + `slurp`, `playerctl`, `jq`, `xdg-utils`, `foot` (terminal por defecto).

Según lo que uses: `matugen` (colores del wallpaper), `cava` (visualizador), `awww` (wallpapers;
antes `swww`), `mpvpaper` + `ffmpeg` (wallpapers en vivo), `hyprshutdown` (apagado limpio), `paru`
(PacSearch con AUR; sin él usa `pacman` a secas, sin AUR).

## Fuentes

Iconos (obligatoria): las instala `install-arch.sh`.
Texto pixel (opcional): descarga Pixelify Sans (y DotGothic16 para japonés) desde Google Fonts y copia
el `.ttf` a `~/.local/share/fonts/` (luego `fc-cache -f`) o directamente a `assets/fonts/PixelFont.ttf`.
Sin fuente pixel se usa Varela Round, que ya viene incluida.

## Atajo de teclado (Hyprland)

    bind = SUPER, U, exec, quickshell ipc -p ~/.config/quickshell/OozeShell/shell.qml call -- pacsearch toggle
