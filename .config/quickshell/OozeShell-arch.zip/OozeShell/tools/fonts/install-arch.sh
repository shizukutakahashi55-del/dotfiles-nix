#!/usr/bin/env bash
# Instala las fuentes de iconos (obligatorias) y la config de fontconfig.
# La fuente pixel de texto es opcional: ver ARCH.md → Fuentes.
set -e
sudo pacman -S --needed ttf-jetbrains-mono-nerd ttf-nerd-fonts-symbols-mono
mkdir -p ~/.config/fontconfig/conf.d
cp "$(dirname "$0")/99-oozeshell-pixel.conf" ~/.config/fontconfig/conf.d/
fc-cache -f
echo "Listo. Reinicia quickshell para que lea las fuentes nuevas."
