// DashboardMpris.qml — DASHBOARD

import QtQuick
import QtQuick.Layouts
import QtQuick.Effects
import "../../COMMON"
import "../../Services/Lang"
import "../../Services/Mpris"


Item {
    id: root
    readonly property int preferredWidth: Theme.ds(460)
    readonly property bool hasPlayer: MprisBackend.activePlayers.length > 0
    readonly property bool playing: MprisBackend.currentStatus === "Playing"
    readonly property bool hasArt: Theme.cozy ? coverImg.status === Image.Ready : mdCover.ready

    function withAlpha(c, a) { return Qt.rgba(c.r, c.g, c.b, a) }

    // ── Teclado ──
    function seekBy(secs) {
        if (MprisBackend.currentLength <= 0) return
        const to = Math.max(0, Math.min(MprisBackend.currentLength / 1000000,
                                        MprisBackend.currentPosition / 1000000 + secs))
        MprisBackend.runCtl(["position", to.toFixed(2)])
    }

    function handleKey(key, modifiers) {
        const shift = (modifiers & Qt.ShiftModifier) !== 0
        if (key === Qt.Key_Space || key === Qt.Key_Return || key === Qt.Key_Enter) {
            MprisBackend.runCtl(["play-pause"]); return true
        }
        if (key === Qt.Key_N || (shift && key === Qt.Key_Right)) { MprisBackend.runCtl(["next"]); return true }
        if (key === Qt.Key_P || (shift && key === Qt.Key_Left)) { MprisBackend.runCtl(["previous"]); return true }
        if (key === Qt.Key_Period) { root.seekBy(5); return true }
        if (key === Qt.Key_Comma) { root.seekBy(-5); return true }
        if (key === Qt.Key_Up) { MprisBackend.selectPlayer(MprisBackend.activePlayerIndex - 1); return true }
        if (key === Qt.Key_Down) { MprisBackend.selectPlayer(MprisBackend.activePlayerIndex + 1); return true }
        return false
    }

    // ── Vida útil: solo sondea/escucha mientras esta sección existe ──
    Component.onCompleted: {
        MprisBackend.setWanted("dashboard", true)
    }
    Component.onDestruction: {
        MprisBackend.setWanted("dashboard", false)
    }

    // ── Seek ────────────────────────────────────────────────────
    property bool seeking: false
    property real seekRatio: 0
    readonly property real shownRatio: root.seeking ? root.seekRatio : MprisBackend.progressRatio
    readonly property real shownPosition: root.seeking
        ? Math.round(root.seekRatio * MprisBackend.currentLength) : MprisBackend.currentPosition


    Item {
        id: card
        anchors.fill: parent
        anchors.margins: Theme.ds(10)

        // ── Fondo sin reproducción ─────────────────────────────
        SkinRect {
            anchors.fill: parent
            visible: !root.hasPlayer
            radius: Theme.ds(18)
            notch: 4
            color: Theme.surface
        }

        // ── Sin reproducción ───────────────────────────────────
        ColumnLayout {
            anchors.centerIn: parent
            anchors.verticalCenterOffset: -14
            visible: !root.hasPlayer
            spacing: Theme.ds(10)

            Item {
                Layout.alignment: Qt.AlignHCenter
                Layout.preferredWidth: Theme.ds(84)
                Layout.preferredHeight: Theme.ds(84)
                Rectangle {
                    anchors.centerIn: parent
                    width: Theme.ds(84); height: Theme.ds(84); radius: Theme.cozy ? 4 : Theme.ds(42)
                    color: "transparent"
                    border.width: 2
                    border.color: root.withAlpha(Theme.primary, 0.14)
                }
                Rectangle {
                    anchors.centerIn: parent
                    width: Theme.ds(62); height: Theme.ds(62); radius: Theme.cozy ? 4 : Theme.ds(31)
                    color: root.withAlpha(Theme.primary, 0.14)
                    border.width: Theme.bw1
                    border.color: Theme.cozy ? Theme.ink : root.withAlpha(Theme.primary, 0.40)
                    Text {
                        anchors.centerIn: parent
                        text: "󰝚"
                        color: Theme.primary
                        font.pixelSize: Theme.dfs(28)
                        font.family: Theme.monoFamily
                    }
                }
            }
            Text {
                Layout.alignment: Qt.AlignHCenter
                text: Translations.t("mprisNoPlaying")
                color: Theme.text
                font.pixelSize: Theme.dfs(14)
                font.bold: true
                font.family: Theme.fontFamily
            }
        }

        // ── Reproduciendo ──────────────────────────────────────
        RowLayout {
            anchors.fill: parent
            anchors.margins: Theme.ds(10)
            spacing: Theme.ds(10)
            visible: root.hasPlayer

            SkinRect {
                Layout.fillWidth: true
                Layout.fillHeight: true
                radius: Theme.cozy ? Theme.ds(18) : MdTokens.rXl
                notch: 4
                color: Theme.cozy ? Theme.surface : MdTokens.container

                ColumnLayout {
                    anchors.fill: parent
                    anchors.margins: Theme.ds(14)
                    spacing: Theme.ds(12)

                    RowLayout {
                        Layout.fillWidth: true
                        Layout.fillHeight: true
                        spacing: Theme.ds(16)


                        Item {
                            visible: !Theme.cozy
                            Layout.preferredWidth: Theme.ds(146)
                            Layout.preferredHeight: Theme.ds(146)
                            Layout.alignment: Qt.AlignVCenter

                            MdCover {
                                id: mdCover
                                anchors.fill: parent
                                source: MprisBackend.currentArt
                                shape: "square"
                                decodeSize: 292
                                scale: mdMouse.pressed ? 0.96 : (mdMouse.containsMouse ? 1.03 : 1.0)
                                Behavior on scale { NumberAnimation { duration: Theme.animDuration(160); easing.type: Easing.OutBack } }
                            }

                            MdShape {
                                anchors.fill: parent
                                shape: "square"
                                color: root.withAlpha(Theme.bg, 0.5)
                                opacity: mdMouse.containsMouse ? 1 : 0
                                Behavior on opacity { NumberAnimation { duration: Theme.animDuration(160) } }

                                Text {
                                    anchors.centerIn: parent
                                    text: root.playing ? "󰏤" : "󰐊"
                                    color: Theme.text
                                    font.pixelSize: Theme.dfs(34)
                                    font.family: Theme.monoFamily
                                }
                            }

                            MouseArea {
                                id: mdMouse
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: MprisBackend.runCtl(["play-pause"])
                            }
                        }

                        Item {
                            visible: Theme.cozy
                            Layout.preferredWidth: Theme.ds(136)
                            Layout.preferredHeight: Theme.ds(136)
                            Layout.alignment: Qt.AlignVCenter


                            Rectangle {
                                visible: Theme.cozy
                                x: 3; y: 5
                                width: parent.width; height: parent.height
                                radius: 3
                                color: Theme.shadowInk
                            }
                            Rectangle {
                                id: halo
                                anchors.centerIn: parent
                                width: Theme.ds(150); height: Theme.ds(150); radius: Theme.cozy ? 4 : Theme.ds(26)
                                color: root.withAlpha(Theme.primary, root.playing ? 0.20 : 0.07)
                                Behavior on color { ColorAnimation { duration: Theme.animDuration(300) } }
                                SequentialAnimation on opacity {
                                    running: root.playing && Theme.uiAnimationsEnabled
                                    loops: Animation.Infinite
                                    NumberAnimation { from: 0.5; to: 1.0; duration: Theme.animDuration(1100); easing.type: Easing.InOutSine }
                                    NumberAnimation { from: 1.0; to: 0.5; duration: Theme.animDuration(1100); easing.type: Easing.InOutSine }
                                    onRunningChanged: if (!running) halo.opacity = 1
                                }
                            }

                            Item {
                                id: coverBox
                                anchors.fill: parent
                                scale: Theme.cozy ? 1.0 : (coverMouse.pressed ? 0.97 : (coverMouse.containsMouse ? 1.02 : 1.0))
                                Behavior on scale { NumberAnimation { duration: Theme.animDuration(160); easing.type: Easing.OutBack } }
                                layer.enabled: !Theme.shellPerf
                                layer.effect: MultiEffect {
                                    maskEnabled: true
                                    maskSource: coverMask
                                    maskThresholdMin: 0.5
                                    maskSpreadAtMin: 1.0
                                }
                                Rectangle {
                                    anchors.fill: parent
                                    gradient: Gradient {
                                        GradientStop { position: 0.0; color: root.withAlpha(Theme.primary, 0.35) }
                                        GradientStop { position: 1.0; color: Theme.surface }
                                    }
                                }
                                Text {
                                    anchors.centerIn: parent
                                    visible: !root.hasArt
                                    text: "󰎆"
                                    color: Theme.primary
                                    font.pixelSize: Theme.dfs(48)
                                    font.family: Theme.monoFamily
                                }
                                Image {
                                    id: coverImg
                                    anchors.fill: parent
                                    source: Theme.cozy ? MprisBackend.currentArt : ""
                                    fillMode: Image.PreserveAspectCrop
                                    visible: root.hasArt
                                    asynchronous: true


                                    sourceSize: Qt.size(272, 272)
                                }

                                Rectangle {
                                    anchors.fill: parent
                                    color: root.withAlpha(Theme.bg, 0.45)
                                    opacity: coverMouse.containsMouse ? 1 : 0
                                    Behavior on opacity { NumberAnimation { duration: Theme.animDuration(160) } }
                                    Text {
                                        anchors.centerIn: parent
                                        text: root.playing ? "󰏤" : "󰐊"
                                        color: Theme.text
                                        font.pixelSize: Theme.dfs(34)
                                        font.family: Theme.monoFamily
                                    }
                                }
                            }
                            Item {
                                id: coverMask
                                anchors.fill: parent
                                layer.enabled: !Theme.shellPerf
                                visible: false
                                Rectangle { anchors.fill: parent; radius: Theme.cozy ? 3 : Theme.ds(18); color: "black" }
                            }
                            Rectangle {
                                anchors.fill: parent
                                radius: Theme.cozy ? 3 : Theme.ds(18)
                                color: "transparent"
                                border.width: Theme.cozy ? 3 : 1.5
                                border.color: Theme.cozy ? Theme.ink : root.withAlpha(Theme.primary, root.playing ? 0.55 : 0.28)
                                Behavior on border.color { ColorAnimation { duration: Theme.animDuration(300) } }
                            }
                            MouseArea {
                                id: coverMouse
                                anchors.fill: parent
                                hoverEnabled: true
                                cursorShape: Qt.PointingHandCursor
                                onClicked: MprisBackend.runCtl(["play-pause"])
                            }
                        }

                        ColumnLayout {
                            Layout.fillWidth: true
                            Layout.fillHeight: true
                            spacing: Theme.ds(5)


                            RowLayout {
                                Layout.fillWidth: true
                                spacing: Theme.ds(7)

                                Rectangle {
                                    id: liveDot
                                    Layout.preferredWidth: Theme.ds(7)
                                    Layout.preferredHeight: Theme.ds(7)
                                    radius: Theme.cozy ? 0 : Theme.ds(3.5)
                                    color: Theme.primary
                                    opacity: root.playing ? 1 : 0.35
                                    SequentialAnimation on opacity {
                                        running: root.playing && Theme.uiAnimationsEnabled
                                        loops: Animation.Infinite
                                        NumberAnimation { from: 1.0; to: 0.3; duration: Theme.animDuration(700); easing.type: Easing.InOutSine }
                                        NumberAnimation { from: 0.3; to: 1.0; duration: Theme.animDuration(700); easing.type: Easing.InOutSine }
                                        onRunningChanged: if (!running) liveDot.opacity = 0.35
                                    }
                                }
                                Text {
                                    text: Translations.t("mprisTitle")
                                    color: Theme.subtext
                                    font.pixelSize: Theme.dfs(9)
                                    font.letterSpacing: 1
                                    font.family: Theme.fontFamily
                                }

                                Item { Layout.fillWidth: true }


                                Rectangle {
                                    id: chip
                                    readonly property bool multi: MprisBackend.activePlayers.length > 1
                                    radius: Theme.cozy ? 4 : Theme.ds(10)
                                    implicitHeight: Theme.ds(22)
                                    implicitWidth: chipRow.implicitWidth + Theme.ds(16)
                                    color: chipMouse.containsMouse && chip.multi
                                        ? root.withAlpha(Theme.primary, 0.28) : root.withAlpha(Theme.primary, 0.14)
                                    border.width: Theme.bw1
                                    border.color: Theme.cozy ? Theme.ink : root.withAlpha(Theme.primary, 0.32)
                                    Behavior on color { ColorAnimation { duration: Theme.animDuration(150) } }

                                    RowLayout {
                                        id: chipRow
                                        anchors.centerIn: parent
                                        spacing: Theme.ds(5)
                                        Text {
                                            text: {
                                                void MprisBackend.activePlayers
                                                void MprisBackend.activePlayerIndex
                                                return MprisBackend.playerIcon(MprisBackend.currentPlayer())
                                            }
                                            color: Theme.primary
                                            font.pixelSize: Theme.dfs(11)
                                            font.family: Theme.fontFamily
                                        }
                                        Text {
                                            text: {
                                                void MprisBackend.activePlayers
                                                void MprisBackend.activePlayerIndex
                                                return MprisBackend.cleanPlayerName(MprisBackend.currentPlayer())
                                                    + (chip.multi ? "  " + (MprisBackend.activePlayerIndex + 1)
                                                                    + "/" + MprisBackend.activePlayers.length : "")
                                            }
                                            color: Theme.primary
                                            font.pixelSize: Theme.dfs(9)
                                            font.bold: true
                                            font.family: Theme.fontFamily
                                        }
                                    }
                                    MouseArea {
                                        id: chipMouse
                                        anchors.fill: parent
                                        hoverEnabled: true
                                        enabled: chip.multi
                                        cursorShape: chip.multi ? Qt.PointingHandCursor : Qt.ArrowCursor
                                        onClicked: MprisBackend.selectPlayer(MprisBackend.activePlayerIndex + 1)
                                    }
                                }
                            }

                            Item { Layout.fillHeight: true; Layout.minimumHeight: Theme.ds(2) }


                            Text {
                                Layout.fillWidth: true
                                text: MprisBackend.currentTitle !== "" ? MprisBackend.currentTitle
                                                                       : Translations.t("mprisNoPlaying")
                                color: Theme.text
                                font.pixelSize: Theme.dfs(17)
                                font.bold: true
                                font.family: Theme.fontFamily
                                elide: Text.ElideRight
                            }
                            RowLayout {
                                Layout.fillWidth: true
                                spacing: Theme.ds(6)
                                visible: MprisBackend.currentArtist !== ""
                                Text {
                                    text: "󰠃"
                                    color: Theme.primary
                                    font.pixelSize: Theme.dfs(12)
                                    font.family: Theme.monoFamily
                                }
                                Text {
                                    Layout.fillWidth: true
                                    text: MprisBackend.currentArtist
                                    color: Theme.subtext
                                    font.pixelSize: Theme.dfs(12)
                                    font.family: Theme.fontFamily
                                    elide: Text.ElideRight
                                }
                            }


                            Item {
                                id: progress
                                Layout.fillWidth: true
                                Layout.preferredHeight: Theme.ds(22)
                                Layout.topMargin: 2

                                PixelBar {
                                    visible: Theme.cozy
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: parent.width
                                    height: Theme.ds(14)
                                    ratio: root.shownRatio
                                    cell: Theme.ds(6)
                                    gap: 2
                                }
                                MdWavy {
                                    id: wavy
                                    visible: !Theme.cozy
                                    anchors.verticalCenter: parent.verticalCenter
                                    width: parent.width
                                    value: root.shownRatio
                                    playing: root.playing
                                    reactive: true
                                    handle: MprisBackend.currentLength > 0
                                    amplitude: seekMouse.containsMouse || root.seeking ? 4 : 3.2
                                    wavelength: 24
                                    thickness: 4.5
                                    Behavior on amplitude { NumberAnimation { duration: Theme.animDuration(160) } }
                                }

                                MouseArea {
                                    id: seekMouse
                                    anchors.fill: parent
                                    hoverEnabled: true
                                    enabled: MprisBackend.currentLength > 0
                                    cursorShape: Qt.PointingHandCursor
                                    function ratioAt(x) { return Math.max(0, Math.min(1, x / width)) }
                                    onPressed: mouse => { root.seeking = true; root.seekRatio = ratioAt(mouse.x) }
                                    onPositionChanged: mouse => { if (pressed) root.seekRatio = ratioAt(mouse.x) }
                                    onReleased: {
                                        const secs = (root.seekRatio * MprisBackend.currentLength / 1000000).toFixed(2)
                                        MprisBackend.runCtl(["position", secs])
                                        root.seeking = false
                                    }
                                    onCanceled: root.seeking = false
                                }
                            }
                            RowLayout {
                                Layout.fillWidth: true
                                Text {
                                    text: MprisBackend.formatTime(root.shownPosition)
                                    color: Theme.subtext; font.pixelSize: Theme.dfs(9)
                                    font.family: Theme.fontFamily
                                }
                                Item { Layout.fillWidth: true }
                                Text {
                                    text: MprisBackend.formatTime(MprisBackend.currentLength)
                                    color: Theme.subtext; font.pixelSize: Theme.dfs(9)
                                    font.family: Theme.fontFamily
                                }
                            }


                            RowLayout {
                                Layout.alignment: Qt.AlignHCenter
                                spacing: Theme.ds(14)

                                component Ctl: MdIconButton {
                                    property bool big: false
                                    visible: !Theme.cozy
                                    Layout.alignment: Qt.AlignVCenter
                                    size: big ? Theme.ds(54) : Theme.ds(42)
                                    variant: big ? "filled" : "tonal"
                                    checkable: big
                                    toggled: root.playing
                                    glyphSize: Theme.dfs(big ? 22 : 17)
                                }

                                Ctl { glyph: "󰒮"; onClicked: MprisBackend.runCtl(["previous"]) }
                                Ctl {
                                    big: true
                                    glyph: root.playing ? "󰏤" : "󰐊"
                                    onClicked: MprisBackend.runCtl(["play-pause"])
                                }
                                Ctl { glyph: "󰒭"; onClicked: MprisBackend.runCtl(["next"]) }


                                component CCtl: CozyButton {
                                    id: cc
                                    property string glyph: ""
                                    property bool big: false
                                    visible: Theme.cozy
                                    Layout.preferredWidth: big ? Theme.ds(56) : Theme.ds(42)
                                    Layout.preferredHeight: (big ? Theme.ds(46) : Theme.ds(36)) + depth
                                    Layout.alignment: Qt.AlignVCenter
                                    face: big ? Theme.primary : Theme.surface
                                    faceHover: big ? Theme.mix(Theme.primary, "#ffffff", 0.18) : Theme.surfaceHigh
                                    active: big
                                    Text {
                                        anchors.centerIn: parent
                                        text: cc.glyph
                                        color: cc.big ? Theme.textOnPrimary : Theme.text
                                        font.pixelSize: Theme.dfs(cc.big ? 20 : 15)
                                        font.family: Theme.monoFamily
                                    }
                                }
                                CCtl { glyph: "󰒮"; onClicked: MprisBackend.runCtl(["previous"]) }
                                CCtl {
                                    big: true
                                    glyph: root.playing ? "󰏤" : "󰐊"
                                    onClicked: MprisBackend.runCtl(["play-pause"])
                                }
                                CCtl { glyph: "󰒭"; onClicked: MprisBackend.runCtl(["next"]) }
                            }

                            Item { Layout.fillHeight: true; Layout.minimumHeight: Theme.ds(2) }
                        }
                    }
                }
            }

            SkinRect {
                Layout.preferredWidth: Theme.ds(44)
                Layout.fillHeight: true
                radius: Theme.cozy ? Theme.ds(14) : MdTokens.rXl
                notch: 3
                color: Theme.cozy ? Theme.surface : MdTokens.container

                MprisVolume {
                    anchors.fill: parent
                    anchors.margins: Theme.ds(8)
                    vertical: true
                }
            }
        }
    }
}
