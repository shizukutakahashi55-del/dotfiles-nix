//
//   quickshell ipc -p .../shell.qml call -- screenshot areaCopy
//   quickshell ipc -p .../shell.qml call -- screenshot fullSave
//   quickshell ipc -p .../shell.qml call -- screenshot areaSave
//
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Io
import "../COMMON"
import "../LANG"

QtObject {
  id: root

  // Grosor del marco de selección, en píxeles lógicos de slurp.
  property int borderWidth: 2

  property real backgroundOpacity: 0.1

  property real settleDelay: 0.3

  // ─── Color del tema → formato que espera slurp (-b / -c / -s: RRGGBBAA) ──
  function toHex8(c, alpha) {
    const h = v => Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16).padStart(2, "0")
    return h(c.r) + h(c.g) + h(c.b) + h(alpha === undefined ? c.a : alpha)
  }

  // Carpeta de destino de las capturas guardadas: $XDG_PICTURES_DIR/Screenshots
  // si `xdg-user-dir` está disponible, si no $HOME/Pictures/Screenshots. Se
  // crea sola si todavía no existe.
  readonly property string dirExpr:
    'd="$(xdg-user-dir PICTURES 2>/dev/null)"; [ -z "$d" ] && d="$HOME/Pictures"; ' +
    'd="$d/Screenshots"; mkdir -p "$d" 2>/dev/null; printf %s "$d"'

  function run(script, args) {
    Quickshell.execDetached(["sh", "-c", script, "sh"].concat(args ?? []))
  }

  // ─── Selección de área → portapapeles ────────────────────────────
  function areaCopy() {
    const border = root.toHex8(Theme.primary, 1)
    const bg = root.toHex8(Theme.primary, root.backgroundOpacity)
    root.run(
      'command -v slurp >/dev/null 2>&1 && command -v grim >/dev/null 2>&1 && command -v wl-copy >/dev/null 2>&1 || ' +
      '{ notify-send -u critical -a OozeShell "$1" "$4"; exit 127; }; ' +
      'geo="$(slurp -c ' + border + ' -w ' + root.borderWidth + ' -b ' + bg + ' -s 00000000)"; ' +
      '[ -z "$geo" ] && exit 0; ' +
      'sleep ' + root.settleDelay + '; ' +
      'grim -g "$geo" - | wl-copy; s=$?; ' +
      'if [ "$s" -eq 0 ]; then notify-send -a OozeShell "$1" "$2"; ' +
      'else notify-send -u critical -a OozeShell "$1" "$3"; fi',
      [Translations.t("scrTitle"), Translations.t("scrCopied"),
       Translations.t("scrCopyFailed"), Translations.t("scrMissingCopy")]
    )
  }

  // ─── Pantalla completa → directorio ──────────────────────────────
  function fullSave() {
    root.run(
      'command -v grim >/dev/null 2>&1 || { notify-send -u critical -a OozeShell "$1" "$3"; exit 127; }; ' +
      'd="$(' + root.dirExpr + ')"; ' +
      'f="$d/Screenshot_$(date +%Y-%m-%d_%H-%M-%S).png"; ' +
      'grim "$f"; s=$?; ' +
      'if [ "$s" -eq 0 ]; then notify-send -a OozeShell "$1" "$f"; ' +
      'else notify-send -u critical -a OozeShell "$1" "$2"; fi',
      [Translations.t("scrTitle"), Translations.t("scrSaveFailed"), Translations.t("scrMissingFull")]
    )
  }

  // ─── Selección de área → directorio ──────────────────────────────
  function areaSave() {
    const border = root.toHex8(Theme.primary, 1)
    const bg = root.toHex8(Theme.primary, root.backgroundOpacity)
    root.run(
      'command -v slurp >/dev/null 2>&1 && command -v grim >/dev/null 2>&1 || ' +
      '{ notify-send -u critical -a OozeShell "$1" "$3"; exit 127; }; ' +
      'geo="$(slurp -c ' + border + ' -w ' + root.borderWidth + ' -b ' + bg + ' -s 00000000)"; ' +
      '[ -z "$geo" ] && exit 0; ' +
      'sleep ' + root.settleDelay + '; ' +
      'd="$(' + root.dirExpr + ')"; ' +
      'f="$d/Screenshot_$(date +%Y-%m-%d_%H-%M-%S).png"; ' +
      'grim -g "$geo" "$f"; s=$?; ' +
      'if [ "$s" -eq 0 ]; then notify-send -a OozeShell "$1" "$f"; ' +
      'else notify-send -u critical -a OozeShell "$1" "$2"; fi',
      [Translations.t("scrTitle"), Translations.t("scrSaveFailed"), Translations.t("scrMissingArea")]
    )
  }
}
