// PanelHeader — encabezado común de los submenús que cuelgan del Menu
// (Apariencia / Monitor / Idioma): flecha ‹ para volver, ícono y título.
// Mismo aspecto que el encabezado de NetworkMenu.
//
// Uso:
//   PanelHeader {
//     Layout.fillWidth: true
//     icon: "󰗊"
//     title: Translations.t("chooseLanguage")
//     onBackRequested: root.backRequested()
//   }
import QtQuick
import QtQuick.Layouts
import "../COMMON"

RowLayout {
  id: root

  property string icon: ""
  property string title: ""
  signal backRequested()

  spacing: 10

  Rectangle {
    Layout.preferredWidth: 30
    Layout.preferredHeight: 30
    radius: 15
    color: backArea.containsMouse ? Theme.surfaceHigh : Theme.surface
    Behavior on color { ColorAnimation { duration: 120 } }

    Text {
      anchors.centerIn: parent
      text: "󰅁"
      color: Theme.text
      font.pixelSize: Theme.fs(16)
      font.family: "JetBrainsMono Nerd Font"
    }
    MouseArea {
      id: backArea
      anchors.fill: parent
      hoverEnabled: true
      cursorShape: Qt.PointingHandCursor
      onClicked: root.backRequested()
    }
  }

  Text {
    visible: root.icon !== ""
    text: root.icon
    color: Theme.primary
    font.pixelSize: Theme.fs(20)
    font.family: "JetBrainsMono Nerd Font"
  }

  Text {
    text: root.title
    color: Theme.text
    font.bold: true
    font.pixelSize: Theme.fs(16)
    font.family: "JetBrainsMono Nerd Font"
  }

  Item { Layout.fillWidth: true }
}
