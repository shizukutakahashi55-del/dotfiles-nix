// FusedWindow — ventana overlay para un popup que cuelga de la barra.
//
// Centraliza lo que antes estaba copiado (distinto) en Menu/Notify/Mpris:
//   • pantalla completa, transparente, capa Overlay
//   • clic afuera = cerrar. La franja de la barra queda LIBRE (mask), así
//     los botones de la barra (campana, ❄, reloj) siguen respondiendo
//     aunque haya un popup abierto.
//   • Esc = cerrar
//   • Cualquier otra tecla se reenvía por la señal keyPressed (para los
//     popups que se manejan con teclado, ej. el Overview). Con
//     exclusiveKeys: true la ventana toma el teclado apenas se abre, sin
//     esperar un clic (los atajos globales de Hyprland siguen funcionando).
//   • `active` decide si el popup captura input. Ponelo en
//     `open || panel.shown` para que la animación de cierre se vea entera.
//
// La ventana queda SIEMPRE montada (transparente y sin zona de clics
// mientras está cerrada), igual que la ventana del calendario. Antes se
// mostraba/ocultaba en cada apertura, y Hyprland le aplicaba su propia
// animación de layer (escala/fade): eso era el "spawn encima" y el
// corrimiento de 1-2px del panel.
//
// Modo Islas (Theme.islandsMode): las píldoras de la barra están en la capa
// Overlay y los popups nacen DE ellas (la tarjeta crece "detrás" de la isla,
// ver FusedPanel). Para que la isla quede siempre arriba del panel, esta
// ventana baja a la capa Top mientras haya islas; en fullscreen (`detached`,
// sin islas visibles) vuelve a Overlay para poder verse encima del juego.
// Además, con islas no hay franja de barra que dejar libre: cualquier clic
// fuera del panel lo cierra, y las islas (capa superior) igual reciben los suyos.
//
// Los hijos se colocan en un contenedor a pantalla completa; ahí va el
// FusedPanel, que se coloca solo según Theme.barPosition (ver FusedPanel).
import Quickshell
import Quickshell.Wayland
import QtQuick
import "../COMMON"

Item {
  id: root

  property bool active: false
  property string targetScreen: ""
  property string namespace: "oozeshell-popup"
  // true = mientras está abierta se queda con TODO el teclado (para popups
  // que se usan con teclas). false = solo lo toma al hacer clic.
  property bool exclusiveKeys: false
  signal closeRequested()
  // Tecla que no es Esc (key = Qt.Key_*, modifiers = Qt.*Modifier)
  signal keyPressed(int key, int modifiers, string text)

  // Hay islas y no estamos en fullscreen: esta ventana va en la capa Top
  readonly property bool onIslands: Theme.islandsMode && !root.detached

  readonly property real screenHeight: win.screen ? win.screen.height : 1080
  readonly property real screenWidth: win.screen ? win.screen.width : 1920

  default property alias content: host.data

  // La barra está oculta — por una ventana en fullscreen en esta pantalla, O
  // porque se está aplicando un wallpaper/esquema nuevo (Theme.wallpaperChanging,
  // ver Theme.qml) — así que el panel se dibuja flotante en vez de colgar de
  // ella (ver FusedPanel, "Modo flotante"). Lo lee el FusedPanel desde su
  // padre. Al terminar cualquiera de los dos (fullscreen o recarga de
  // wallpaper) vuelve solo a `false` y el panel se reengancha a la barra.
  readonly property bool detached: FullscreenState.isOn(win.screen) || Theme.wallpaperChanging

  PanelWindow {
    id: win

    screen: Quickshell.screens.find(s => s.name === root.targetScreen) ?? Quickshell.screens[0]
    visible: true
    color: "transparent"
    exclusiveZone: -1
    anchors { top: true; left: true; right: true; bottom: true }

    WlrLayershell.layer: root.onIslands ? WlrLayer.Top : WlrLayer.Overlay
    WlrLayershell.namespace: root.namespace
    // Cerrada no debe tocar el foco del teclado
    WlrLayershell.keyboardFocus: !root.active ? WlrKeyboardFocus.None
      : (root.exclusiveKeys ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.OnDemand)

    // Solo lo que está debajo de la barra captura input, y solo mientras
    // el popup está activo (cerrado: región vacía = todo click-through)
    mask: Region { item: backdrop }

    Connections {
      target: root
      function onActiveChanged() {
        if (root.active) keyCatcher.forceActiveFocus()
      }
    }

    Item {
      id: backdrop
      // La zona de "clic afuera" es todo MENOS la franja de la barra:
      //   arriba    → empieza debajo de ella
      //   abajo     → empieza en el borde de arriba y termina donde arranca la barra
      //   izquierda → empieza a la derecha de ella
      //   derecha   → empieza en el borde izquierdo y termina donde arranca la barra
      // (Con islas: pantalla completa; las islas quedan encima y responden solas)
      x: (Theme.barVertical && !Theme.barAtRight && !root.onIslands) ? Theme.barOffset : 0
      y: (!Theme.barVertical && !Theme.barAtBottom && !root.onIslands) ? Theme.barOffset : 0
      width: root.active ? (Theme.barVertical ? parent.width - Theme.barOffset : parent.width) : 0
      height: root.active
        ? (Theme.barVertical ? parent.height
                             : (root.onIslands ? parent.height : parent.height - Theme.barOffset))
        : 0

      MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.AllButtons
        onClicked: root.closeRequested()
      }
    }

    Item {
      id: host
      anchors.fill: parent
      // FusedPanel lee esto de su padre
      readonly property bool detached: root.detached
      // FusedPanel lo lee para saber de qué isla (de qué pantalla) nace
      readonly property string screenName: win.screen ? win.screen.name : ""
    }

    Item {
      id: keyCatcher
      anchors.fill: parent
      focus: true
      Keys.onPressed: event => {
        if (event.key === Qt.Key_Escape) {
          root.closeRequested()
          event.accepted = true
        } else {
          root.keyPressed(event.key, event.modifiers, event.text)
        }
      }
    }
  }
}
