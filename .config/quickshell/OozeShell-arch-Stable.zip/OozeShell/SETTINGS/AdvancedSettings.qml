// AdvancedSettings — "Configuración avanzada", accesible desde
// Ajustes → General → Configuración avanzada.
//
// A diferencia del resto de los paneles de Ajustes (que cuelgan de la barra,
// chicos, con FusedWindow/FusedPanel), esta es una ventana grande y
// centrada en la pantalla, con una lista de categorías a la izquierda y el
// detalle de la elegida a la derecha — mismo patrón de PowerMenu.qml /
// ConfirmDialog.qml (PanelWindow propio, fondo oscurecido, Esc/clic afuera
// para cerrar), pero con una tarjeta bien grande en vez de una chica.
//
// Wiring en shell.qml (mismo patrón que BarSettings/LauncherSettings):
//   AdvancedSettings {
//     open: root.advancedSettingsOpen
//     targetScreen: root.focusedMonitor
//     onCloseRequested: root.advancedSettingsOpen = false
//     onBackRequested: root.swapTo("settings")
//   }
//
// Para sumar una categoría nueva más adelante: agregá una entrada a
// `root.categories` (icon + key) y su bloque de contenido (visible:
// root.category === N) dentro del Flickable, más abajo.
import Quickshell
import Quickshell.Wayland
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import QtQuick.Effects
import "../COMMON"
import "../LANG"
import "../APPEARANCE"
import "../OozeAudio/data"

Item {
  id: root

  property bool open: false
  property string targetScreen: ""
  property string namespace: "oozeshell-advanced-settings"

  signal closeRequested()
  signal backRequested()
  signal requestMonitorEditor()

  // ── Marco de pantalla (Interfaz) ──────────────────────────────
  // El ON/OFF es el mismo estado que el botón del Menú y el IPC
  // `corners toggle` (dueño: shell.qml → root.screenCorners): acá solo se
  // refleja y se puede tocar también, para tenerlo junto al estilo.
  property bool screenCorners: true
  signal requestCornersToggle()

  // ── Opciones de apariencia de Hyprland (gaps, bordes, blur, sombra) ──
  // Mismo trío de señales que APPEARANCE/Appearance.qml, para que
  // shell.qml pueda cablear esto exactamente igual (misma property
  // `appearance`, mismas funciones applyAppearanceLive/setAppearanceValue):
  // lo que se cambia acá se ve reflejado (y persiste) igual que desde el
  // panel rápido de Apariencia de la barra — es el mismo estado.
  property var appearanceValues: ({})
  signal appearancePreviewChanged(string key, real value)
  signal appearanceValueCommitted(string key, real value)
  signal appearanceToggleChanged(string key, bool value)

  // Sliders numéricos de Hyprland — mismos campos/rangos que
  // APPEARANCE/Appearance.qml (se duplica el spec a propósito: mismo
  // criterio que levelNames/sliderColors en otros paneles, cada archivo
  // se basta solo en vez de cruzar imports de datos entre paneles).
  readonly property var hyprSliderSpecs: [
    { key: "gapsIn",          label: "Gaps in",          min: 0,   max: 30,  step: 1,    dec: 0, def: 3   },
    { key: "gapsOut",         label: "Gaps out",         min: 0,   max: 60,  step: 1,    dec: 0, def: 6   },
    { key: "borderSize",      label: "Border size",      min: 0,   max: 10,  step: 1,    dec: 0, def: 2   },
    { key: "rounding",        label: "Rounding",         min: 0,   max: 30,  step: 1,    dec: 0, def: 10  },
    { key: "activeOpacity",   label: "Active opacity",   min: 0.2, max: 1.0, step: 0.01, dec: 2, def: 1.0 },
    { key: "inactiveOpacity", label: "Inactive opacity", min: 0.2, max: 1.0, step: 0.01, dec: 2, def: 1.0 },
    { key: "blurSize",        label: "Blur size",        min: 0,   max: 15,  step: 1,    dec: 0, def: 3   },
    { key: "blurPasses",      label: "Blur passes",      min: 0,   max: 5,   step: 1,    dec: 0, def: 1   },
    { key: "shadowRange",     label: "Shadow range",     min: 0,   max: 50,  step: 1,    dec: 0, def: 3   },
    { key: "shadowRenderPower", label: "Shadow power",   min: 1,   max: 4,   step: 1,    dec: 0, def: 1   }
  ]

  readonly property var hyprSliderColors: ({
    accent: Theme.primary,
    text: Theme.text,
    subtext: Theme.subtext,
    track: Theme.surfaceHigh
  })

  readonly property var hyprToggles: [
    { key: "blurEnabled",       label: Translations.t("appearanceBlur"),       def: true  },
    { key: "shadowEnabled",     label: Translations.t("appearanceShadow"),     def: false },
    { key: "animationsEnabled", label: Translations.t("appearanceAnimations"), def: true  }
  ]

  // 0 Apariencia · 1 Interfaz · 2 Servicios · 3 Audio · 4 Acerca de
  property int category: 0
  property string query: ""

  onOpenChanged: if (!root.open) { root.query = ""; searchInput.text = "" }

  readonly property var categories: [
    { icon: "󰏘", key: "advCatAppearance", idx: 0 },
    { icon: "󰍹", key: "advCatInterface", idx: 1 },
    { icon: "󰆍", key: "advCatServices", idx: 2 },
    { icon: "󰕾", key: "advCatAudio", idx: 3 },
    { icon: "󰋽", key: "advCatAbout", idx: 4 }
  ]

  // ── Tachidesk (server de manga/anime, manejado con el comando
  // `tachidesk {start,stop,status}` que ya existe en el sistema) ──
  // Mismo patrón que las acciones de NETWORK/NetworkBackend.qml: un
  // Process para consultar estado, otro para la acción, y un Timer que
  // refresca la salida mientras esta categoría está abierta.
  property string tachideskStatusText: ""
  property string tachideskLastUpdate: ""
  property string tachideskLastAction: ""
  property bool tachideskRunning: false
  property bool tachideskBusy: false
  property bool tachideskKnown: false

  // La salida de "tachidesk status" es la de systemctl: busca la línea
  // "Active: active (running)" / "Active: inactive (dead)".
  function tachideskParseActive(text) {
    const m = text.match(/Active:\s*(\S+)/)
    return m ? m[1] === "active" : false
  }

  function tachideskHtmlEscape(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  }

  // Coloreado línea por línea al estilo de una terminal real: no es
  // sintaxis de systemd completa, solo lo que hace que de un vistazo se
  // note si está corriendo, si hay un warning o un error.
  function tachideskFormatOutput(text) {
    if (text === "") return ""
    return text.split("\n").map(line => {
      const esc = root.tachideskHtmlEscape(line)
      if (/Active:\s*active/i.test(line))
        return "<font color=\"" + Theme.primary + "\"><b>" + esc + "</b></font>"
      if (/Active:\s*(inactive|failed)/i.test(line))
        return "<font color=\"" + Theme.error + "\"><b>" + esc + "</b></font>"
      if (/\berror\b/i.test(line))
        return "<font color=\"" + Theme.error + "\">" + esc + "</font>"
      if (/\bwarn(ing)?\b/i.test(line))
        return "<font color=\"#e0a95a\">" + esc + "</font>"
      if (/^\s*(Loaded|Docs|Main PID|Process|Tasks|Memory|CPU):/i.test(line))
        return "<font color=\"" + Theme.text + "\">" + esc + "</font>"
      return "<font color=\"" + Theme.subtext + "\">" + esc + "</font>"
    }).join("<br>")
  }

  function tachideskRefreshStatus() {
    if (!tachideskStatusProc.running) tachideskStatusProc.running = true
  }

  function tachideskRunAction(action) {
    root.tachideskLastAction = action
    root.tachideskBusy = true
    tachideskActionProc.running = false
    tachideskActionProc.action = action
    tachideskActionProc.running = true
  }

  Process {
    id: tachideskStatusProc
    command: ["tachidesk", "status"]
    running: false
    property var lines: []
    stdout: SplitParser { onRead: line => tachideskStatusProc.lines.push(line) }
    stderr: SplitParser { onRead: line => tachideskStatusProc.lines.push(line) }
    onRunningChanged: {
      if (running) { lines = []; return }
      const text = lines.join("\n")
      root.tachideskStatusText = text
      root.tachideskRunning = root.tachideskParseActive(text)
      root.tachideskKnown = true
      root.tachideskLastUpdate = Qt.formatTime(new Date(), "hh:mm:ss")
    }
  }

  Process {
    id: tachideskActionProc
    property string action: ""
    command: ["tachidesk", action]
    running: false
    onRunningChanged: {
      if (running) return
      root.tachideskBusy = false
      tachideskAfterActionTimer.restart()
    }
  }

  // Después de start/stop/restart, systemd tarda un pelo en reflejar el
  // nuevo estado — mismo margen que afterActionTimer en NetworkBackend.
  Timer { id: tachideskAfterActionTimer; interval: 500; repeat: false; onTriggered: root.tachideskRefreshStatus() }

  // Poll periódico, solo mientras el panel está abierto y parado en
  // "Servicios" (igual criterio que `watching` en NetworkBackend: no
  // interesa gastar procesos de fondo si nadie está mirando).
  Timer {
    interval: 3000
    repeat: true
    triggeredOnStart: true
    running: root.open && root.category === 2
    onTriggered: root.tachideskRefreshStatus()
  }

  // ── Acerca de: repos + info avanzada del sistema ─────────────────────
  readonly property var aboutRepos: [
    {
      icon: "󰆍",
      titleKey: "advAboutRepoDotfilesTitle",
      url: "https://github.com/shizukutakahashi55-del/dotfiles-nix"
    },
    {
      icon: "󱄅",
      titleKey: "advAboutRepoNixTitle",
      url: "https://github.com/shizukutakahashi55-del/nix-home"
    }
  ]
  property string aboutSysInfoText: ""
  property bool aboutSysInfoKnown: false
  // Colapsada por defecto: la sección se ve limpia de entrada, la info
  // avanzada queda a un click en vez de ocupar toda la pantalla.
  property bool aboutAdvancedOpen: false

  // Nuestra caja de texto (Text + RichText) no interpreta ANSI: un código
  // como "\x1b[90m" no pinta nada, queda como un cuadradito sin glifo.
  // Ya no dependemos de fastfetch, pero se deja como limpieza defensiva
  // por si algún comando de abajo llega a colar color en el futuro.
  function aboutStripAnsi(s) {
    return s.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, "")
  }

  // El backend imprime líneas planas "Clave: Valor" (sin terminal, sin
  // logo, sin colores) — se parsean acá para renderizarlas como filas
  // (mismo look que la tarjeta "SYSTEM" de la pestaña Usuario), en vez de
  // tirar todo como un bloque de texto tipo terminal.
  function aboutParseSysInfo(text) {
    if (text === "") return []
    return text.split("\n")
      .map(line => line.trim())
      .filter(line => line !== "")
      .map(line => {
        const idx = line.indexOf(": ")
        if (idx === -1) return { key: line, value: "" }
        return { key: line.slice(0, idx).trim(), value: line.slice(idx + 2).trim() }
      })
      .filter(row => row.value !== "")
  }

  readonly property var aboutSysInfoRows: root.aboutParseSysInfo(root.aboutSysInfoText)

  // Ícono por tipo de dato (heurística por palabra clave — el backend
  // reporta más o menos campos según la máquina, así que esto no depende
  // de una lista fija).
  function aboutIconFor(key) {
    const k = key.toLowerCase()
    if (k.includes("host")) return "󰍹"
    if (k === "os" || k.includes("operating")) return "󰌽"
    if (k.includes("kernel")) return "󰣇"
    if (k.includes("uptime")) return "󱑂"
    if (k.includes("package") || k.includes("pkgs")) return "󰏖"
    if (k.includes("shell")) return "󱆃"
    if (k === "de" || k.includes("desktop")) return "󰧨"
    if (k === "wm" || k.includes("window manager")) return "󱂬"
    if (k.includes("cpu") || k.includes("processor")) return "󰘚"
    if (k.includes("gpu")) return "󰢮"
    if (k.includes("memory") || k.includes("ram")) return "󰍛"
    if (k.includes("disk")) return "󰋊"
    if (k.includes("resolution") || k.includes("display") || k.includes("monitor")) return "󰍹"
    if (k.includes("terminal")) return "󰆍"
    if (k.includes("battery")) return "󰁹"
    if (k.includes("ip")) return "󰩟"
    if (k.includes("locale")) return "󰗊"
    return "󰋽"
  }

  function aboutRefreshSysInfo() {
    if (!aboutSysInfoProc.running) aboutSysInfoProc.running = true
  }

  Process {
    id: aboutSysInfoProc
    // Sin fastfetch (no siempre está instalado -- por eso la caja decía
    // "Couldn't read system information"): comandos estándar de
    // Linux/systemd/Hyprland ya presentes en cualquier NixOS, cada uno
    // imprimiendo su propia línea "Clave: Valor" en texto plano. Cada
    // sección tiene su propio guard (command -v / [ -n ]), así que si
    // algo no aplica en esta máquina (por ej. no hay batería) esa línea
    // simplemente no sale, en vez de romper el resto.
    command: ["bash", "-c", "echo \"Host: $(hostname)\"\n. /etc/os-release 2>/dev/null\necho \"OS: ${PRETTY_NAME:-${NAME:-Linux}}\"\necho \"Kernel: $(uname -r)\"\nread -r up _ < /proc/uptime\ns=${up%.*}\nd=$((s/86400)); h=$((s%86400/3600)); m=$((s%3600/60))\nif [ \"$d\" -gt 0 ]; then echo \"Uptime: ${d}d ${h}h ${m}m\"\nelif [ \"$h\" -gt 0 ]; then echo \"Uptime: ${h}h ${m}m\"\nelse echo \"Uptime: ${m}m\"\nfi\necho \"Shell: $(basename \"${SHELL:-sh}\")\"\ndesktop=\"${XDG_CURRENT_DESKTOP:-${DESKTOP_SESSION:-}}\"\n[ -n \"${HYPRLAND_INSTANCE_SIGNATURE:-}\" ] && desktop=\"Hyprland\"\n[ -n \"$desktop\" ] && echo \"Desktop: $desktop\"\ncpu_model=$(grep -m1 'model name' /proc/cpuinfo 2>/dev/null | cut -d: -f2 | sed 's/^ *//')\ncores=$(nproc 2>/dev/null)\nif [ -n \"$cpu_model\" ]; then\n  if [ -n \"$cores\" ]; then echo \"CPU: $cpu_model ($cores)\"\n  else echo \"CPU: $cpu_model\"\n  fi\nfi\nif command -v lspci >/dev/null 2>&1; then\n  gpu=$(lspci -mm 2>/dev/null | grep -Ei 'vga|3d|display' | head -n1 | sed -E 's/^[^\"]*\"[^\"]*\"[[:space:]]*\"[^\"]*\"[[:space:]]*\"([^\"]*)\"[[:space:]]*\"([^\"]*)\".*/\\1 \\2/')\n  [ -n \"$gpu\" ] && echo \"GPU: $gpu\"\nfi\nif command -v free >/dev/null 2>&1; then\n  mem=$(free -h 2>/dev/null | awk '/^Mem:/ {print $3 \" / \" $2}')\n  [ -n \"$mem\" ] && echo \"Memory: $mem\"\nfi\ndisk=$(df -h / 2>/dev/null | awk 'NR==2 {print $3 \" / \" $2 \" (\" $5 \")\"}')\n[ -n \"$disk\" ] && echo \"Disk: $disk\"\nif command -v hyprctl >/dev/null 2>&1; then\n  res=$(hyprctl monitors 2>/dev/null | awk '/^Monitor/ {getline; print $1}' | head -n1)\n  [ -n \"$res\" ] && echo \"Resolution: $res\"\nfi\nip=$(hostname -I 2>/dev/null | awk '{print $1}')\n[ -n \"$ip\" ] && echo \"Local IP: $ip\"\n[ -n \"${LANG:-}\" ] && echo \"Locale: $LANG\"\nif command -v upower >/dev/null 2>&1; then\n  bat=$(upower -e 2>/dev/null | grep -m1 BAT)\n  if [ -n \"$bat\" ]; then\n    pct=$(upower -i \"$bat\" 2>/dev/null | awk -F: '/percentage/ {gsub(/ /,\"\",$2); print $2}')\n    state=$(upower -i \"$bat\" 2>/dev/null | awk -F: '/state/ {gsub(/ /,\"\",$2); print $2}')\n    [ -n \"$pct\" ] && echo \"Battery: $pct ($state)\"\n  fi\nfi\n"]
    running: false
    property var lines: []
    stdout: SplitParser { onRead: line => aboutSysInfoProc.lines.push(line) }
    stderr: SplitParser { onRead: line => aboutSysInfoProc.lines.push(line) }
    onRunningChanged: {
      if (running) { lines = []; return }
      root.aboutSysInfoText = root.aboutStripAnsi(lines.join("\n"))
      root.aboutSysInfoKnown = true
    }
  }

  // Carga perezosa: recién quien abre el desplegable "Información avanzada"
  // dispara la consulta (ver toggle más abajo) — no tiene sentido correrla
  // solo por entrar a la pestaña "Acerca de".
  function aboutToggleAdvanced() {
    root.aboutAdvancedOpen = !root.aboutAdvancedOpen
    if (root.aboutAdvancedOpen && !root.aboutSysInfoKnown) root.aboutRefreshSysInfo()
  }

  // Ancho fijo de la barra lateral. Se probaron dos formas de calcularlo
  // solo (medido con TextMetrics primero, por implicitWidth después) y las
  // dos se rompieron en el motor QML de este setup — así que va fijo, sin
  // ningún cálculo dinámico de por medio. Si en algún idioma el texto más
  // largo no entra, subí este número a mano.
  readonly property real sidebarWidth: Math.max(160, sidebarMeasure.implicitWidth + 62)

  // Filtro simple: categorías cuyo nombre traducido matchea la búsqueda.
  // Si no hay coincidencias, el panel avisa en vez de quedar vacío sin más.
  function matches(key) {
    if (root.query.trim() === "") return true
    return Translations.t(key).toLowerCase().indexOf(root.query.trim().toLowerCase()) >= 0
  }
  readonly property var visibleCategories: root.categories.filter(c => root.matches(c.key))

  // Si la categoría activa queda oculta por el filtro, saltamos a la primera visible.
  // Se compara por `idx` (puesto a mano en cada entrada), NO por
  // `root.categories.indexOf(c)`: ese indexOf busca por IDENTIDAD del objeto
  // dentro del array, y `c` viene de `visibleCategories` (un `.filter()`
  // sobre `root.categories`). Si algo entre medio reevaluaba el binding de
  // `categories` (una lista de objetos literales; cada reevaluación crea
  // objetos NUEVOS, aunque el contenido sea igual), el indexOf ya no
  // encontraba ninguno (-1 para las tres), la condición `stillVisible`
  // daba `false` siempre, y `root.category` se reescribía todo el tiempo con
  // `root.categories.indexOf(root.visibleCategories[0])`, que TAMBIÉN daba
  // -1: `root.category` quedaba en -1. Ningún panel de la derecha coincide
  // con -1 → se ve vacío. Y en la fila, `catRow.catIndex` (mismo indexOf)
  // también daba -1 para las tres, así que `root.category === catIndex`
  // (-1 === -1) era CIERTO para las tres → las tres se ven "activas".
  onVisibleCategoriesChanged: {
    if (root.visibleCategories.length === 0) return
    const stillVisible = root.visibleCategories.some(c => c.idx === root.category)
    if (!stillVisible) root.category = root.visibleCategories[0].idx
  }

  // Ventana grande: ancho fijo generoso, no el cardWidth chico de los demás
  // paneles. Sigue respetando la escala de "Ventanas" (Ajustes → Interfaz)
  // Y, además, el ancho (solo el ancho — winH no lleva panelWidthScale)
  // respeta la 4ta perilla de acá abajo ("Ancho de paneles grandes").
  // Antes panelWidthScale no se usaba en ningún lado: mover el stepper
  // cambiaba Theme.panelWidthPercent pero ninguna ventana lo leía, así
  // que no pasaba nada visible.
  readonly property int winW: Math.round(920 * Theme.windowScale * Theme.panelWidthScale)
  readonly property int winH: Math.round(600 * Theme.windowScale)

  // Text oculto que mide el ancho del label más largo entre las categorías
// visibles. No se dibuja (visible: false, opacity: 0), solo presta su
// implicitWidth para calcular root.sidebarWidth.
Text {
  id: sidebarMeasure
  visible: false
  font.bold: true
  font.pixelSize: Theme.fs(12)
  font.family: "JetBrainsMono Nerd Font"
  text: {
    let longest = ""
    for (const c of root.visibleCategories) {
      const t = Translations.t(c.key)
      if (t.length > longest.length) longest = t
    }
    return longest
  }
}

  // Botón chico de acción (Iniciar/Detener/Refrescar) — mismo patrón que
  // el `component Btn` de SETTINGS/LauncherSettings.qml.
  component Btn: Rectangle {
    id: btn
    property string text: ""
    property string icon: ""
    property bool primary: false
    // `enabled` no se redeclara: ya es una propiedad nativa de Item/
    // Rectangle (default true) y al ponerla en false Qt Quick corta la
    // entrada del item y sus hijos solo — con eso alcanza.
    signal clicked()

    implicitHeight: 32
    implicitWidth: btnRow.implicitWidth + 22
    Layout.preferredHeight: 32
    Layout.preferredWidth: btnRow.implicitWidth + 22
    radius: 9
    opacity: btn.enabled ? 1 : 0.45
    color: btn.primary
      ? (btnArea.containsMouse ? Qt.lighter(Theme.primary, 1.12) : Theme.primary)
      : (btnArea.containsMouse ? Theme.surfaceHigh : Theme.surface)
    Behavior on color { ColorAnimation { duration: 150 } }

    scale: btnArea.pressed && btn.enabled ? 0.94 : 1.0
    Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }

    RowLayout {
      id: btnRow
      anchors.centerIn: parent
      spacing: 6
      Text {
        visible: btn.icon !== ""
        text: btn.icon
        color: btn.primary ? Theme.textOnPrimary : Theme.primary
        font.pixelSize: Theme.fs(13)
        font.family: "JetBrainsMono Nerd Font"
      }
      Text {
        text: btn.text
        color: btn.primary ? Theme.textOnPrimary : Theme.text
        font.pixelSize: Theme.fs(11)
        font.bold: true
        font.family: "JetBrainsMono Nerd Font"
      }
    }

    MouseArea {
      id: btnArea
      anchors.fill: parent
      hoverEnabled: true
      cursorShape: btn.enabled ? Qt.PointingHandCursor : Qt.ArrowCursor
      onClicked: if (btn.enabled) btn.clicked()
    }
  }

  // ── OozeAudio: mismo AudioService que la app standalone ────────────
  // No se reimplementa nada de PipeWire acá: se reusa el Singleton (mismo
  // backend/audio.sh) para que crear/borrar una salida virtual desde acá
  // sea IDÉNTICO a hacerlo desde la app OozeAudio suelta — un solo estado,
  // dos formas de llegar a él.
  property string oozeAudioNewName: ""
  // Nombre del output que se está por borrar (confirmación de 1 paso:
  // primer click en 🗑 arma esto, segundo click en el mismo botón borra).
  property string oozeAudioConfirmDelete: ""

  // AudioService ya hace su propio refreshAll() en Component.onCompleted,
  // pero eso pasa al arrancar quickshell entero, mucho antes de que exista
  // esta ventana: si alguien creó/borró una salida por consola mientras
  // tanto, la primera apertura de "Audio" mostraría datos viejos. Un
  // refresh más, la primera vez que se entra a esta categoría, alcanza
  // (mismo criterio que aboutRefreshSysInfo: perezoso, una sola vez).
  property bool oozeAudioRefreshedOnce: false

  // `root` ya tiene un onCategoryChanged (carga perezosa de Acerca de, más
  // arriba) — QML no permite un segundo onCategoryChanged en el mismo
  // objeto, así que esto va por Connections en vez de chocar con ese.
  Connections {
    target: root
    function onCategoryChanged() {
      if (root.category === 3 && !root.oozeAudioRefreshedOnce) {
        root.oozeAudioRefreshedOnce = true
        AudioService.refreshAll()
      }
      // Cambiar de categoría cancela cualquier confirmación de borrado pendiente
      root.oozeAudioConfirmDelete = ""
    }
  }

  property string oozeAudioError: ""
  Connections {
    target: AudioService
    function onCommandFailed(message) {
      root.oozeAudioError = message
      oozeAudioErrorTimer.restart()
    }
  }
  Timer { id: oozeAudioErrorTimer; interval: 5000; repeat: false; onTriggered: root.oozeAudioError = "" }

  // ── Abrir qpwgraph: patchbay completo de PipeWire para cuando el
  // editor simplificado de acá (o de OozeAudio suelta) se queda corto.
  // No usamos Quickshell.execDetached (fire-and-forget, sin feedback):
  // acá sí interesa avisar si el binario no está instalado.
  Process {
    id: qpwgraphProc
    command: ["bash", "-c", "command -v qpwgraph >/dev/null 2>&1 && exec qpwgraph || echo '__ooze_qpwgraph_missing__' >&2"]
    stderr: StdioCollector {
      id: qpwgraphErr
      onStreamFinished: {
        if (qpwgraphErr.text.indexOf("__ooze_qpwgraph_missing__") !== -1) {
          root.oozeAudioError = Translations.t("advAudioQpwgraphMissing")
          oozeAudioErrorTimer.restart()
        }
      }
    }
  }
  function openQpwgraph() {
    qpwgraphProc.running = false
    qpwgraphProc.running = true
  }

  // Una fila de audio: nombre + mute + volumen (0-150%), con borrar opcional
  // (solo para salidas virtuales — un sink de hardware no se borra).
  // Confirmación de un solo click extra: tocar 🗑 arma `confirmingDelete`
  // (mismo `nodeId` en root.oozeAudioConfirmDelete); un segundo click en el
  // MISMO botón, ahora rojo con ✓, borra de verdad. Cambiar de categoría o
  // tocar cualquier otra fila cancela la confirmación.
  component AudioRow: Rectangle {
    id: row
    property string nodeId: ""
    property string nodeName: ""
    property string title: ""
    property string subtitle: ""
    property int volume: 100
    property bool muted: false
    property bool deletable: false
    property bool confirmingDelete: false
    // Solo para salidas virtuales: chips para conectar/desconectar cada
    // salida física individualmente (así podés, por ejemplo, dejar una
    // salida sin sonido en tus parlantes pero igual capturable en OBS
    // vía "Monitor of <nombre>" — el monitor de PipeWire existe siempre,
    // esté o no conectada a algo).
    property bool showConnections: false
    signal volumeMoved(real v)
    signal muteToggled()
    signal deleteRequested()

    Layout.fillWidth: true
    implicitHeight: rowContent.implicitHeight + 20  
    radius: 10
    color: Theme.bg
    clip: true

    ColumnLayout {
    id: rowContent
    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 12 }
    spacing: 8

      RowLayout {
        Layout.fillWidth: true
        spacing: 10

        ColumnLayout {
          Layout.fillWidth: true
          spacing: 0
          Text {
            Layout.fillWidth: true
            elide: Text.ElideRight
            text: row.title
            color: Theme.text
            font.bold: true
            font.pixelSize: Theme.fs(12)
            font.family: "JetBrainsMono Nerd Font"
          }
          Text {
            visible: row.subtitle !== ""
            Layout.fillWidth: true
            elide: Text.ElideRight
            text: row.subtitle
            color: Theme.subtext
            font.pixelSize: Theme.fs(10)
            font.family: "JetBrainsMono Nerd Font"
          }
        }

        Rectangle {
          Layout.preferredWidth: 30
          Layout.preferredHeight: 26
          radius: 9
          color: row.muted ? Qt.rgba(Theme.error.r, Theme.error.g, Theme.error.b, 0.16)
               : (muteArea.containsMouse ? Theme.surfaceHigh : "transparent")
          Behavior on color { ColorAnimation { duration: 120 } }
          Text {
            anchors.centerIn: parent
            text: row.muted ? "󰝟" : "󰕾"
            color: row.muted ? Theme.error : Theme.subtext
            font.pixelSize: Theme.fs(13)
            font.family: "JetBrainsMono Nerd Font"
          }
          MouseArea {
            id: muteArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: row.muteToggled()
          }
        }

        Rectangle {
          visible: row.deletable
          Layout.preferredWidth: 30
          Layout.preferredHeight: 26
          radius: 9
          color: row.confirmingDelete
            ? Theme.error
            : (delArea.containsMouse ? Qt.rgba(Theme.error.r, Theme.error.g, Theme.error.b, 0.16) : "transparent")
          Behavior on color { ColorAnimation { duration: 120 } }
          Text {
            anchors.centerIn: parent
            text: row.confirmingDelete ? "󰄬" : "󰆴"
            color: row.confirmingDelete ? Theme.textOnPrimary : Theme.subtext
            font.pixelSize: Theme.fs(12)
            font.family: "JetBrainsMono Nerd Font"
          }
          MouseArea {
            id: delArea
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: row.deleteRequested()
          }
        }
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 10
        enabled: !row.muted
        opacity: row.muted ? 0.4 : 1
        Behavior on opacity { NumberAnimation { duration: 120 } }

        Text {
          Layout.fillWidth: true
          text: Translations.t("advAudioVolume")
          color: Theme.subtext
          font.pixelSize: Theme.fs(11)
          font.family: "JetBrainsMono Nerd Font"
        }

        NumberStepper {
          Layout.preferredWidth: 130
          value: row.volume
          min: 0; max: 150; step: 5
          suffix: "%"
          onEdited: v => row.volumeMoved(v)
        }
      }

      // ── Conectar a: chips por cada salida física, tildable individual ──
      ColumnLayout {
        Layout.fillWidth: true
        Layout.topMargin: 2
        spacing: 4
        visible: row.showConnections && AudioService.destinationCandidates().length > 0

        Text {
          text: Translations.t("advAudioConnectTo")
          color: Theme.subtext
          font.pixelSize: Theme.fs(10)
          font.family: "JetBrainsMono Nerd Font"
        }

        Flow {
          Layout.fillWidth: true
          spacing: 6

          Repeater {
            model: AudioService.destinationCandidates()
            delegate: Rectangle {
              id: chip
              required property var modelData
              readonly property bool connected: AudioService.isConnected(row.nodeName, modelData.name)

              width: chipRow.implicitWidth + 18
              height: 26
              radius: 8
              color: chip.connected
                ? Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.18)
                : (chipArea.containsMouse ? Theme.surfaceHigh : Theme.surface)
              border.width: chip.connected ? 1 : 0
              border.color: Theme.primary
              Behavior on color { ColorAnimation { duration: 120 } }

              RowLayout {
                id: chipRow
                anchors.centerIn: parent
                spacing: 5
                Text {
                  visible: chip.connected
                  text: "󰄬"
                  color: Theme.primary
                  font.pixelSize: Theme.fs(10)
                  font.family: "JetBrainsMono Nerd Font"
                }
                Text {
                  text: chip.modelData.desc
                  color: chip.connected ? Theme.text : Theme.subtext
                  font.pixelSize: Theme.fs(10)
                  font.family: "JetBrainsMono Nerd Font"
                }
              }

              MouseArea {
                id: chipArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: AudioService.setConnection(row.nodeName, chip.modelData.name, !chip.connected)
              }
            }
          }
        }
      }
    }
  }

  PanelWindow {
    id: win

    screen: Quickshell.screens.find(s => s.name === root.targetScreen) ?? Quickshell.screens[0]
    visible: true
    color: "transparent"
    exclusiveZone: -1
    anchors { top: true; left: true; right: true; bottom: true }

    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.namespace: root.namespace
    // Modal: mientras está abierta se queda con el teclado (Esc)
    WlrLayershell.keyboardFocus: root.open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    // Cerrada: región vacía = todo click-through
    mask: Region { item: hitArea }

    Connections {
      target: root
      function onOpenChanged() {
        if (root.open) keyCatcher.forceActiveFocus()
      }
    }

    // ── Fondo oscurecido ──
    Rectangle {
      anchors.fill: parent
      color: "#000000"
      opacity: root.open ? 0.55 : 0
      visible: opacity > 0
      Behavior on opacity { NumberAnimation { duration: 180 } }
    }

    // ── Zona que captura input (clic afuera = cerrar) ──
    Item {
      id: hitArea
      width: root.open ? parent.width : 0
      height: root.open ? parent.height : 0

      MouseArea {
        anchors.fill: parent
        acceptedButtons: Qt.AllButtons
        onClicked: root.closeRequested()
      }
    }

    Item {
      id: keyCatcher
      anchors.fill: parent
      focus: true
      Keys.onPressed: event => {
        if (event.key === Qt.Key_Escape) {
          root.closeRequested()
          event.accepted = true
        }
      }
    }

    // ── Tarjeta grande ──
    Rectangle {
      id: card
      anchors.centerIn: parent
      width: root.winW
      height: root.winH
      radius: Theme.panelRadius
      color: Theme.bg
      border.width: 1
      border.color: Theme.divider
      // Sin esto, el contenido (header, sidebar, tarjetas del panel
      // derecho) llega hasta el borde exacto del rectángulo y no se
      // recorta con la curva de `radius` — cualquier esquina que toque
      // el borde se ve cuadrada asomando por fuera del panel redondeado.
      // Pasa en todas las categorías porque `card` es el contenedor raíz
      // de todas ellas, no algo específico de una pestaña.
      clip: true

      opacity: root.open ? 1 : 0
      visible: opacity > 0
      scale: (root.open ? 1.0 : 0.95) * Theme.windowScale
      Behavior on opacity { NumberAnimation { duration: 180 } }
      Behavior on scale { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }

      // Los clics sobre la tarjeta no deben llegar al fondo (que cierra)
      MouseArea { anchors.fill: parent }

      // `clip: true` de arriba solo recorta contra el RECTÁNGULO que ocupa
      // `card` (su bounding box), no contra la silueta curva de `radius`.
      // Por eso cualquier hijo que llegue justo a la esquina (p.ej. la
      // tarjeta "Monitores" cortada a mitad por el scroll) se sigue viendo
      // con la punta cuadrada asomando por fuera de la curva. Esta máscara
      // recorta el contenido con un rectángulo redondeado real, del mismo
      // radio que `card`, para que ninguna esquina cuadrada llegue a
      // dibujarse ahí.
      Item {
        id: cardMask
        anchors.fill: parent
        layer.enabled: true
        visible: false

        Rectangle {
          anchors.fill: parent
          color: "black"
          radius: card.radius
        }
      }

      ColumnLayout {
        anchors.fill: parent
        spacing: 0
        layer.enabled: true
        layer.effect: MultiEffect {
          maskEnabled: true
          maskSource: cardMask
          maskThresholdMin: 0.5
          maskSpreadAtMin: 1.0
        }

        // ══════════════════════════════════════════════════════
        // Encabezado: ‹ volver · ícono + título · buscador · ✕ cerrar
        // ══════════════════════════════════════════════════════
        RowLayout {
          Layout.fillWidth: true
          Layout.preferredHeight: 60
          Layout.leftMargin: 20
          Layout.rightMargin: 16
          spacing: 12

          Rectangle {
            Layout.preferredWidth: 30
            Layout.preferredHeight: 30
            radius: 15
            color: backArea.containsMouse ? Theme.surfaceHigh : Theme.surface
            Behavior on color { ColorAnimation { duration: 120 } }
            Text {
              anchors.centerIn: parent
              text: "󰅁"
              color: Theme.text
              font.pixelSize: Theme.fs(16)
              font.family: "JetBrainsMono Nerd Font"
            }
            MouseArea {
              id: backArea
              anchors.fill: parent
              hoverEnabled: true
              cursorShape: Qt.PointingHandCursor
              onClicked: root.backRequested()
            }
          }

          Text {
            text: "󰒓"
            color: Theme.primary
            font.pixelSize: Theme.fs(19)
            font.family: "JetBrainsMono Nerd Font"
          }
          Text {
            text: Translations.t("advTitle")
            color: Theme.text
            font.bold: true
            font.pixelSize: Theme.fs(16)
            font.family: "JetBrainsMono Nerd Font"
          }

          Item { Layout.fillWidth: true }

          // ── Buscador (filtra las categorías de la izquierda) ──
          Rectangle {
            Layout.preferredWidth: 220
            Layout.preferredHeight: 36
            radius: 12
            color: Theme.surface
            border.width: searchInput.activeFocus ? 1 : 0
            border.color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.55)
            Behavior on border.width { NumberAnimation { duration: 150 } }

            RowLayout {
              anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
              spacing: 8

              Text {
                text: "󰍉"
                color: Theme.subtext
                font.pixelSize: Theme.fs(13)
                font.family: "JetBrainsMono Nerd Font"
              }

              TextInput {
                id: searchInput
                Layout.fillWidth: true
                color: Theme.text
                selectionColor: Theme.primary
                selectedTextColor: Theme.textOnPrimary
                font.pixelSize: Theme.fs(12)
                font.family: "JetBrainsMono Nerd Font"
                clip: true
                inputMethodHints: Qt.ImhNoPredictiveText
                onTextChanged: root.query = text
                Keys.onEscapePressed: root.closeRequested()

                Text {
                  visible: searchInput.text === "" && !searchInput.activeFocus
                  text: Translations.t("advSearchPlaceholder")
                  color: Theme.subtext
                  font.pixelSize: Theme.fs(12)
                  font.family: "JetBrainsMono Nerd Font"
                }
              }
            }
          }

          Rectangle {
            Layout.preferredWidth: 30
            Layout.preferredHeight: 30
            radius: 15
            color: closeArea.containsMouse ? Theme.surfaceHigh : Theme.surface
            Behavior on color { ColorAnimation { duration: 120 } }
            Text {
              anchors.centerIn: parent
              text: "✕"
              color: Theme.text
              font.pixelSize: Theme.fs(14)
              font.family: "JetBrainsMono Nerd Font"
            }
            MouseArea {
              id: closeArea
              anchors.fill: parent
              hoverEnabled: true
              cursorShape: Qt.PointingHandCursor
              onClicked: root.closeRequested()
            }
          }
        }

        Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

        // ══════════════════════════════════════════════════════
        // Cuerpo: lista de categorías (izquierda) + detalle (derecha)
        // ══════════════════════════════════════════════════════
        RowLayout {
          Layout.fillWidth: true
          Layout.fillHeight: true
          spacing: 0

          // ── Barra lateral: ancho fijo (root.sidebarWidth) ──
          ColumnLayout {
            Layout.preferredWidth: root.sidebarWidth
              Layout.minimumWidth: root.sidebarWidth
            Layout.fillHeight: true
            Layout.topMargin: 14
            Layout.leftMargin: 1
            Layout.rightMargin: 0
            spacing: 1

            Repeater {
              model: root.visibleCategories

              delegate: Rectangle {
                id: catRow
                required property var modelData
                // `.idx`, puesto a mano en cada entrada de `root.categories`
                // (ver el comentario arriba, junto a `onVisibleCategoriesChanged`):
                // nunca depende de encontrar este mismo objeto por identidad
                // dentro de un array que podría haber sido recreado.
                readonly property int catIndex: catRow.modelData.idx
                readonly property bool current: root.category === catIndex

                Layout.fillWidth: true
                Layout.preferredHeight: 42
                radius: 10
                color: catRow.current ? Theme.primary
                     : (catArea.containsMouse ? Theme.surfaceHigh : "transparent")
                Behavior on color { ColorAnimation { duration: 150 } }

                RowLayout {
                  id: catRowContent
                  anchors { fill: parent; leftMargin: 12; rightMargin: 1 }
                  spacing: 10

                  Text {
                    text: catRow.modelData.icon
                    color: catRow.current ? Theme.textOnPrimary : Theme.primary
                    font.pixelSize: Theme.fs(15)
                    font.family: "JetBrainsMono Nerd Font"
                    Behavior on color { ColorAnimation { duration: 150 } }
                  }
                  Text {
                    Layout.fillWidth: true
                    elide: Text.ElideRight
                    text: Translations.t(catRow.modelData.key)
                    color: catRow.current ? Theme.textOnPrimary : Theme.text
                    font.bold: true
                    font.pixelSize: Theme.fs(12)
                    font.family: "JetBrainsMono Nerd Font"
                    Behavior on color { ColorAnimation { duration: 150 } }
                  }
                }

                MouseArea {
                  id: catArea
                  anchors.fill: parent
                  hoverEnabled: true
                  cursorShape: Qt.PointingHandCursor
                  onClicked: root.category = catRow.catIndex
                }
              }
            }

            Text {
              visible: root.visibleCategories.length === 0
              Layout.fillWidth: true
              Layout.topMargin: 8
              wrapMode: Text.WordWrap
              text: Translations.t("advNoResults")
              color: Theme.subtext
              font.pixelSize: Theme.fs(11)
              font.family: "JetBrainsMono Nerd Font"
            }

            Item { Layout.fillHeight: true }
          }

          Rectangle { Layout.preferredWidth: 1; Layout.fillHeight: true; color: Theme.divider }

          // ── Detalle de la categoría elegida ──
          Flickable {
            id: flick
            Layout.fillWidth: true
            Layout.minimumWidth: 320          // ← clave: nunca colapsa a 1px
            Layout.preferredWidth: 480        // ← ancho cómodo por defecto
            Layout.fillHeight: true
            contentWidth: width
            contentHeight: detailCol.implicitHeight + 40
            clip: true
            boundsBehavior: Flickable.StopAtBounds


            // Si quedó con scroll (ej. estabas en "Acerca de" y lo bajaste)
            // y cambiás a una categoría más corta (ej. "Apariencia"), sin
            // esto el contenido nuevo nace más arriba que `contentY` y con
            // `clip: true` no se ve nada: hay que scrollear a mano para
            // encontrarlo. Se reubica arriba del todo al cambiar de
            // categoría y también al reabrir el menú.
            Behavior on contentY {
              enabled: flick.moving === false
              NumberAnimation { duration: 150; easing.type: Easing.OutCubic }
            }
            Connections {
              target: root
              function onCategoryChanged() { flick.contentY = 0 }
              function onOpenChanged() { if (root.open) flick.contentY = 0 }
            }

            ColumnLayout {
              id: detailCol
              x: 1
              y: 22
              width: flick.width - 5
              spacing: 1

              // ────────────────────────────────────────────────
              // Apariencia · Paleta de matugen preferida
              // ────────────────────────────────────────────────
              ColumnLayout {
                Layout.fillWidth: true
                visible: root.category === 0
                spacing: 10

                Text {
                  text: Translations.t("advCatAppearance")
                  color: Theme.text
                  font.bold: true
                  font.pixelSize: Theme.fs(18)
                  font.family: "JetBrainsMono Nerd Font"
                }

                Rectangle {
                  Layout.fillWidth: true
                  implicitHeight: paletteCol.implicitHeight + 28
                  radius: Theme.cardRadius
                  color: Theme.surface
                  clip: true

                  ColumnLayout {
                    id: paletteCol
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                    spacing: 10

                    SectionLabel { text: Translations.t("advPaletteTitle") }

                    // ── Slider Automático ⇄ Paletas ──────────────────
                    // Pastilla de dos mitades: la mitad marcada se desliza
                    // con una animación (mismo lenguaje que el switch on/off
                    // de Apariencia, pero con las dos etiquetas siempre a la
                    // vista en vez de un puntito). Automático = de siempre
                    // (matugen sobre el wallpaper); Paletas = colores fijos,
                    // elegidos abajo, y matugen se apaga del todo.
                    Rectangle {
                      id: modeSlider
                      Layout.fillWidth: true
                      Layout.preferredHeight: 36
                      radius: 18
                      color: Theme.bg
                      border.width: 1
                      border.color: Theme.divider

                      readonly property bool manual: Theme.paletteMode
                      readonly property real half: (width - 4) / 2

                      Rectangle {
                        x: modeSlider.manual ? modeSlider.half + 2 : 2
                        y: 2
                        width: modeSlider.half
                        height: parent.height - 4
                        radius: 16
                        color: Theme.primary
                        Behavior on x { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
                      }

                      RowLayout {
                        anchors.fill: parent
                        spacing: 0

                        Repeater {
                          model: [
                            { key: "advPaletteModeAuto",   value: false },
                            { key: "advPaletteModeManual", value: true  }
                          ]

                          delegate: Item {
                            id: seg
                            required property var modelData
                            readonly property bool active: seg.modelData.value === modeSlider.manual

                            Layout.fillWidth: true
                            Layout.fillHeight: true

                            Text {
                              anchors.centerIn: parent
                              text: Translations.t(seg.modelData.key)
                              color: seg.active ? Theme.textOnPrimary : Theme.subtext
                              font.bold: seg.active
                              font.pixelSize: Theme.fs(11)
                              font.family: "JetBrainsMono Nerd Font"
                              Behavior on color { ColorAnimation { duration: 150 } }
                            }

                            MouseArea {
                              anchors.fill: parent
                              cursorShape: Qt.PointingHandCursor
                              onClicked: Theme.setPaletteMode(seg.modelData.value)
                            }
                          }
                        }
                      }
                    }

                    Text {
                      Layout.fillWidth: true
                      text: Translations.t(Theme.paletteMode ? "advPaletteManualHint" : "advPaletteHint")
                      wrapMode: Text.WordWrap
                      color: Theme.subtext
                      font.pixelSize: Theme.fs(11)
                      font.family: "JetBrainsMono Nerd Font"
                    }

                    // ── Automático: esquemas de matugen (de siempre) ──
                    Flow {
                      Layout.fillWidth: true
                      spacing: 8
                      visible: !Theme.paletteMode

                      Repeater {
                        model: Theme.schemes
                        delegate: Rectangle {
                          id: chip
                          required property var modelData
                          required property int index
                          readonly property bool active: index === Theme.defaultSchemeIndex

                          implicitWidth: chipLabel.implicitWidth + 24
                          implicitHeight: 32
                          radius: 16
                          color: chip.active ? Theme.primary
                               : (chipArea.containsMouse ? Theme.surfaceHigh : Theme.bg)
                          border.width: chip.active ? 0 : 1
                          border.color: Theme.divider
                          Behavior on color { ColorAnimation { duration: 150 } }

                          Text {
                            id: chipLabel
                            anchors.centerIn: parent
                            text: chip.modelData.label
                            color: chip.active ? Theme.textOnPrimary : Theme.text
                            font.pixelSize: Theme.fs(11)
                            font.bold: chip.active
                            font.family: "JetBrainsMono Nerd Font"
                          }

                          MouseArea {
                            id: chipArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: Theme.setDefaultSchemeIndex(chip.index)
                          }
                        }
                      }
                    }

                    // ── Paletas: 6 paletas fijas (con muestra de color) ──
                    Flow {
                      Layout.fillWidth: true
                      spacing: 8
                      visible: Theme.paletteMode

                      Repeater {
                        model: Theme.manualPalettes
                        delegate: Rectangle {
                          id: pchip
                          required property var modelData
                          required property int index
                          readonly property bool active: index === Theme.manualPaletteIndex

                          implicitWidth: pchipRow.implicitWidth + 22
                          implicitHeight: 32
                          radius: 16
                          color: pchip.active ? Theme.primary
                               : (pchipArea.containsMouse ? Theme.surfaceHigh : Theme.bg)
                          border.width: pchip.active ? 0 : 1
                          border.color: Theme.divider
                          Behavior on color { ColorAnimation { duration: 150 } }

                          RowLayout {
                            id: pchipRow
                            anchors.centerIn: parent
                            spacing: 6

                            Rectangle {
                              Layout.preferredWidth: 14
                              Layout.preferredHeight: 14
                              radius: 7
                              color: pchip.modelData.primary
                              border.width: 1
                              border.color: pchip.active ? Theme.textOnPrimary : Theme.divider
                            }

                            Text {
                              text: pchip.modelData.label
                              color: pchip.active ? Theme.textOnPrimary : Theme.text
                              font.pixelSize: Theme.fs(11)
                              font.bold: pchip.active
                              font.family: "JetBrainsMono Nerd Font"
                            }
                          }

                          MouseArea {
                            id: pchipArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: Theme.setManualPaletteIndex(pchip.index)
                          }
                        }
                      }
                    }
                  }
                }

                // ────────────────────────────────────────────
                // Hyprland: gaps, bordes, blur, sombra — sliders
                // con input numérico (clic en el número → editás)
                // ────────────────────────────────────────────
                Rectangle {
                  Layout.fillWidth: true
                  implicitHeight: hyprCol.implicitHeight + 28
                  radius: Theme.cardRadius
                  color: Theme.surface
                  clip: true

                  ColumnLayout {
                    id: hyprCol
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                    spacing: 14

                    SectionLabel { text: Translations.t("advHyprTitle") }

                    Text {
                      Layout.fillWidth: true
                      text: Translations.t("advHyprHint")
                      wrapMode: Text.WordWrap
                      color: Theme.subtext
                      font.pixelSize: Theme.fs(11)
                      font.family: "JetBrainsMono Nerd Font"
                    }

                    GridLayout {
                      Layout.fillWidth: true
                      columns: 2
                      columnSpacing: 18
                      rowSpacing: 10

                      Repeater {
                        model: root.hyprSliderSpecs

                        delegate: AppearanceSlider {
                          Layout.fillWidth: true
                          Layout.preferredWidth: 1
                          Layout.preferredHeight: 44
                          // Sin efecto mientras la sombra está apagada: se atenúan
                          opacity: (modelData.key.indexOf("shadow") === 0
                                    && !(root.appearanceValues.shadowEnabled ?? false)) ? 0.45 : 1
                          Behavior on opacity { NumberAnimation { duration: 150 } }

                          label: modelData.label
                          keyName: modelData.key
                          minValue: modelData.min
                          maxValue: modelData.max
                          stepValue: modelData.step
                          decimals: modelData.dec
                          value: root.appearanceValues[modelData.key] ?? modelData.def
                          colors: root.hyprSliderColors

                          onPreviewChanged: (k, v) => root.appearancePreviewChanged(k, v)
                          onCommitted: (k, v) => root.appearanceValueCommitted(k, v)
                        }
                      }
                    }

                    Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

                    RowLayout {
                      Layout.fillWidth: true
                      spacing: 12

                      Repeater {
                        model: root.hyprToggles

                        delegate: Item {
                          id: tog
                          readonly property bool on: root.appearanceValues[modelData.key] ?? modelData.def

                          Layout.fillWidth: true
                          Layout.preferredWidth: 1
                          Layout.preferredHeight: 26

                          RowLayout {
                            anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter }
                            spacing: 8

                            Rectangle {
                              Layout.preferredWidth: 34
                              Layout.preferredHeight: 20
                              radius: 10
                              color: tog.on ? Theme.primary : Theme.surfaceHigh
                              Behavior on color { ColorAnimation { duration: 150 } }

                              Rectangle {
                                width: 14
                                height: 14
                                radius: 7
                                anchors.verticalCenter: parent.verticalCenter
                                x: tog.on ? 17 : 3
                                color: tog.on ? Theme.textOnPrimary : Theme.subtext
                                Behavior on x { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
                                Behavior on color { ColorAnimation { duration: 150 } }
                              }
                            }

                            Text {
                              Layout.fillWidth: true
                              text: modelData.label
                              color: Theme.text
                              font.pixelSize: Theme.fs(11)
                              font.family: "JetBrainsMono Nerd Font"
                              elide: Text.ElideRight
                            }
                          }

                          MouseArea {
                            anchors.fill: parent
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.appearanceToggleChanged(modelData.key, !tog.on)
                          }
                        }
                      }
                    }
                  }
                }
              }

              // ────────────────────────────────────────────────
              // Interfaz · UI size avanzado
              // ────────────────────────────────────────────────
              ColumnLayout {
                Layout.fillWidth: true
                visible: root.category === 1
                spacing: 10

                Text {
                  text: Translations.t("advCatInterface")
                  color: Theme.text
                  font.bold: true
                  font.pixelSize: Theme.fs(18)
                  font.family: "JetBrainsMono Nerd Font"
                }

                Rectangle {
                  Layout.fillWidth: true
                  implicitHeight: panelWidthCol.implicitHeight + 30
                  radius: Theme.cardRadius
                  color: Theme.surface
                  clip: true

                  ColumnLayout {
                    id: panelWidthCol
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 16 }
                    spacing: 12

                    RowLayout {
                      Layout.fillWidth: true
                      spacing: 12

                      Rectangle {
                        Layout.preferredWidth: 36
                        Layout.preferredHeight: 36
                        radius: 11
                        color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.14)
                        Text {
                          anchors.centerIn: parent
                          text: "󰊓"
                          color: Theme.primary
                          font.pixelSize: Theme.fs(16)
                          font.family: "JetBrainsMono Nerd Font"
                        }
                      }

                      ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 1
                        SectionLabel { text: Translations.t("advPanelWidthTitle") }
                        Text {
                          Layout.fillWidth: true
                          text: Translations.t("advPanelWidthHint")
                          wrapMode: Text.WordWrap
                          color: Theme.subtext
                          font.pixelSize: Theme.fs(10)
                          font.family: "JetBrainsMono Nerd Font"
                        }
                      }
                    }

                    Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

                    RowLayout {
                      Layout.fillWidth: true
                      spacing: 12

                      NumberStepper {
                        Layout.preferredWidth: 150
                        value: Theme.panelWidthPercent
                        min: Theme.panelWidthMin
                        max: Theme.panelWidthMax
                        step: 5
                        suffix: "%"
                        onEdited: v => Theme.setPanelWidthPercent(v)
                      }

                      // ── Barra de progreso: dónde cae el % dentro del
                      // rango, con una marquita en 100% (el valor "de
                      // fábrica") para ubicarse de un vistazo. ──
                      ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 4

                        Item {
                          id: widthTrack
                          Layout.fillWidth: true
                          Layout.preferredHeight: 6

                          Rectangle {
                            anchors.fill: parent
                            radius: 3
                            color: Theme.surfaceHigh
                          }
                          Rectangle {
                            height: parent.height
                            radius: 3
                            color: Theme.primary
                            width: Math.max(6, parent.width *
                              ((Theme.panelWidthPercent - Theme.panelWidthMin) /
                               (Theme.panelWidthMax - Theme.panelWidthMin)))
                            Behavior on width { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
                          }
                          // Marca del 100% (tamaño por defecto)
                          Rectangle {
                            width: 2
                            height: 10
                            y: -2
                            radius: 1
                            color: Theme.subtext
                            opacity: 0.6
                            x: Math.min(widthTrack.width - width,
                                        widthTrack.width *
                                        ((100 - Theme.panelWidthMin) /
                                         (Theme.panelWidthMax - Theme.panelWidthMin)))
                          }
                        }

                        Text {
                          Layout.fillWidth: true
                          text: Theme.panelWidthMin + "% ─── 100% ─── " + Theme.panelWidthMax + "%"
                          color: Theme.subtext
                          opacity: 0.6
                          font.pixelSize: Theme.fs(9)
                          font.family: "JetBrainsMono Nerd Font"
                        }
                      }

                      // ── Restablecer: solo visible si no está en 100% ──
                      Rectangle {
                        visible: Theme.panelWidthPercent !== 100
                        Layout.preferredWidth: 30
                        Layout.preferredHeight: 30
                        radius: 9
                        color: resetArea.containsMouse ? Theme.surfaceHigh : "transparent"
                        Behavior on color { ColorAnimation { duration: 120 } }
                        Text {
                          anchors.centerIn: parent
                          text: "󰑙"
                          color: Theme.subtext
                          font.pixelSize: Theme.fs(14)
                          font.family: "JetBrainsMono Nerd Font"
                        }
                        MouseArea {
                          id: resetArea
                          anchors.fill: parent
                          hoverEnabled: true
                          cursorShape: Qt.PointingHandCursor
                          onClicked: Theme.setPanelWidthPercent(100)
                        }
                      }
                    }
                  }
                }

                Text {
                  Layout.fillWidth: true
                  text: Translations.t("advPanelWidthNote")
                  wrapMode: Text.WordWrap
                  color: Theme.subtext
                  font.italic: true
                  font.pixelSize: Theme.fs(10)
                  font.family: "JetBrainsMono Nerd Font"
                }

                // ────────────────────────────────────────────
                // Marco de pantalla: ON/OFF (mismo estado que el botón
                // del Menú) + estilo (esquinas | curvas) + radio/grosor
                // cuando el estilo es "curvas". Fusiona lo que antes eran
                // BAR/Border.qml y BAR/components/ConcaveCurves.qml (dos
                // piezas sueltas, sin cablear) en un solo sistema con
                // Bar.qml — ver Theme.frameStyle / frameCurveRadius /
                // frameThickness.
                // ────────────────────────────────────────────
                Rectangle {
                  Layout.fillWidth: true
                  implicitHeight: frameCol.implicitHeight + 30
                  radius: Theme.cardRadius
                  color: Theme.surface
                  clip: true

                  ColumnLayout {
                    id: frameCol
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 16 }
                    spacing: 12

                    // ── Encabezado + interruptor ON/OFF ──
                    RowLayout {
                      Layout.fillWidth: true
                      spacing: 12

                      Rectangle {
                        Layout.preferredWidth: 36
                        Layout.preferredHeight: 36
                        radius: 11
                        color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.14)
                        Text {
                          anchors.centerIn: parent
                          text: root.screenCorners ? "▣" : "▢"
                          color: Theme.primary
                          font.pixelSize: Theme.fs(16)
                          font.family: "JetBrainsMono Nerd Font"
                        }
                      }

                      ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 1
                        SectionLabel { text: Translations.t("advFrameTitle") }
                        Text {
                          Layout.fillWidth: true
                          text: Translations.t("advFrameEnableHint")
                          wrapMode: Text.WordWrap
                          maximumLineCount: 2
                          elide: Text.ElideRight
                          color: Theme.subtext
                          font.pixelSize: Theme.fs(10)
                          font.family: "JetBrainsMono Nerd Font"
                        }
                      }

                      // ── Interruptor (mismo look que los toggles de
                      // Apariencia: píldora + perilla que se desliza) ──
                      Item {
                        id: frameSwitch
                        Layout.preferredWidth: 34
                        Layout.preferredHeight: 20
                        opacity: Theme.barSeparated ? 0.4 : 1.0

                        Rectangle {
                          anchors.fill: parent
                          radius: 10
                          color: root.screenCorners ? Theme.primary : Theme.surfaceHigh
                          Behavior on color { ColorAnimation { duration: 150 } }

                          Rectangle {
                            width: 14
                            height: 14
                            radius: 7
                            anchors.verticalCenter: parent.verticalCenter
                            x: root.screenCorners ? 17 : 3
                            color: root.screenCorners ? Theme.textOnPrimary : Theme.subtext
                            Behavior on x { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
                            Behavior on color { ColorAnimation { duration: 150 } }
                          }
                        }

                        MouseArea {
                          anchors.fill: parent
                          cursorShape: Theme.barSeparated ? Qt.ArrowCursor : Qt.PointingHandCursor
                          onClicked: if (!Theme.barSeparated) root.requestCornersToggle()
                        }
                      }
                    }

                    // ── Aviso: con la barra flotante o Islas el marco no
                    // se puede mostrar aunque esté activado ──
                    Text {
                      visible: Theme.barSeparated
                      Layout.fillWidth: true
                      text: Translations.t("advFrameOffHint")
                      wrapMode: Text.WordWrap
                      color: Theme.subtext
                      font.italic: true
                      font.pixelSize: Theme.fs(10)
                      font.family: "JetBrainsMono Nerd Font"
                    }

                    Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

                    // ── Estilo: Esquinas | Curvas (selector de 2) ──
                    SectionLabel { text: Translations.t("advFrameStyleLabel") }

                    Rectangle {
                      id: styleSeg
                      Layout.fillWidth: true
                      Layout.preferredHeight: 44
                      radius: 12
                      color: Theme.surfaceHigh

                      readonly property bool curved: Theme.frameCurved
                      readonly property real segW: (width - 6) / 2

                      // Resaltador que se desliza al elegido
                      Rectangle {
                        x: 3 + (styleSeg.curved ? 1 : 0) * styleSeg.segW
                        y: 3
                        width: styleSeg.segW
                        height: parent.height - 6
                        radius: 9
                        color: Theme.primary
                        Behavior on x { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
                      }

                      RowLayout {
                        anchors.fill: parent
                        anchors.margins: 3
                        spacing: 0

                        Repeater {
                          model: [
                            { key: "corners", glyph: "▨", label: Translations.t("advFrameStyleCorners") },
                            { key: "curved",  glyph: "◜", label: Translations.t("advFrameStyleCurved")  }
                          ]

                          delegate: Item {
                            id: opt
                            required property var modelData
                            readonly property bool current: Theme.frameStyle === modelData.key

                            Layout.fillWidth: true
                            Layout.fillHeight: true

                            RowLayout {
                              anchors.centerIn: parent
                              spacing: 6
                              Text {
                                text: opt.modelData.glyph
                                color: opt.current ? Theme.textOnPrimary : Theme.text
                                font.pixelSize: Theme.fs(14)
                                font.family: "JetBrainsMono Nerd Font"
                                Behavior on color { ColorAnimation { duration: 150 } }
                              }
                              Text {
                                text: opt.modelData.label
                                color: opt.current ? Theme.textOnPrimary : Theme.text
                                font.pixelSize: Theme.fs(11)
                                font.family: "JetBrainsMono Nerd Font"
                                Behavior on color { ColorAnimation { duration: 150 } }
                              }
                            }

                            MouseArea {
                              anchors.fill: parent
                              cursorShape: Qt.PointingHandCursor
                              onClicked: Theme.setFrameStyle(opt.modelData.key)
                            }
                          }
                        }
                      }
                    }

                    Text {
                      Layout.fillWidth: true
                      text: Translations.t("advFrameStyleHint")
                      wrapMode: Text.WordWrap
                      color: Theme.subtext
                      font.pixelSize: Theme.fs(10)
                      font.family: "JetBrainsMono Nerd Font"
                    }

                    // ── Radio / grosor: solo tienen sentido con "curvas" ──
                    ColumnLayout {
                      Layout.fillWidth: true
                      spacing: 10
                      visible: Theme.frameCurved
                      opacity: Theme.frameCurved ? 1 : 0
                      Behavior on opacity { NumberAnimation { duration: 150 } }

                      Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

                      RowLayout {
                        Layout.fillWidth: true
                        spacing: 12

                        ColumnLayout {
                          Layout.fillWidth: true
                          spacing: 6
                          Text {
                            text: Translations.t("advFrameRadiusLabel")
                            color: Theme.subtext
                            font.pixelSize: Theme.fs(10)
                            font.family: "JetBrainsMono Nerd Font"
                          }
                          NumberStepper {
                            value: Theme.frameCurveRadius
                            min: 10; max: 60; step: 2
                            suffix: "px"
                            onEdited: v => Theme.setFrameCurveRadius(v)
                          }
                        }

                        ColumnLayout {
                          Layout.fillWidth: true
                          spacing: 6
                          Text {
                            text: Translations.t("advFrameThicknessLabel")
                            color: Theme.subtext
                            font.pixelSize: Theme.fs(10)
                            font.family: "JetBrainsMono Nerd Font"
                          }
                          NumberStepper {
                            value: Theme.frameThickness
                            min: 0; max: 150; step: 2
                            suffix: "px"
                            onEdited: v => Theme.setFrameThickness(v)
                          }
                        }
                      }
                    }
                  }
                }

                // ────────────────────────────────────────────
                // HyprMonitors: abre el editor de monitores de
                // Hyprland (antes vivía en Ajustes → General).
                // ────────────────────────────────────────────
                Rectangle {
                  Layout.fillWidth: true
                  Layout.preferredHeight: 58
                  radius: Theme.cardRadius
                  color: hyprMonitorsArea.containsMouse ? Theme.surfaceHigh : Theme.surface
                  Behavior on color { ColorAnimation { duration: 150 } }
                  clip: true

                  RowLayout {
                    anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                    spacing: 12

                    Rectangle {
                      Layout.preferredWidth: 36
                      Layout.preferredHeight: 36
                      radius: 11
                      color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.14)
                      Text {
                        anchors.centerIn: parent
                        text: "󰹑"
                        color: Theme.primary
                        font.pixelSize: Theme.fs(16)
                        font.family: "JetBrainsMono Nerd Font"
                      }
                    }

                    ColumnLayout {
                      Layout.fillWidth: true
                      spacing: 1
                      SectionLabel { text: Translations.t("settingsHyprMonitors") }
                      Text {
                        Layout.fillWidth: true
                        text: Translations.t("hyprMonitorsHint")
                        wrapMode: Text.WordWrap
                        maximumLineCount: 1
                        elide: Text.ElideRight
                        color: Theme.subtext
                        font.pixelSize: Theme.fs(10)
                        font.family: "JetBrainsMono Nerd Font"
                      }
                    }

                    Text {
                      text: "󰅂"
                      color: Theme.subtext
                      font.pixelSize: Theme.fs(11)
                      font.family: "JetBrainsMono Nerd Font"
                    }
                  }

                  MouseArea {
                    id: hyprMonitorsArea
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: root.requestMonitorEditor()
                  }
                }
              }

              // ────────────────────────────────────────────────
              // Servicios · Tachidesk (start/stop/restart/status)
              // ────────────────────────────────────────────────
              ColumnLayout {
                Layout.fillWidth: true
                visible: root.category === 2
                spacing: 10

                Text {
                  text: Translations.t("advCatServices")
                  color: Theme.text
                  font.bold: true
                  font.pixelSize: Theme.fs(18)
                  font.family: "JetBrainsMono Nerd Font"
                }

                Rectangle {
                  Layout.fillWidth: true
                  implicitHeight: tachideskCol.implicitHeight + 30
                  radius: Theme.cardRadius
                  color: Theme.surface
                  clip: true

                  ColumnLayout {
                    id: tachideskCol
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 16 }
                    spacing: 14

                    // ── Encabezado: ícono grande + nombre + estado ──
                    RowLayout {
                      Layout.fillWidth: true
                      spacing: 12

                      Rectangle {
                        Layout.preferredWidth: 40
                        Layout.preferredHeight: 40
                        radius: 12
                        color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.14)
                        Text {
                          anchors.centerIn: parent
                          text: "󰇜"
                          color: Theme.primary
                          font.pixelSize: Theme.fs(19)
                          font.family: "JetBrainsMono Nerd Font"
                        }
                      }

                      ColumnLayout {
                        Layout.fillWidth: true
                        spacing: 1
                        Text {
                          text: Translations.t("advTachideskTitle")
                          color: Theme.text
                          font.bold: true
                          font.pixelSize: Theme.fs(14)
                          font.family: "JetBrainsMono Nerd Font"
                        }
                        Text {
                          Layout.fillWidth: true
                          text: Translations.t("advTachideskHint")
                          wrapMode: Text.WordWrap
                          color: Theme.subtext
                          font.pixelSize: Theme.fs(10)
                          font.family: "JetBrainsMono Nerd Font"
                        }
                      }

                      // ── Badge de estado (pastilla con fondo tintado) ──
                      Rectangle {
                        id: statusBadge
                        readonly property color tint: !root.tachideskKnown ? Theme.subtext
                                                     : (root.tachideskRunning ? Theme.primary : Theme.error)
                        Layout.preferredWidth: badgeRow.implicitWidth + 20
                        Layout.preferredHeight: 26
                        radius: 13
                        color: Qt.rgba(tint.r, tint.g, tint.b, 0.14)
                        Behavior on color { ColorAnimation { duration: 200 } }

                        RowLayout {
                          id: badgeRow
                          anchors.centerIn: parent
                          spacing: 6

                          Rectangle {
                            id: statusDot
                            Layout.preferredWidth: 7
                            Layout.preferredHeight: 7
                            radius: 3.5
                            color: statusBadge.tint
                            Behavior on color { ColorAnimation { duration: 200 } }

                            SequentialAnimation on opacity {
                              running: root.tachideskBusy || !root.tachideskKnown
                              loops: Animation.Infinite
                              NumberAnimation { from: 1.0; to: 0.25; duration: 550; easing.type: Easing.InOutQuad }
                              NumberAnimation { from: 0.25; to: 1.0; duration: 550; easing.type: Easing.InOutQuad }
                            }
                          }
                          Text {
                            text: root.tachideskBusy ? Translations.t("advTachideskWorking")
                                : (!root.tachideskKnown ? Translations.t("advTachideskUnknown")
                                : (root.tachideskRunning ? Translations.t("advTachideskActive")
                                                          : Translations.t("advTachideskInactive")))
                            color: statusBadge.tint
                            font.pixelSize: Theme.fs(10)
                            font.bold: true
                            font.family: "JetBrainsMono Nerd Font"
                          }
                        }
                      }
                    }

                    Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

                    // ── Acciones ──
                    RowLayout {
                      Layout.fillWidth: true
                      spacing: 8

                      Btn {
                        text: Translations.t("advTachideskStart")
                        icon: "󰐊"
                        primary: true
                        enabled: !root.tachideskBusy && !root.tachideskRunning
                        onClicked: root.tachideskRunAction("start")
                      }
                      Btn {
                        text: Translations.t("advTachideskStop")
                        icon: "󰓛"
                        enabled: !root.tachideskBusy && root.tachideskRunning
                        onClicked: root.tachideskRunAction("stop")
                      }
                      Btn {
                        text: Translations.t("advTachideskRestart")
                        icon: "󰜉"
                        enabled: !root.tachideskBusy
                        onClicked: root.tachideskRunAction("restart")
                      }

                      Item { Layout.fillWidth: true }

                      // ── Refrescar: ghost button, solo ícono, gira mientras consulta ──
                      Rectangle {
                        id: refreshBtn
                        Layout.preferredWidth: 32
                        Layout.preferredHeight: 32
                        radius: 9
                        color: refreshArea.containsMouse ? Theme.surfaceHigh : "transparent"
                        Behavior on color { ColorAnimation { duration: 150 } }

                        Text {
                          id: refreshIcon
                          anchors.centerIn: parent
                          text: "󰑐"
                          color: Theme.subtext
                          font.pixelSize: Theme.fs(14)
                          font.family: "JetBrainsMono Nerd Font"
                          RotationAnimation on rotation {
                            running: tachideskStatusProc.running
                            loops: Animation.Infinite
                            from: 0; to: 360
                            duration: 700
                          }
                        }
                        MouseArea {
                          id: refreshArea
                          anchors.fill: parent
                          hoverEnabled: true
                          cursorShape: Qt.PointingHandCursor
                          onClicked: root.tachideskRefreshStatus()
                        }
                      }
                    }

                    // ── "Terminal": barra con semáforo + salida coloreada ──
                    ColumnLayout {
                      Layout.fillWidth: true
                      spacing: 0

                      Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 28
                        topLeftRadius: 10
                        topRightRadius: 10
                        color: Qt.darker(Theme.bg, 1.08)

                        RowLayout {
                          anchors { fill: parent; leftMargin: 12; rightMargin: 12 }
                          spacing: 6

                          Repeater {
                            model: ["#ff5f56", "#ffbd2e", "#27c93f"]
                            delegate: Rectangle {
                              required property string modelData
                              Layout.preferredWidth: 9
                              Layout.preferredHeight: 9
                              radius: 4.5
                              color: modelData
                              opacity: 0.85
                            }
                          }

                          Item { Layout.preferredWidth: 4 }

                          Text {
                            Layout.fillWidth: true
                            elide: Text.ElideRight
                            text: Translations.t("advTachideskOutputTitle")
                            color: Theme.subtext
                            font.pixelSize: Theme.fs(10)
                            font.family: "JetBrainsMono Nerd Font"
                          }

                          Text {
                            visible: root.tachideskLastUpdate !== ""
                            text: root.tachideskLastUpdate
                            color: Theme.subtext
                            opacity: 0.7
                            font.pixelSize: Theme.fs(9)
                            font.family: "JetBrainsMono Nerd Font"
                          }
                        }
                      }

                      Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 168
                        color: Theme.bg
                        bottomLeftRadius: 10
                        bottomRightRadius: 10
                        border.width: 1
                        border.color: Theme.divider
                        clip: true

                        Flickable {
                          id: consoleFlick
                          anchors { fill: parent; margins: 12 }
                          contentWidth: width
                          contentHeight: consoleText.implicitHeight
                          clip: true
                          boundsBehavior: Flickable.StopAtBounds
                          Behavior on contentY { NumberAnimation { duration: 160; easing.type: Easing.OutCubic } }

                          // Autoscroll al fondo cada vez que llega salida nueva
                          onContentHeightChanged: Qt.callLater(() => {
                            consoleFlick.contentY = Math.max(0, consoleFlick.contentHeight - consoleFlick.height)
                          })

                          Text {
                            id: consoleText
                            width: consoleFlick.width
                            textFormat: Text.RichText
                            text: root.tachideskStatusText !== ""
                              ? root.tachideskFormatOutput(root.tachideskStatusText)
                              : "<font color=\"" + Theme.subtext + "\">" + Translations.t("advTachideskNoOutput") + "</font>"
                            wrapMode: Text.Wrap
                            lineHeight: 1.35
                            font.pixelSize: Theme.fs(10)
                            font.family: "JetBrainsMono Nerd Font, monospace"
                          }
                        }
                      }
                    }
                  }
                }
              }

              // ────────────────────────────────────────────────
              // Audio · OozeAudio (mismo AudioService que la app suelta)
              // ────────────────────────────────────────────────
              ColumnLayout {
                Layout.fillWidth: true
                visible: root.category === 3
                spacing: 10

                RowLayout {
                  Layout.fillWidth: true
                  spacing: 10

                  Text {
                    Layout.fillWidth: true
                    text: Translations.t("advCatAudio")
                    color: Theme.text
                    font.bold: true
                    font.pixelSize: Theme.fs(18)
                    font.family: "JetBrainsMono Nerd Font"
                  }

                  Btn {
                    text: Translations.t("advAudioOpenQpwgraph")
                    icon: "󰏌"
                    onClicked: root.openQpwgraph()
                  }

                  // ── Refrescar: ghost button, gira mientras consulta ──
                  Rectangle {
                    Layout.preferredWidth: 30
                    Layout.preferredHeight: 30
                    radius: 9
                    color: audioRefreshArea.containsMouse ? Theme.surfaceHigh : "transparent"
                    Behavior on color { ColorAnimation { duration: 120 } }
                    Text {
                      anchors.centerIn: parent
                      text: "󰑐"
                      color: Theme.subtext
                      font.pixelSize: Theme.fs(14)
                      font.family: "JetBrainsMono Nerd Font"
                      RotationAnimation on rotation {
                        running: AudioService.busy
                        loops: Animation.Infinite
                        from: 0; to: 360
                        duration: 700
                      }
                    }
                    MouseArea {
                      id: audioRefreshArea
                      anchors.fill: parent
                      hoverEnabled: true
                      cursorShape: Qt.PointingHandCursor
                      onClicked: AudioService.refreshAll()
                    }
                  }
                }

                // ── Mostrar/ocultar la tarjeta de Monitores físicos: la
                // app OozeAudio suelta no la tiene (solo virtuales +
                // conexiones), así que queda opcional acá también. ──
                RowLayout {
                  Layout.fillWidth: true
                  spacing: 8

                  Text {
                    Layout.fillWidth: true
                    text: Translations.t("advAudioMonitorsToggleLabel")
                    color: Theme.subtext
                    font.pixelSize: Theme.fs(11)
                    font.family: "JetBrainsMono Nerd Font"
                  }

                  Rectangle {
                    Layout.preferredWidth: 34
                    Layout.preferredHeight: 20
                    radius: 10
                    color: Theme.audioMonitorsCardEnabled ? Theme.primary : Theme.surfaceHigh
                    Behavior on color { ColorAnimation { duration: 150 } }

                    Rectangle {
                      width: 14
                      height: 14
                      radius: 7
                      anchors.verticalCenter: parent.verticalCenter
                      x: Theme.audioMonitorsCardEnabled ? 17 : 3
                      color: Theme.audioMonitorsCardEnabled ? Theme.textOnPrimary : Theme.subtext
                      Behavior on x { NumberAnimation { duration: 150; easing.type: Easing.OutCubic } }
                      Behavior on color { ColorAnimation { duration: 150 } }
                    }

                    MouseArea {
                      anchors.fill: parent
                      cursorShape: Qt.PointingHandCursor
                      onClicked: Theme.setAudioMonitorsCardEnabled(!Theme.audioMonitorsCardEnabled)
                    }
                  }
                }

                // ── Error del backend, si el último comando falló ──
                Rectangle {
                  visible: root.oozeAudioError !== ""
                  Layout.fillWidth: true
                  implicitHeight: audioErrText.implicitHeight + 24
                  radius: Theme.cardRadius
                  color: Qt.rgba(Theme.error.r, Theme.error.g, Theme.error.b, 0.12)
                  clip: true
                  Text {
                    id: audioErrText
                    anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 12 }
                    wrapMode: Text.WordWrap
                    text: root.oozeAudioError
                    color: Theme.error
                    font.pixelSize: Theme.fs(11)
                    font.family: "JetBrainsMono Nerd Font"
                  }
                }

                // ── Salidas virtuales (ooze_*): crear, borrar, volumen ──
                Rectangle {
                  Layout.fillWidth: true
                  implicitHeight: outputsCol.implicitHeight + 28
                  radius: Theme.cardRadius
                  color: Theme.surface
                  clip: true

                  ColumnLayout {
                    id: outputsCol
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                    spacing: 10

                    SectionLabel { text: Translations.t("advAudioOutputsTitle") }
                    Text {
                      Layout.fillWidth: true
                      text: Translations.t("advAudioOutputsHint")
                      wrapMode: Text.WordWrap
                      color: Theme.subtext
                      font.pixelSize: Theme.fs(11)
                      font.family: "JetBrainsMono Nerd Font"
                    }

                    // ── Crear salida nueva ──
                    RowLayout {
                      Layout.fillWidth: true
                      spacing: 8

                      Rectangle {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 36
                        radius: 10
                        color: Theme.bg
                        border.width: newOutputInput.activeFocus ? 1 : 0
                        border.color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.55)
                        Behavior on border.width { NumberAnimation { duration: 150 } }

                        TextInput {
                          id: newOutputInput
                          anchors { fill: parent; leftMargin: 12; rightMargin: 12; verticalCenter: parent.verticalCenter }
                          verticalAlignment: TextInput.AlignVCenter
                          color: Theme.text
                          selectionColor: Theme.primary
                          selectedTextColor: Theme.textOnPrimary
                          font.pixelSize: Theme.fs(12)
                          font.family: "JetBrainsMono Nerd Font"
                          clip: true
                          text: root.oozeAudioNewName
                          onTextChanged: root.oozeAudioNewName = text
                          onAccepted: if (root.oozeAudioNewName.trim() !== "") {
                            AudioService.createOutput(root.oozeAudioNewName.trim())
                            root.oozeAudioNewName = ""
                          }

                          Text {
                            visible: newOutputInput.text === "" && !newOutputInput.activeFocus
                            text: Translations.t("advAudioNewOutputPlaceholder")
                            color: Theme.subtext
                            font.pixelSize: Theme.fs(12)
                            font.family: "JetBrainsMono Nerd Font"
                          }
                        }
                      }

                      Btn {
                        text: Translations.t("advAudioCreate")
                        icon: "󰐕"
                        primary: true
                        enabled: !AudioService.busy && root.oozeAudioNewName.trim() !== ""
                        onClicked: {
                          AudioService.createOutput(root.oozeAudioNewName.trim())
                          root.oozeAudioNewName = ""
                        }
                      }
                    }

                    Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

                    // ── Lista de salidas virtuales ──
                    ColumnLayout {
                      Layout.fillWidth: true
                      spacing: 8
                      visible: AudioService.outputs.length > 0

                      Repeater {
                        model: AudioService.outputs
                        delegate: AudioRow {
                          required property var modelData
                          nodeId: modelData.id
                          nodeName: modelData.name
                          title: modelData.desc
                          subtitle: modelData.name
                          volume: modelData.volume
                          muted: modelData.muted
                          deletable: true
                          showConnections: true
                          confirmingDelete: root.oozeAudioConfirmDelete === modelData.name
                          onVolumeMoved: v => AudioService.setVolume("outputs", modelData.id, v)
                          onMuteToggled: AudioService.setMute("outputs", modelData.id, !modelData.muted)
                          onDeleteRequested: {
                            if (root.oozeAudioConfirmDelete === modelData.name) {
                              AudioService.deleteOutput(modelData.desc)
                              root.oozeAudioConfirmDelete = ""
                            } else {
                              root.oozeAudioConfirmDelete = modelData.name
                            }
                          }
                        }
                      }
                    }

                    Text {
                      visible: AudioService.outputs.length === 0
                      Layout.fillWidth: true
                      wrapMode: Text.WordWrap
                      text: Translations.t("advAudioNoOutputs")
                      color: Theme.subtext
                      font.italic: true
                      font.pixelSize: Theme.fs(11)
                      font.family: "JetBrainsMono Nerd Font"
                    }
                  }
                }

                // ── Monitores / salidas físicas: solo volumen ──
                Rectangle {
                  Layout.fillWidth: true
                  visible: Theme.audioMonitorsCardEnabled
                  implicitHeight: sinksCol.implicitHeight + 28
                  radius: Theme.cardRadius
                  color: Theme.surface
                  clip: true

                  ColumnLayout {
                    id: sinksCol
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 14 }
                    spacing: 10

                    SectionLabel { text: Translations.t("advAudioMonitorsTitle") }
                    Text {
                      Layout.fillWidth: true
                      text: Translations.t("advAudioMonitorsHint")
                      wrapMode: Text.WordWrap
                      color: Theme.subtext
                      font.pixelSize: Theme.fs(11)
                      font.family: "JetBrainsMono Nerd Font"
                    }

                    ColumnLayout {
                      Layout.fillWidth: true
                      spacing: 8
                      visible: AudioService.destinationCandidates().length > 0

                      Repeater {
                        model: AudioService.destinationCandidates()
                        delegate: AudioRow {
                          required property var modelData
                          nodeId: modelData.id
                          title: modelData.desc
                          subtitle: modelData.name
                          volume: modelData.volume
                          muted: modelData.muted
                          deletable: false
                          onVolumeMoved: v => AudioService.setVolume("sinks", modelData.id, v)
                          onMuteToggled: AudioService.setMute("sinks", modelData.id, !modelData.muted)
                        }
                      }
                    }

                    Text {
                      visible: AudioService.destinationCandidates().length === 0
                      Layout.fillWidth: true
                      wrapMode: Text.WordWrap
                      text: Translations.t("advAudioNoMonitors")
                      color: Theme.subtext
                      font.italic: true
                      font.pixelSize: Theme.fs(11)
                      font.family: "JetBrainsMono Nerd Font"
                    }
                  }
                }

                Item { Layout.preferredHeight: 4 }
              }

              // ────────────────────────────────────────────────
              // Acerca de — limpia por defecto: hero + repos a la vista,
              // info avanzada del sistema escondida detrás de un desplegable.
              // ────────────────────────────────────────────────
              ColumnLayout {
                Layout.fillWidth: true
                visible: root.category === 4
                spacing: 14

                // ── Hero: ícono + nombre + tagline en una fila compacta,
                // en vez de la pila centrada de antes (ícono grande +
                // título grande + párrafo aparte) ──
                RowLayout {
                  Layout.fillWidth: true
                  spacing: 12

                  Rectangle {
                    Layout.preferredWidth: 42
                    Layout.preferredHeight: 42
                    radius: 13
                    color: Qt.rgba(Theme.primary.r, Theme.primary.g, Theme.primary.b, 0.15)

                    Text {
                      anchors.centerIn: parent
                      text: "󰧨"
                      color: Theme.primary
                      font.pixelSize: Theme.fs(19)
                      font.family: "JetBrainsMono Nerd Font"
                    }
                  }

                  ColumnLayout {
                    Layout.fillWidth: true
                    spacing: 1

                    Text {
                      text: "OozeShell"
                      color: Theme.text
                      font.bold: true
                      font.pixelSize: Theme.fs(14)
                      font.family: "JetBrainsMono Nerd Font"
                    }

                    Text {
                      Layout.fillWidth: true
                      elide: Text.ElideRight
                      text: Translations.t("advAboutBuiltWith")
                      color: Theme.subtext
                      font.pixelSize: Theme.fs(10)
                      font.family: "JetBrainsMono Nerd Font"
                    }
                  }
                }

                // ── Repos (GitHub) ──
                Rectangle {
                  Layout.fillWidth: true
                  implicitHeight: reposCol.implicitHeight + 20
                  radius: Theme.cardRadius
                  color: Theme.surface
                  clip: true

                  ColumnLayout {
                    id: reposCol
                    anchors { left: parent.left; right: parent.right; top: parent.top; margins: 10 }
                    spacing: 4

                    Repeater {
                      model: root.aboutRepos
                      delegate: Rectangle {
                        id: repoRow
                        required property var modelData
                        Layout.fillWidth: true
                        Layout.preferredHeight: 48
                        radius: 10
                        clip: true
                        color: repoArea.containsMouse ? Theme.surfaceHigh : "transparent"
                        Behavior on color { ColorAnimation { duration: 150 } }

                        RowLayout {
                          anchors { fill: parent; leftMargin: 10; rightMargin: 10 }
                          spacing: 12

                          Text {
                            text: repoRow.modelData.icon
                            color: Theme.primary
                            font.pixelSize: Theme.fs(16)
                            font.family: "JetBrainsMono Nerd Font"
                          }

                          ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 1
                            Text {
                              text: Translations.t(repoRow.modelData.titleKey)
                              color: Theme.text
                              font.bold: true
                              font.pixelSize: Theme.fs(12)
                              font.family: "JetBrainsMono Nerd Font"
                            }
                            Text {
                              Layout.fillWidth: true
                              elide: Text.ElideMiddle
                              text: repoRow.modelData.url.replace(/^https?:\/\//, "")
                              color: Theme.subtext
                              font.pixelSize: Theme.fs(10)
                              font.family: "JetBrainsMono Nerd Font"
                            }
                          }

                          Text {
                            text: "󰏌"
                            color: Theme.subtext
                            font.pixelSize: Theme.fs(13)
                            font.family: "JetBrainsMono Nerd Font"
                          }
                        }

                        MouseArea {
                          id: repoArea
                          anchors.fill: parent
                          hoverEnabled: true
                          cursorShape: Qt.PointingHandCursor
                          onClicked: Qt.openUrlExternally(repoRow.modelData.url)
                        }
                      }
                    }
                  }
                }

                // ── Información avanzada del sistema, colapsada por defecto ──
                ColumnLayout {
                  Layout.fillWidth: true
                  spacing: 0

                  Rectangle {
                    id: advToggleRow
                    Layout.fillWidth: true
                    Layout.preferredHeight: 44
                    radius: Theme.cardRadius
                    color: advToggleArea.containsMouse ? Theme.surfaceHigh : Theme.surface
                    clip: true

                    RowLayout {
                      anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                      spacing: 8

                      Text {
                        text: "󰆍"
                        color: Theme.subtext
                        font.pixelSize: Theme.fs(13)
                        font.family: "JetBrainsMono Nerd Font"
                      }
                      Text {
                        Layout.fillWidth: true
                        text: Translations.t("advAboutSysInfoTitle")
                        color: Theme.text
                        font.bold: true
                        font.pixelSize: Theme.fs(12)
                        font.family: "JetBrainsMono Nerd Font"
                      }
                      Text {
                        text: root.aboutAdvancedOpen ? "󰅃" : "󰅀"
                        color: Theme.subtext
                        font.pixelSize: Theme.fs(13)
                        font.family: "JetBrainsMono Nerd Font"
                      }
                    }

                    MouseArea {
                      id: advToggleArea
                      anchors.fill: parent
                      hoverEnabled: true
                      cursorShape: Qt.PointingHandCursor
                      onClicked: root.aboutToggleAdvanced()
                    }
                  }

                  Rectangle {
                    Layout.fillWidth: true
                    Layout.topMargin: 8
                    implicitHeight: sysRowsCol.implicitHeight + 24
                    radius: Theme.cardRadius
                    color: Theme.surface
                    visible: root.aboutAdvancedOpen
                    clip: true

                    ColumnLayout {
                      id: sysRowsCol
                      anchors { left: parent.left; right: parent.right; top: parent.top; margins: 12 }
                      spacing: 10

                      // ── Refrescar (gira mientras corren los comandos) ──
                      RowLayout {
                        Layout.fillWidth: true
                        Text {
                          Layout.fillWidth: true
                          text: Translations.t("advAboutSysInfoSource")
                          color: Theme.subtext
                          font.pixelSize: Theme.fs(10)
                          font.family: "JetBrainsMono Nerd Font"
                        }
                        Rectangle {
                          Layout.preferredWidth: 22
                          Layout.preferredHeight: 22
                          radius: 7
                          color: aboutRefreshArea.containsMouse ? Theme.surfaceHigh : "transparent"
                          Behavior on color { ColorAnimation { duration: 120 } }
                          Text {
                            anchors.centerIn: parent
                            text: "󰑐"
                            color: Theme.subtext
                            font.pixelSize: Theme.fs(11)
                            font.family: "JetBrainsMono Nerd Font"
                            RotationAnimation on rotation {
                              running: aboutSysInfoProc.running
                              loops: Animation.Infinite
                              from: 0; to: 360
                              duration: 700
                            }
                          }
                          MouseArea {
                            id: aboutRefreshArea
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            onClicked: root.aboutRefreshSysInfo()
                          }
                        }
                      }

                      Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

                      // ── Filas ícono + etiqueta + valor (mismo estilo que
                      // la tarjeta "SYSTEM" de la pestaña Usuario) ──
                      Repeater {
                        model: root.aboutSysInfoRows
                        delegate: RowLayout {
                          required property var modelData
                          Layout.fillWidth: true
                          spacing: 10
                          Text {
                            text: root.aboutIconFor(modelData.key)
                            color: Theme.primary
                            font.pixelSize: Theme.fs(13)
                            font.family: "JetBrainsMono Nerd Font"
                          }
                          Text {
                            text: modelData.key
                            color: Theme.subtext
                            font.pixelSize: Theme.fs(11)
                            font.family: "JetBrainsMono Nerd Font"
                          }
                          Item { Layout.fillWidth: true }
                          Text {
                            Layout.maximumWidth: 260
                            horizontalAlignment: Text.AlignRight
                            text: modelData.value
                            color: Theme.text
                            font.bold: true
                            font.pixelSize: Theme.fs(11)
                            elide: Text.ElideRight
                            font.family: "JetBrainsMono Nerd Font"
                          }
                        }
                      }

                      Text {
                        visible: root.aboutSysInfoRows.length === 0
                        Layout.fillWidth: true
                        wrapMode: Text.WordWrap
                        text: aboutSysInfoProc.running
                          ? Translations.t("advAboutSysInfoLoading")
                          : Translations.t("advAboutSysInfoEmpty")
                        color: Theme.subtext
                        font.italic: true
                        font.pixelSize: Theme.fs(11)
                        font.family: "JetBrainsMono Nerd Font"
                      }
                    }
                  }
                }
              }

              Item { Layout.preferredHeight: 4 }
            }
          }
        }
      }
    }
  }
}
