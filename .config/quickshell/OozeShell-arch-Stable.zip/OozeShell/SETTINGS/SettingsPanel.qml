// SettingsPanel — Ajustes del shell, como submenú del Menu (botón de la
// tuerca junto al usuario).
//
// Atajo (IPC), ver shell.qml:
//   quickshell ipc -p .../shell.qml call -- settings toggle
import Quickshell
import Quickshell.Io
import QtQuick
import QtQuick.Layouts
import "../COMMON"
import "../LANG"

Item {
  id: root

  property bool open: false
  property string targetScreen: ""

  property int cardWidth: 440
  property int edgeMargin: 10
  readonly property int pad: 18

  signal closeRequested()
  signal backRequested()
  signal requestMonitorPicker()
  signal requestLanguage()
  signal requestBarSettings()
  signal requestLauncherSettings()
  signal requestTerminalSettings()
  signal requestAdvancedSettings()

  // 0 = Interfaz · 1 = Usuario · 2 = General
  property int tab: 0

  readonly property var tabs: [
    { icon: "󰍹", key: "settingsTabUi" },
    { icon: "󰀄", key: "settingsTabProfile" },
    { icon: "󰒓", key: "settingsTabGeneral" }
  ]

  // Nombre del idioma activo (subtítulo de la fila "Idioma")
  readonly property string languageName: {
    const l = Translations.availableLanguages.find(x => x.code === Translations.current)
    return l ? l.name : ""
  }

  // Mostrando el explorador de imágenes
  property bool browsing: false

  onOpenChanged: { if (!root.open) root.browsing = false }
  onBrowsingChanged: { if (root.browsing) browser.go(browser.home + "/Pictures") }

  // ─── Detalles del sistema (pestaña Usuario) ──────────────────────
  // Se leen una sola vez, al abrir el panel: no cambian mientras corre
  // el shell (salvo el tiempo activo, que se refresca cada 30 s
  // mientras la pestaña está a la vista).
  property string sysHostname: ""
  property string sysOs: ""
  property string sysKernel: ""
  property string sysUptime: ""

  Process {
    id: hostnameProc
    command: ["hostname"]
    running: root.open && root.sysHostname === ""
    stdout: SplitParser { onRead: line => root.sysHostname = line.trim() }
  }
  Process {
    id: osProc
    command: ["bash", "-c",
      ". /etc/os-release 2>/dev/null || . /usr/lib/os-release 2>/dev/null; echo \"${PRETTY_NAME:-${NAME:-Linux}}\""]
    running: root.open && root.sysOs === ""
    stdout: SplitParser { onRead: line => root.sysOs = line.trim() }
  }
  Process {
    id: kernelProc
    command: ["uname", "-r"]
    running: root.open && root.sysKernel === ""
    stdout: SplitParser { onRead: line => root.sysKernel = line.trim() }
  }
  // /proc/uptime → "2d 3h 14m" (mismo formato que POWER/PowerMenu.qml)
  Process {
    id: uptimeProc
    command: ["cat", "/proc/uptime"]
    running: false
    stdout: SplitParser {
      onRead: line => {
        const s = Math.floor(parseFloat(line.split(" ")[0]))
        if (isNaN(s)) return
        const d = Math.floor(s / 86400)
        const h = Math.floor((s % 86400) / 3600)
        const m = Math.floor((s % 3600) / 60)
        root.sysUptime = d > 0 ? d + "d " + h + "h " + m + "m"
                       : h > 0 ? h + "h " + m + "m"
                       : m + "m"
      }
    }
  }
  Timer {
    interval: 30000
    running: root.open && root.tab === 1
    repeat: true
    triggeredOnStart: true
    onTriggered: if (!uptimeProc.running) uptimeProc.running = true
  }

  // Nombres de los 5 niveles (se re-evalúan al cambiar de idioma)
  readonly property var levelNames: [
    Translations.t("sizeSmall"), Translations.t("sizeMedium"), Translations.t("sizeNormal"),
    Translations.t("sizeLarge"), Translations.t("sizeHuge")
  ]

  // Nivel del selector general: solo si barra y ventanas coinciden
  readonly property int masterLevel: Theme.barLevel === Theme.windowLevel ? Theme.barLevel : -1

  function levelOf(kind) {
    return kind === "font" ? Theme.fontLevel : kind === "bar" ? Theme.barLevel : Theme.windowLevel
  }

  // Botón de texto (con icono opcional)
  component Btn: Rectangle {
    id: btn
    property string text: ""
    property string icon: ""
    property bool primary: false
    signal clicked()

    // Tamaño propio: sirve dentro de un Layout y también de un Flow
    implicitHeight: 34
    implicitWidth: btnRow.implicitWidth + 26
    Layout.preferredHeight: 34
    Layout.preferredWidth: btnRow.implicitWidth + 26
    radius: 10
    color: btn.primary
      ? (btnArea.containsMouse ? Qt.lighter(Theme.primary, 1.12) : Theme.primary)
      : (btnArea.containsMouse ? Theme.surfaceHigh : Theme.surface)
    Behavior on color { ColorAnimation { duration: 150 } }

    scale: btnArea.pressed ? 0.94 : 1.0
    Behavior on scale { NumberAnimation { duration: 140; easing.type: Easing.OutBack } }

    RowLayout {
      id: btnRow
      anchors.centerIn: parent
      spacing: 7
      Text {
        visible: btn.icon !== ""
        text: btn.icon
        color: btn.primary ? Theme.textOnPrimary : Theme.primary
        font.pixelSize: Theme.fs(15)
        font.family: "JetBrainsMono Nerd Font"
      }
      Text {
        text: btn.text
        color: btn.primary ? Theme.textOnPrimary : Theme.text
        font.pixelSize: Theme.fs(12)
        font.bold: true
        font.family: "JetBrainsMono Nerd Font"
      }
    }

    MouseArea {
      id: btnArea
      anchors.fill: parent
      hoverEnabled: true
      cursorShape: Qt.PointingHandCursor
      onClicked: btn.clicked()
    }
  }

  FusedWindow {
    id: fw
    active: root.open || panel.shown
    targetScreen: root.targetScreen
    namespace: "oozeshell-settings"
    onCloseRequested: root.closeRequested()

    FusedPanel {
      id: panel

      open: root.open
      // El ancho lógico se escala por la 4ta perilla de Configuración
      // avanzada (Theme.panelWidthScale) — el resto del contenido no se
      // toca, FusedPanel ya escala todo por Theme.windowScale además.
      panelWidth: Math.round(root.cardWidth * Theme.panelWidthScale)
      contentHeight: col.implicitHeight + root.pad * 2

      // Cuelga de la barra, del lado de su botón (derecha si es horizontal,
      // abajo si es vertical). FusedPanel se coloca solo según Theme.barPosition.
      align: "end"
      alignMargin: root.edgeMargin + Theme.barEdge + Theme.frameSideArm

      ColumnLayout {
        id: col
        x: root.pad
        y: root.pad
        width: parent.width - root.pad * 2
        spacing: 14

        PanelHeader {
          Layout.fillWidth: true
          icon: "󰒓"
          title: Translations.t("settingsTitle")
          onBackRequested: root.backRequested()
        }

        // ── Pestañas: Interfaz | Perfil | General ─────────────
        // Un "resaltador" (primary) que se desliza bajo la pestaña activa
        Rectangle {
          id: tabBar
          Layout.fillWidth: true
          Layout.preferredHeight: 38
          radius: 13
          color: Theme.surface

          readonly property real segW: (width - 6) / root.tabs.length

          Rectangle {
            x: 3 + root.tab * tabBar.segW
            y: 3
            width: tabBar.segW
            height: tabBar.height - 6
            radius: 10
            color: Theme.primary
            Behavior on x { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
          }

          Row {
            x: 3
            y: 3

            Repeater {
              model: root.tabs.length

              delegate: Item {
                id: seg
                required property int index

                readonly property bool current: root.tab === seg.index

                width: tabBar.segW
                height: tabBar.height - 6
                // Evita que textos largos (id/ja con fuente grande) se
                // derramen sobre el segmento vecino o fuera del panel.
                clip: true

                RowLayout {
                  anchors.fill: parent
                  anchors.leftMargin: 6
                  anchors.rightMargin: 6
                  spacing: 6

                  Item { Layout.fillWidth: true }

                  Text {
                    text: root.tabs[seg.index].icon
                    color: seg.current ? Theme.textOnPrimary : Theme.subtext
                    font.pixelSize: Theme.fs(14)
                    font.family: "JetBrainsMono Nerd Font"
                    Behavior on color { ColorAnimation { duration: 150 } }
                  }
                  Text {
                    Layout.fillWidth: true
                    Layout.maximumWidth: implicitWidth
                    text: Translations.t(root.tabs[seg.index].key)
                    color: seg.current ? Theme.textOnPrimary : Theme.subtext
                    font.pixelSize: Theme.fs(12)
                    font.bold: true
                    font.family: "JetBrainsMono Nerd Font"
                    // Si no entra ni recortado, se achica antes que
                    // desbordar (igual que LevelPicker con "Exorbitante").
                    fontSizeMode: Text.HorizontalFit
                    minimumPixelSize: 7
                    elide: Text.ElideRight
                    horizontalAlignment: Text.AlignHCenter
                    Behavior on color { ColorAnimation { duration: 150 } }
                  }

                  Item { Layout.fillWidth: true }
                }

                MouseArea {
                  anchors.fill: parent
                  hoverEnabled: true
                  cursorShape: Qt.PointingHandCursor
                  onClicked: root.tab = seg.index
                }
              }
            }
          }
        }

        // ══════════════════════════════════════════════════════
        // PESTAÑA 1 · INTERFAZ
        // ══════════════════════════════════════════════════════
        ColumnLayout {
          Layout.fillWidth: true
          visible: root.tab === 0
          spacing: 12

          // ── Selector general: barra + ventanas ─────────────
          RowLayout {
            Layout.fillWidth: true
            SectionLabel { text: Translations.t("uiSizeTitle") }
            Item { Layout.fillWidth: true }
            // Si barra y ventanas están en niveles distintos
            Text {
              visible: root.masterLevel < 0
              text: Translations.t("uiCustom")
              color: Theme.primary
              font.pixelSize: Theme.fs(11)
              font.family: "JetBrainsMono Nerd Font"
            }
          }

          Text {
            Layout.fillWidth: true
            text: Translations.t("uiSizeHint")
            wrapMode: Text.WordWrap
            color: Theme.subtext
            font.pixelSize: Theme.fs(10)
            font.family: "JetBrainsMono Nerd Font"
          }

          LevelPicker {
            level: root.masterLevel
            names: root.levelNames
            showNames: true
            onPicked: index => Theme.setInterfaceLevel(index)
          }

          Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

          // ── Ajuste fino: Fuente / Barra / Ventanas ─────────
          SectionLabel { text: Translations.t("uiFineTune") }

          Repeater {
            model: [
              { kind: "font",   label: "uiFont" },
              { kind: "bar",    label: "uiBar" },
              { kind: "window", label: "uiWindows" }
            ]

            delegate: RowLayout {
              Layout.fillWidth: true
              spacing: 10

              ColumnLayout {
                Layout.preferredWidth: 100
                Layout.maximumWidth: 140
                spacing: 0
                Text {
                  Layout.fillWidth: true
                  elide: Text.ElideRight
                  text: Translations.t(modelData.label)
                  color: Theme.text
                  font.bold: true
                  font.pixelSize: Theme.fs(12)
                  font.family: "JetBrainsMono Nerd Font"
                }
                Text {
                  Layout.fillWidth: true
                  elide: Text.ElideRight
                  text: root.levelNames[root.levelOf(modelData.kind)] ?? ""
                  color: Theme.subtext
                  font.pixelSize: Theme.fs(10)
                  font.family: "JetBrainsMono Nerd Font"
                }
              }

              LevelPicker {
                level: root.levelOf(modelData.kind)
                names: root.levelNames
                showNames: false
                onPicked: index => Theme.setLevel(modelData.kind, index)
              }
            }
          }

          Text {
            Layout.fillWidth: true
            text: Translations.t("uiFineHint")
            wrapMode: Text.WordWrap
            color: Theme.subtext
            font.pixelSize: Theme.fs(10)
            font.family: "JetBrainsMono Nerd Font"
          }

          Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

          // ── Tema: modo claro / oscuro ───────────────────────
          // Theme.lightMode elige la variante de la paleta de matugen (y
          // Walls le pasa `-m light|dark` a matugen para tus otras apps).
          SectionLabel { text: Translations.t("themeSection") }

          RowLayout {
            Layout.fillWidth: true
            spacing: 10

            Text {
              Layout.preferredWidth: Math.min(implicitWidth, 140)
              Layout.maximumWidth: 140
              elide: Text.ElideRight
              text: Translations.t("themeLightMode")
              color: Theme.text
              font.bold: true
              font.pixelSize: Theme.fs(12)
              font.family: "JetBrainsMono Nerd Font"
            }
            Btn {
              icon: Theme.lightMode ? "󰖨" : "󰖔"
              text: Theme.lightMode ? "ON" : "OFF"
              primary: Theme.lightMode
              onClicked: Theme.setLightMode(!Theme.lightMode)
            }
            // Bromita al lado del botón (cambia según el estado)
            Text {
              Layout.fillWidth: true
              Layout.minimumWidth: 0
              text: Translations.t(Theme.lightMode ? "themeLightJokeOn" : "themeLightJokeOff")
              wrapMode: Text.WordWrap
              maximumLineCount: 2
              elide: Text.ElideRight
              color: Theme.subtext
              font.italic: true
              font.pixelSize: Theme.fs(11)
              font.family: "JetBrainsMono Nerd Font"
            }
          }

          Text {
            Layout.fillWidth: true
            text: Translations.t("themeLightHint")
            wrapMode: Text.WordWrap
            color: Theme.subtext
            font.pixelSize: Theme.fs(10)
            font.family: "JetBrainsMono Nerd Font"
          }

          Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

          SectionLabel { text: Translations.t("dockSection") }

          ColumnLayout {
            Layout.fillWidth: true
            spacing: 6

            RowLayout {
              Layout.fillWidth: true
              spacing: 10

              Text {
                Layout.preferredWidth: Math.min(implicitWidth, 100)
                Layout.maximumWidth: 100
                elide: Text.ElideRight
                text: Translations.t("dockEnable")
                color: Theme.text
                font.bold: true
                font.pixelSize: Theme.fs(12)
                font.family: "JetBrainsMono Nerd Font"
              }
              Btn {
                icon: Theme.dockEnabled ? "󰇙" : "󰇘"
                text: Theme.dockEnabled ? "ON" : "OFF"
                primary: Theme.dockEnabled
                onClicked: Theme.setDockEnabled(!Theme.dockEnabled)
              }

              Text {
                Layout.preferredWidth: Math.min(implicitWidth, 100)
                Layout.maximumWidth: 100
                elide: Text.ElideRight
                text: Translations.t("dockAutoHide")
                color: Theme.text
                font.bold: true
                font.pixelSize: Theme.fs(12)
                font.family: "JetBrainsMono Nerd Font"
              }
              Btn {
                icon: Theme.dockAutoHide ? "▣" : "▢"
                text: Theme.dockAutoHide ? "ON" : "OFF"
                primary: Theme.dockAutoHide
                onClicked: Theme.setDockAutoHide(!Theme.dockAutoHide)
              }
              Item { Layout.fillWidth: true }
            }

            RowLayout {
              Layout.fillWidth: true
              spacing: 10
              opacity: Theme.barVertical ? 1.0 : 0.4

              Text {
                Layout.preferredWidth: Math.min(implicitWidth, 140)
                Layout.maximumWidth: 140
                elide: Text.ElideRight
                text: Translations.t("dockPosition")
                color: Theme.text
                font.bold: true
                font.pixelSize: Theme.fs(12)
                font.family: "JetBrainsMono Nerd Font"
              }
              Btn {
                icon: "▀"
                text: Translations.t("barTop")
                primary: Theme.dockPosition === "top"
                onClicked: { if (Theme.barVertical) Theme.setDockPosition("top") }
              }
              Btn {
                icon: "▄"
                text: Translations.t("barBottom")
                primary: Theme.dockPosition === "bottom"
                onClicked: { if (Theme.barVertical) Theme.setDockPosition("bottom") }
              }
              Item { Layout.fillWidth: true }
            }

          }

          Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

          RowLayout {
            Layout.fillWidth: true
            Item { Layout.fillWidth: true }
            Btn {
              text: Translations.t("uiReset")
              onClicked: Theme.resetLevels()
            }
          }
        }

        // ══════════════════════════════════════════════════════
        // PESTAÑA 2 · PERFIL
        // ══════════════════════════════════════════════════════
        ColumnLayout {
          Layout.fillWidth: true
          visible: root.tab === 1
          spacing: 12

          RowLayout {
            Layout.fillWidth: true
            spacing: 16

            Avatar {
              Layout.preferredWidth: 76
              Layout.preferredHeight: 76
              size: 76
              source: UserProfile.avatarUrl
              letter: UserProfile.userName.length > 0 ? UserProfile.userName.charAt(0).toUpperCase() : "?"
            }

            ColumnLayout {
              Layout.fillWidth: true
              Layout.minimumWidth: 0
              spacing: 6

              Text {
                Layout.fillWidth: true
                text: UserProfile.userName.length > 0 ? UserProfile.userName : "—"
                color: Theme.text
                font.bold: true
                font.pixelSize: Theme.fs(15)
                font.family: "JetBrainsMono Nerd Font"
                elide: Text.ElideRight
              }
              Text {
                Layout.fillWidth: true
                text: UserProfile.busy ? Translations.t("profileSaving")
                    : UserProfile.avatarSource !== "" ? Translations.t("profilePhoto")
                    : Translations.t("profileNoPhoto")
                color: Theme.subtext
                font.pixelSize: Theme.fs(11)
                font.family: "JetBrainsMono Nerd Font"
                elide: Text.ElideRight
              }

              RowLayout {
                spacing: 8
                Btn {
                  primary: true
                  icon: "󰋩"
                  text: UserProfile.avatarSource !== "" ? Translations.t("profileChange")
                                                        : Translations.t("profileChoose")
                  onClicked: root.browsing = !root.browsing
                }
                Btn {
                  visible: UserProfile.avatarPath !== ""
                  icon: "󰆴"
                  text: Translations.t("profileRemove")
                  onClicked: UserProfile.clearAvatar()
                }
              }
            }
          }

          Text {
            visible: root.browsing
            Layout.fillWidth: true
            text: Translations.t("profileBrowseHint")
            wrapMode: Text.WordWrap
            color: Theme.subtext
            font.pixelSize: Theme.fs(10)
            font.family: "JetBrainsMono Nerd Font"
          }

          ImageBrowser {
            id: browser
            visible: root.browsing
            Layout.fillWidth: true
            Layout.preferredHeight: 290

            onPicked: path => {
              UserProfile.chooseAvatar(path)
              root.browsing = false
            }
            onCancelled: root.browsing = false
          }

          Rectangle { Layout.fillWidth: true; Layout.preferredHeight: 1; color: Theme.divider }

          // ── Detalles del sistema ────────────────────────────
          SectionLabel { text: Translations.t("profileSystemSection") }

          Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: sysCol.implicitHeight + 20
            radius: Theme.cardRadius
            color: Theme.surface

            ColumnLayout {
              id: sysCol
              anchors { fill: parent; margins: 12 }
              spacing: 8

              Repeater {
                model: [
                  { icon: "󰍹", label: Translations.t("profileHostname"),  value: root.sysHostname },
                  { icon: "󰌽", label: Translations.t("profileOs"),        value: root.sysOs },
                  { icon: "󰆍", label: Translations.t("profileKernel"),    value: root.sysKernel },
                  { icon: "󱑂", label: Translations.t("profileUptimeLbl"), value: root.sysUptime }
                ]
                delegate: RowLayout {
                  Layout.fillWidth: true
                  spacing: 10
                  Text {
                    text: modelData.icon
                    color: Theme.primary
                    font.pixelSize: Theme.fs(13)
                    font.family: "JetBrainsMono Nerd Font"
                  }
                  Text {
                    text: modelData.label
                    color: Theme.subtext
                    font.pixelSize: Theme.fs(11)
                    font.family: "JetBrainsMono Nerd Font"
                  }
                  Item { Layout.fillWidth: true }
                  Text {
                    Layout.maximumWidth: 220
                    horizontalAlignment: Text.AlignRight
                    text: modelData.value.length > 0 ? modelData.value : "…"
                    color: Theme.text
                    font.bold: true
                    font.pixelSize: Theme.fs(11)
                    elide: Text.ElideRight
                    font.family: "JetBrainsMono Nerd Font"
                  }
                }
              }
            }
          }
        }

        // ══════════════════════════════════════════════════════
        // PESTAÑA 3 · GENERAL
        // ══════════════════════════════════════════════════════
        ColumnLayout {
          Layout.fillWidth: true
          visible: root.tab === 2
          spacing: 8

          // Cada fila abre su propia ventana (mismo patrón que Bluetooth /
          // Red desde el Menu): así esta pestaña queda como un índice
          // corto en vez de acumular los controles de cada tema.
          Repeater {
            model: [
              { icon: "󰍹", label: "settingsMonitor",         action: "monitor" },
              { icon: "󰗊", label: "settingsLanguage",        action: "lang" },
              { icon: "▀",  label: "barSection",              action: "bar" },
              { icon: "󰀻", label: "settingsLauncherSection",  action: "launcher" },
              { icon: "󰆍", label: "settingsTerminalSection",  action: "terminal" },
              { icon: "󰒓", label: "settingsAdvancedSection",  action: "advanced" }
            ]

            delegate: Rectangle {
              Layout.fillWidth: true
              Layout.preferredHeight: 46
              radius: 10
              color: rowArea.containsMouse ? Theme.surfaceHigh : Theme.surface
              Behavior on color { ColorAnimation { duration: 150 } }

              RowLayout {
                anchors { fill: parent; leftMargin: 14; rightMargin: 14 }
                spacing: 10

                Text {
                  text: modelData.icon
                  color: Theme.primary
                  font.pixelSize: Theme.fs(15)
                  font.family: "JetBrainsMono Nerd Font"
                }
                Text {
                  text: Translations.t(modelData.label)
                  color: Theme.text
                  font.pixelSize: Theme.fs(12)
                  font.bold: true
                  font.family: "JetBrainsMono Nerd Font"
                }
                Item { Layout.fillWidth: true }
                // Valor actual: monitor del shell / idioma activo (las demás
                // filas son categorías, sin un único valor que resumir)
                Text {
                  visible: text !== ""
                  Layout.maximumWidth: 180
                  text: modelData.action === "monitor" ? root.targetScreen
                      : modelData.action === "lang" ? root.languageName
                      : ""
                  color: Theme.subtext
                  font.pixelSize: Theme.fs(11)
                  font.family: "JetBrainsMono Nerd Font"
                  elide: Text.ElideRight
                }
                Text {
                  text: "󰅂"
                  color: Theme.subtext
                  font.pixelSize: Theme.fs(11)
                  font.family: "JetBrainsMono Nerd Font"
                }
              }

              MouseArea {
                id: rowArea
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                  switch (modelData.action) {
                    case "monitor":      root.requestMonitorPicker(); break
                    case "lang":         root.requestLanguage(); break
                    case "bar":          root.requestBarSettings(); break
                    case "launcher":     root.requestLauncherSettings(); break
                    case "terminal":     root.requestTerminalSettings(); break
                    case "advanced":     root.requestAdvancedSettings(); break
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
