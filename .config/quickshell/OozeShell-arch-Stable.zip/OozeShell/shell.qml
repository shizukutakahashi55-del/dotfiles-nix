// OozeShell Wallpapers and More

import Quickshell
import Quickshell.Io
import Quickshell.Hyprland
import QtQuick
import "./WALLS"
import "./NOTIFY"
import "./MPRIS"
import "./MONITOR"
import "./Keybinds"
import "./Launcher"
import "./PACSEARCH"
import "./SCREENSHOT"
import "./LANG"
import "./APPEARANCE"
import "./SETTINGS"
import "./BAR"
import "./DOCK"
import "./MENU"
import "./COMMON"
import "./NETWORK"
import "./BLUETOOTH"
import "./AUDIO"
import "./CAPS"
import "./OVERVIEW"
import "./POWER"


ShellRoot {
  id: root

  property bool wallsOpen:     false
  property bool mprisOpen:     false
  property bool keybindsOpen:  false
  property int  currentWallIndex: 0
  property bool monitorPickerOpen: false
  property bool monitorEditorOpen: false
  property bool langPickerOpen: false
  property bool appearancePickerOpen: false
  property bool settingsOpen: false
  property bool barSettingsOpen: false
  property bool launcherSettingsOpen: false
  property bool terminalSettingsOpen: false
  property bool advancedSettingsOpen: false
  property bool menuOpen: false
  property bool notifyOpen: false
  property bool networkOpen: false
  property bool bluetoothOpen: false
  property bool audioOpen: false
  property bool overviewOpen: false
  property bool launcherOpen: false
  property bool pacSearchOpen: false
  // Menú de energía (pantalla completa, modal): NO es un popup de la barra,
  // por eso no entra en isPopupOpen/closeAllPopups. Ver POWER/PowerMenu.qml.
  property bool powerOpen: false

  // ─── Esquinas de pantalla ("marco") ─────────────────────────────
  // Las 4 piecitas curvas de Bar.qml. Mismo patrón que monitor/lang:
  // persistido en disco y cambiable en caliente por IPC, además del botón
  // del Menú (junto al usuario).
  //   quickshell ipc -p .../shell.qml call -- corners toggle
  //   quickshell ipc -p .../shell.qml call -- corners set true
  //   quickshell ipc -p .../shell.qml call -- corners get
  property bool screenCorners: true
  // Espejo en Theme: así cualquier popup (Menu, AudioMenu, NetworkMenu...)
  // puede leer "¿el marco está prendido?" sin que shell.qml tenga que
  // pasárselo como prop uno por uno (son ~15 archivos). Theme.frameSideArm
  // (COMMON/Theme.qml) es lo que en realidad usan para su alignMargin.
  onScreenCornersChanged: Theme.screenCorners = root.screenCorners
  property string cornersCacheFile: Quickshell.env("HOME") + "/.cache/oozeshell-corners"

  Process {
    id: loadCorners
    command: ["bash", "-c", "cat '" + root.cornersCacheFile + "' 2>/dev/null"]
    running: true
    property string buffer: ""
    stdout: SplitParser { onRead: line => loadCorners.buffer += line }
    onRunningChanged: {
      if (!running) {
        const saved = loadCorners.buffer.trim()
        // Sin archivo todavía = queda el valor por defecto (activadas)
        if (saved !== "") root.screenCorners = (saved === "1")
        loadCorners.buffer = ""
      }
    }
  }

  Process {
    id: saveCorners
    property string value: "1"
    command: ["bash", "-c", "echo -n '" + value + "' > '" + root.cornersCacheFile + "'"]
    running: false
  }

  function setScreenCorners(on) {
    root.screenCorners = on
    saveCorners.value = on ? "1" : "0"
    saveCorners.running = false
    saveCorners.running = true
  }

  IpcHandler {
    target: "corners"
    function toggle(): void { root.setScreenCorners(!root.screenCorners) }
    function set(on: bool): void { root.setScreenCorners(on) }
    function get(): bool { return root.screenCorners }
  }

  // ─── Barra: posición y modo flotante ────────────────────────────
  // También desde Ajustes → Interfaz. Se persiste en ui.json (Theme).
  //   quickshell ipc -p .../shell.qml call -- bar position top|bottom|left|right
  //   quickshell ipc -p .../shell.qml call -- bar togglePosition
  //   quickshell ipc -p .../shell.qml call -- bar floating true|false
  //   quickshell ipc -p .../shell.qml call -- bar toggleFloating
  //   quickshell ipc -p .../shell.qml call -- bar islands true|false
  //   quickshell ipc -p .../shell.qml call -- bar toggleIslands
  //   quickshell ipc -p .../shell.qml call -- bar get
  // togglePosition da la vuelta al lado opuesto sobre el mismo eje
  // (top↔bottom, left↔right). Flotante solo tiene efecto con la barra
  // arriba o abajo; la preferencia se guarda igual.
  IpcHandler {
    target: "bar"
    function position(p: string): void { Theme.setBarPosition(p) }
    function togglePosition(): void {
      const flip = { top: "bottom", bottom: "top", left: "right", right: "left" }
      Theme.setBarPosition(flip[Theme.barPosition] ?? "top")
    }
    function floating(on: bool): void { Theme.setBarFloating(on) }
    function toggleFloating(): void { Theme.setBarFloating(!Theme.barFloatingPref) }
    // Modo Islas: sin fondo de barra, cada popup nace de su isla
    function islands(on: bool): void { Theme.setIslandsEnabled(on) }
    function toggleIslands(): void { Theme.setIslandsEnabled(!Theme.islandsPref) }
    function get(): string {
      return JSON.stringify({ position: Theme.barPosition, floating: Theme.barFloatingPref,
                              islands: Theme.islandsPref })
    }
  }

  // ─── Selector de monitor ────────────────────────────────────────
  // Un solo lugar para decidir en qué pantalla vive el shell.
  // Walls/Notify/Mpris leen esta property en vez de tener el nombre
  // de la pantalla hardcodeado cada uno. Se persiste en disco para
  // que sobreviva a un reinicio de Quickshell, y se puede cambiar
  // en caliente por IPC sin editar QML ni reiniciar nada:
  //   quickshell ipc -p .../shell.qml call -- monitor set DP-3
  //   quickshell ipc -p .../shell.qml call -- monitor set auto
  //   quickshell ipc -p .../shell.qml call -- monitor list
  //   quickshell ipc -p .../shell.qml call -- monitor get
  //   quickshell ipc -p .../shell.qml call -- monitor current
  //
  // targetMonitor puede ser el nombre de una pantalla fija (DP-3, HDMI-A-1,
  // etc.) o el valor especial "auto": en ese modo no hay pantalla fija,
  // sino que cada cosa que se abre sin saber "desde dónde" la llamaron
  // (IPC, atajo de teclado) usa resolveMonitor() de abajo, que pregunta a
  // Hyprland cuál es la pantalla bajo el mouse en ESE momento.
  property string targetMonitor: "DP-3"
  property string monitorCacheFile: Quickshell.env("HOME") + "/.cache/oozeshell-monitor"

  // Pantalla que usa Hyprland "ahora": Hyprland actualiza esto solo, sin
  // necesidad de click, apenas el mouse cruza a otro monitor. Es la base
  // del modo "auto".
  function resolveMonitor() {
    if (root.targetMonitor !== "auto") return root.targetMonitor
    const hm = Hyprland.focusedMonitor
    if (hm && hm.name) return hm.name
    // Sin info de Hyprland todavía (arranque): primera pantalla conocida.
    return Quickshell.screens.length > 0 ? Quickshell.screens[0].name : root.focusedMonitor
  }

  // focusedMonitor: pantalla donde se abre el PRÓXIMO popup/menú/toggle.
  // Es lo que usan todos los `targetScreen:` de acá abajo — targetMonitor
  // sigue siendo el "monitor por defecto" que se elige a mano en Ajustes
  // (y el que se persiste en disco); focusedMonitor arranca igual a ese
  // valor pero cada botón de la barra lo actualiza a SU propia pantalla
  // al tocarlo (ver Bar{} más abajo), así el panel aparece donde uno está
  // parado en vez de saltar siempre a la pantalla "por defecto".
  // Los toggles disparados por IPC/atajo de teclado (sin click en la
  // barra) no tienen forma de saber dónde estás, así que usan el último
  // focusedMonitor conocido (o targetMonitor si todavía no tocaste nada).
  property string focusedMonitor: root.targetMonitor

  // ─── Popups de la barra ─────────────────────────────────────────
  // menu / notify / network / bluetooth / audio / mpris / appearance / settings / barsettings / launchersettings / terminalsettings / monitor / lang / overview / keybinds / launcher / pacsearch.
  // Todos cuelgan de la barra y comparten zona, así que son
  // excluyentes: abrir uno cierra los otros (antes se apilaban).
  function isPopupOpen(name) {
    return name === "menu" ? root.menuOpen
         : name === "notify" ? root.notifyOpen
         : name === "network" ? root.networkOpen
         : name === "bluetooth" ? root.bluetoothOpen
         : name === "audio" ? root.audioOpen
         : name === "appearance" ? root.appearancePickerOpen
         : name === "settings" ? root.settingsOpen
         : name === "barsettings" ? root.barSettingsOpen
         : name === "launchersettings" ? root.launcherSettingsOpen
         : name === "terminalsettings" ? root.terminalSettingsOpen
         : name === "advancedsettings" ? root.advancedSettingsOpen
         : name === "monitor" ? root.monitorPickerOpen
         : name === "monitoreditor" ? root.monitorEditorOpen
         : name === "lang" ? root.langPickerOpen
         : name === "overview" ? root.overviewOpen
         : name === "keybinds" ? root.keybindsOpen
         : name === "launcher" ? root.launcherOpen
         : name === "pacsearch" ? root.pacSearchOpen
         : root.mprisOpen
  }

  function closeAllPopups() {
    root.menuOpen = false
    root.notifyOpen = false
    root.networkOpen = false
    root.bluetoothOpen = false
    root.audioOpen = false
    root.mprisOpen = false
    root.appearancePickerOpen = false
    root.settingsOpen = false
    root.barSettingsOpen = false
    root.launcherSettingsOpen = false
    root.terminalSettingsOpen = false
    root.advancedSettingsOpen = false
    root.monitorPickerOpen = false
    root.monitorEditorOpen = false
    root.langPickerOpen = false
    root.overviewOpen = false
    root.keybindsOpen = false
    root.launcherOpen = false
    root.pacSearchOpen = false
  }

  // screen es opcional: lo pasan los botones de la barra, que SÍ saben en
  // qué pantalla física los tocaste. Si no viene (IPC, atajo de teclado,
  // navegación interna entre popups), se resuelve solo con
  // resolveMonitor() — fijo o "auto" según targetMonitor.
  function openPopup(name, screen) {
    root.closeAllPopups()
    root.focusedMonitor = screen || root.resolveMonitor()
    if (name === "menu") root.menuOpen = true
    else if (name === "notify") root.notifyOpen = true
    else if (name === "network") root.networkOpen = true
    else if (name === "bluetooth") root.bluetoothOpen = true
    else if (name === "audio") root.audioOpen = true
    else if (name === "appearance") root.appearancePickerOpen = true
    else if (name === "settings") root.settingsOpen = true
    else if (name === "barsettings") root.barSettingsOpen = true
    else if (name === "launchersettings") root.launcherSettingsOpen = true
    else if (name === "terminalsettings") root.terminalSettingsOpen = true
    else if (name === "advancedsettings") root.advancedSettingsOpen = true
    else if (name === "monitor") root.monitorPickerOpen = true
    else if (name === "monitoreditor") root.monitorEditorOpen = true
    else if (name === "lang") root.langPickerOpen = true
    else if (name === "overview") root.overviewOpen = true
    else if (name === "keybinds") root.keybindsOpen = true
    else if (name === "launcher") root.launcherOpen = true
    else if (name === "pacsearch") root.pacSearchOpen = true
    else root.mprisOpen = true
  }

  function togglePopup(name, screen) {
    const wasOpen = root.isPopupOpen(name)
    root.closeAllPopups()
    if (!wasOpen) root.openPopup(name, screen)
  }

  // Pasar de un popup a otro (ej. Menu → Network): primero se cierra el
  // actual y, cuando termina su animación, se abre el siguiente en el
  // mismo sitio. Así no se pisan dos paneles a la vez. Se queda en la
  // misma pantalla donde ya estaba (no vuelve a resolver "auto": si abrí
  // Ajustes en la pantalla 2, Ajustes→Monitor también aparece ahí).
  property string pendingPopup: ""
  property string pendingScreen: ""
  function swapTo(name, screen) {
    root.closeAllPopups()
    root.pendingPopup = name
    root.pendingScreen = screen || root.focusedMonitor
    popupSwapTimer.restart()
  }
  Timer {
    id: popupSwapTimer
    interval: 230
    repeat: false
    onTriggered: root.openPopup(root.pendingPopup, root.pendingScreen)
  }

  // Mismo agregado que arma `popupOpen` para la barra (ver más abajo), sin
  // "notify": ese caso ya lo cubre NotificationsBackend.centerOpen. Un
  // Binding en vez de tocar Notify.qml/Bar.qml: NotificationsBackend es un
  // singleton, así que se le puede asignar la propiedad desde cualquier
  // lado sin que ese componente necesite saber nada de este flag.
  readonly property bool otherBarPopupOpen:
    root.menuOpen || root.networkOpen || root.bluetoothOpen
    || root.audioOpen || root.mprisOpen || root.overviewOpen
    || root.appearancePickerOpen || root.settingsOpen || root.monitorPickerOpen
    || root.monitorEditorOpen
    || root.barSettingsOpen || root.launcherSettingsOpen || root.terminalSettingsOpen || root.advancedSettingsOpen
    || root.langPickerOpen || root.keybindsOpen || root.powerOpen
    || root.launcherOpen || root.pacSearchOpen

  Binding {
    target: NotificationsBackend
    property: "otherPopupOpen"
    value: root.otherBarPopupOpen
  }

  Bar {
    id: bar
    menuOpen: root.menuOpen
    notifyOpen: root.notifyOpen
    mprisOpen: root.mprisOpen
    audioOpen: root.audioOpen
    overviewOpen: root.overviewOpen
    screenCorners: root.screenCorners
    popupOpen: root.menuOpen || root.notifyOpen || root.networkOpen
               || root.bluetoothOpen
               || root.audioOpen || root.mprisOpen || root.overviewOpen
               || root.appearancePickerOpen || root.settingsOpen || root.monitorPickerOpen
               || root.monitorEditorOpen
               || root.barSettingsOpen || root.launcherSettingsOpen || root.terminalSettingsOpen || root.advancedSettingsOpen
               || root.langPickerOpen || root.keybindsOpen || root.powerOpen
               || root.launcherOpen || root.pacSearchOpen
    // Solo mientras se recargan los colores (no por abrir el selector)
    wallpaperChanging: walls.changing
    onTrayMenuOpened: root.closeAllPopups()
    onMenuButtonClicked: (screen) => { root.togglePopup("menu", screen.name) }
    onNotificationButtonClicked: (screen) => { root.togglePopup("notify", screen.name) }
    onOverviewButtonClicked: (screen) => { root.togglePopup("overview", screen.name) }
    onMprisButtonClicked: (screen) => { root.togglePopup("mpris", screen.name) }
    onAudioButtonClicked: (screen) => { root.togglePopup("audio", screen.name) }
    onPowerButtonClicked: (screen) => { root.focusedMonitor = screen.name; root.closeAllPopups(); root.powerOpen = !root.powerOpen }
  }

  // ─── Dock ─────────────────────────────────────────────────────
  // Encendido/apagado en Ajustes → Interfaz → Dock (Theme.dockEnabled).
  // Igual que Bar, Dock.qml ya trae adentro su propio Variants por pantalla.
  Dock {
    id: dock
    // Mismo criterio que la barra: con un popup abierto no hay tooltips
    popupOpen: root.otherBarPopupOpen || root.notifyOpen
  }
  

  Process {
    id: loadMonitor
    command: ["bash", "-c", "cat '" + root.monitorCacheFile + "' 2>/dev/null"]
    running: true
    property string buffer: ""
    stdout: SplitParser { onRead: line => loadMonitor.buffer += line }
    onRunningChanged: {
      if (!running) {
        const saved = loadMonitor.buffer.trim()
        if (saved !== "") root.targetMonitor = saved
        loadMonitor.buffer = ""
      }
    }
  }

  Process {
    id: saveMonitor
    property string value: ""
    command: ["bash", "-c", "echo -n " + "'" + value + "'" + " > '" + root.monitorCacheFile + "'"]
    running: false
  }

  function setMonitor(name) {
    root.targetMonitor = name
    root.focusedMonitor = root.resolveMonitor()
    saveMonitor.value = name
    saveMonitor.running = false
    saveMonitor.running = true
  }

  IpcHandler {
    target: "monitor"
    // name también acepta "auto"
    function set(name: string): void { root.setMonitor(name) }
    // Valor crudo de la preferencia ("DP-3" o "auto")
    function get(): string { return root.targetMonitor }
    function togglePicker(): void { root.togglePopup("monitor") }
    // Lista las pantallas conectadas ahora mismo, así no hay que
    // adivinar el nombre exacto (DP-3, HDMI-A-1, etc).
    function list(): string {
      return Quickshell.screens.map(s => s.name).join(", ")
    }
    // Pantalla que se usaría AHORA MISMO si algo se abriera ya: igual a
    // get() salvo en modo "auto", donde muestra la detectada por el mouse.
    function current(): string { return root.resolveMonitor() }
  }

  // ─── Selector de idioma ─────────────────────────────────────────
  // Mismo patrón que targetMonitor: una property global, persistida
  // en disco, cambiable en caliente por IPC. Cualquier componente
  // que quiera texto traducido importa "./LANG" y lee
  // Translations.t("clave") o Translations.sections() — no hace
  // falta pasarle el idioma a mano a cada uno, porque Translations
  // es un singleton compartido por todo el shell.
  //   quickshell ipc -p .../shell.qml call -- lang set es
  //   quickshell ipc -p .../shell.qml call -- lang togglePicker
  //   quickshell ipc -p .../shell.qml call -- lang get
  property string currentLang: "en"
  property string langCacheFile: Quickshell.env("HOME") + "/.cache/oozeshell-lang"

  Process {
    id: loadLang
    command: ["bash", "-c", "cat '" + root.langCacheFile + "' 2>/dev/null"]
    running: true
    property string buffer: ""
    stdout: SplitParser { onRead: line => loadLang.buffer += line }
    onRunningChanged: {
      if (!running) {
        const saved = loadLang.buffer.trim()
        if (saved !== "") root.currentLang = saved
        loadLang.buffer = ""
      }
    }
  }

  Process {
    id: saveLang
    property string value: ""
    command: ["bash", "-c", "echo -n " + "'" + value + "'" + " > '" + root.langCacheFile + "'"]
    running: false
  }

  function setLang(code) {
    root.currentLang = code
    saveLang.value = code
    saveLang.running = false
    saveLang.running = true
  }

  // Mantiene el singleton Translations sincronizado con la
  // property persistida (incluida la carga inicial desde disco).
  onCurrentLangChanged: Translations.current = root.currentLang

  IpcHandler {
    target: "lang"
    function set(code: string): void { root.setLang(code) }
    function get(): string { return root.currentLang }
    function togglePicker(): void { root.togglePopup("lang") }
    function list(): string {
      return Translations.availableLanguages.map(l => l.code + " (" + l.name + ")").join(", ")
    }
  }

  LanguagePicker {
    id: languagePicker
    open: root.langPickerOpen
    current: root.currentLang
    targetScreen: root.focusedMonitor
    onCloseRequested: root.langPickerOpen = false
    onBackRequested: root.swapTo("settings")
    onLanguageChosen: (code) => root.setLang(code)
  }

  // ─── Ajustes (tamaño de la interfaz + foto de perfil + monitor/idioma) ─
  // El estado vive en singletons de COMMON/ (se persiste en
  // ~/.config/oozeshell/): Theme guarda los 3 niveles de tamaño
  // (Theme.fontLevel / barLevel / windowLevel, de 0 = Pequeño a
  // 4 = Exorbitante) y UserProfile la foto. Este panel solo los cambia.
  //   quickshell ipc -p .../shell.qml call -- settings toggle
  //   quickshell ipc -p .../shell.qml call -- settings get
  //   quickshell ipc -p .../shell.qml call -- settings setUi 3        (barra + ventanas)
  //   quickshell ipc -p .../shell.qml call -- settings setLevel font 4   (font | bar | window)
  //   quickshell ipc -p .../shell.qml call -- settings reset
  IpcHandler {
    target: "settings"
    function toggle(): void { root.togglePopup("settings") }
    function get(): string {
      return JSON.stringify({ font: Theme.fontLevel, bar: Theme.barLevel, window: Theme.windowLevel })
    }
    function setUi(level: int): void { Theme.setInterfaceLevel(level) }
    function setLevel(kind: string, level: int): void { Theme.setLevel(kind, level) }
    function reset(): void { Theme.resetLevels() }
  }

  // Modo claro / oscuro (también está en Ajustes → Interfaz → Tema)
  //   quickshell ipc -p .../shell.qml call -- theme mode light|dark
  //   quickshell ipc -p .../shell.qml call -- theme toggle
  //   quickshell ipc -p .../shell.qml call -- theme get
  IpcHandler {
    target: "theme"
    function mode(m: string): void { Theme.setLightMode(m === "light") }
    function toggle(): void { Theme.setLightMode(!Theme.lightMode) }
    function get(): string { return Theme.schemeMode }
  }

  SettingsPanel {
    id: settingsPanel
    open: root.settingsOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.settingsOpen = false
    onBackRequested: root.swapTo("menu")
    onRequestMonitorPicker: root.swapTo("monitor")
    onRequestLanguage: root.swapTo("lang")
    onRequestBarSettings: root.swapTo("barsettings")
    onRequestLauncherSettings: root.swapTo("launchersettings")
    onRequestTerminalSettings: root.swapTo("terminalsettings")
    onRequestAdvancedSettings: root.swapTo("advancedsettings")
  }

  AdvancedSettings {
    id: advancedSettings
    open: root.advancedSettingsOpen
    targetScreen: root.focusedMonitor
    appearanceValues: root.appearance
    onCloseRequested: root.advancedSettingsOpen = false
    onBackRequested: root.swapTo("settings")
    onRequestMonitorEditor: root.swapTo("monitoreditor")
    onAppearancePreviewChanged: (key, value) => root.applyAppearanceLive(key, value)
    onAppearanceValueCommitted: (key, value) => root.setAppearanceValue(key, value)
    onAppearanceToggleChanged: (key, value) => root.setAppearanceValue(key, value)
    // Marco de pantalla (Interfaz → Marco): mismo estado que el botón del
    // Menú (ver más abajo) y el IPC `corners toggle`.
    screenCorners: root.screenCorners
    onRequestCornersToggle: root.setScreenCorners(!root.screenCorners)
  }

  // Sub-ventanas de Ajustes → General (mismo patrón que Monitor/Idioma):
  // cada una vuelve a Ajustes con la flecha ‹.
  MonitorEditor {
    id: monitorEditor
    open: root.monitorEditorOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.monitorEditorOpen = false
    onBackRequested: root.swapTo("advancedsettings")
  }

  BarSettings {
    id: barSettings
    open: root.barSettingsOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.barSettingsOpen = false
    onBackRequested: root.swapTo("settings")
  }

  LauncherSettings {
    id: launcherSettings
    open: root.launcherSettingsOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.launcherSettingsOpen = false
    onBackRequested: root.swapTo("settings")
  }

  TerminalSettings {
    id: terminalSettings
    open: root.terminalSettingsOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.terminalSettingsOpen = false
    onBackRequested: root.swapTo("settings")
  }

  // ─── Apariencia + Layouts ────────────────────────────────────────
  // Mismo patrón que monitor/lang: una property "appearance" (objeto),
  // persistida en un cache JSON, cambiable en caliente por IPC. La
  // diferencia es que además de guardar el cache, cada cambio:
  //   1) se aplica al toque con `hyprctl keyword ...` (feedback
  //      instantáneo, sin tocar ningún archivo ni recargar nada)
  //   2) regenera ~/.config/hypr/theme.lua y ~/.config/hypr/layouts.lua,
  //      que tu hyprland.lua importa con require("theme") / require("layouts")
  //      para que el valor sobreviva a un reinicio real de Hyprland.
  //
  //   quickshell ipc -p .../shell.qml call -- appearance toggle
  //   quickshell ipc -p .../shell.qml call -- appearance get
  //   quickshell ipc -p .../shell.qml call -- appearance set gapsOut 10
  //   quickshell ipc -p .../shell.qml call -- appearance set blurEnabled true
  //   quickshell ipc -p .../shell.qml call -- appearance set layout master
  property var appearance: ({
    gapsIn: 3, gapsOut: 6, borderSize: 2,
    rounding: 10, roundingPower: 5,
    activeOpacity: 1.0, inactiveOpacity: 1.0,
    blurEnabled: true, blurSize: 3, blurPasses: 1,
    shadowEnabled: false, shadowRange: 3, shadowRenderPower: 1,
    animationsEnabled: true,
    layout: "dwindle"
  })
  property string appearanceCacheFile: Quickshell.env("HOME") + "/.cache/oozeshell-appearance.json"

  // Traduce cada clave del objeto "appearance" a la ruta de tabla
  // anidada que usa hl.config() en Lua (ej. decoration.blur.enabled).
  // Hyprland 0.55+ corre con configProvider: lua, así que el clásico
  // `hyprctl keyword <opcion> <valor>` viene deshabilitado ("unknown
  // request"); el reemplazo es `hyprctl eval '<código lua>'`, que
  // ejecuta directamente un hl.config({...}) equivalente.
  readonly property var appearanceLuaPath: ({
    gapsIn:            ["general", "gaps_in"],
    gapsOut:           ["general", "gaps_out"],
    borderSize:        ["general", "border_size"],
    rounding:          ["decoration", "rounding"],
    roundingPower:     ["decoration", "rounding_power"],
    activeOpacity:     ["decoration", "active_opacity"],
    inactiveOpacity:   ["decoration", "inactive_opacity"],
    blurEnabled:       ["decoration", "blur", "enabled"],
    blurSize:          ["decoration", "blur", "size"],
    blurPasses:        ["decoration", "blur", "passes"],
    shadowEnabled:     ["decoration", "shadow", "enabled"],
    shadowRange:       ["decoration", "shadow", "range"],
    shadowRenderPower: ["decoration", "shadow", "render_power"],
    animationsEnabled: ["animations", "enabled"]
  })

  // Arma un literal de tabla Lua anidada a partir de un path y un
  // valor. Ej: (["decoration","blur","enabled"], true) ->
  // "{ decoration = { blur = { enabled = true } } }"
  function buildLuaTable(path, value) {
    const v = (typeof value === "boolean") ? (value ? "true" : "false") : value
    let expr = String(v)
    for (let i = path.length - 1; i >= 0; i--) {
      expr = "{ " + path[i] + " = " + expr + " }"
    }
    return expr
  }

  Process {
    id: loadAppearance
    command: ["bash", "-c", "cat '" + root.appearanceCacheFile + "' 2>/dev/null"]
    running: true
    property string buffer: ""
    stdout: SplitParser { onRead: line => loadAppearance.buffer += line }
    onRunningChanged: {
      if (!running) {
        const saved = loadAppearance.buffer.trim()
        if (saved !== "") {
          try {
            root.appearance = Object.assign({}, root.appearance, JSON.parse(saved))
          } catch (e) {
            console.log("appearance cache parse error:", e)
          }
        }
        loadAppearance.buffer = ""
        // Asegura que theme.lua / layouts.lua existan siempre, incluso
        // en la primera corrida (sin cache todavía), para que el
        // require("theme") / require("layouts") de hyprland.lua no falle.
        root.writeThemeLua()
        root.writeLayoutsLua(root.appearance.layout)
      }
    }
  }

  Process {
    id: applyAppearanceKeyword
    property string cmd: ""
    command: ["bash", "-c", cmd]
    running: false
    stdout: SplitParser { onRead: line => console.log("[appearance] hyprctl:", line) }
    stderr: SplitParser { onRead: line => console.log("[appearance] hyprctl error:", line) }
  }

  // Preview instantáneo: NO toca disco, solo aplica en vivo vía
  // `hyprctl eval` (el reemplazo de `hyprctl keyword` en modo lua).
  // Se llama en cada movimiento del slider (onPreviewChanged).
  function applyAppearanceLive(key, value) {
    const path = root.appearanceLuaPath[key]
    if (!path) return
    const table = root.buildLuaTable(path, value)
    applyAppearanceKeyword.cmd = "hyprctl eval 'hl.config(" + table + ")'"
    applyAppearanceKeyword.running = false
    applyAppearanceKeyword.running = true
  }

  Process {
    id: saveAppearanceCache
    property string json: ""
    command: ["bash", "-c",
      "cat > '" + root.appearanceCacheFile + "' << 'OOZE_EOF'\n" + json + "\nOOZE_EOF\n"]
    running: false
  }

  function writeAppearanceCache() {
    saveAppearanceCache.json = JSON.stringify(root.appearance)
    saveAppearanceCache.running = false
    saveAppearanceCache.running = true
  }

  Process {
    id: saveThemeLua
    property string content: ""
    command: ["bash", "-c",
      "cat > '" + Quickshell.env("HOME") + "/.config/hypr/modules/appearance/autogen/theme.lua' << 'OOZE_LUA_EOF'\n" + content + "\nOOZE_LUA_EOF\n"]
    running: false
  }

  // Regenera ~/.config/hypr/theme.lua a partir de root.appearance.
  // Es un archivo generado: no se edita a mano, se pisa cada vez.
  function writeThemeLua() {
    const a = root.appearance
    const lua =
      "-- Auto-generado por OozeShell (APPEARANCE). No editar a mano.\n" +
      "-- Se regenera cada vez que cambiás algo desde el panel de apariencia.\n" +
      "return {\n" +
      "    gaps_in = " + a.gapsIn + ",\n" +
      "    gaps_out = " + a.gapsOut + ",\n" +
      "    border_size = " + a.borderSize + ",\n" +
      "    rounding = " + a.rounding + ",\n" +
      "    rounding_power = " + a.roundingPower + ",\n" +
      "    active_opacity = " + a.activeOpacity + ",\n" +
      "    inactive_opacity = " + a.inactiveOpacity + ",\n" +
      "    animations = " + (a.animationsEnabled ? "true" : "false") + ",\n" +
      "    blur = {\n" +
      "        enabled = " + (a.blurEnabled ? "true" : "false") + ",\n" +
      "        size = " + a.blurSize + ",\n" +
      "        passes = " + a.blurPasses + ",\n" +
      "    },\n" +
      "    shadow = {\n" +
      "        enabled = " + (a.shadowEnabled ? "true" : "false") + ",\n" +
      "        range = " + a.shadowRange + ",\n" +
      "        render_power = " + a.shadowRenderPower + ",\n" +
      "    },\n" +
      "}\n"
    saveThemeLua.content = lua
    saveThemeLua.running = false
    saveThemeLua.running = true
  }

  Process {
    id: saveLayoutsLua
    property string content: ""
    command: ["bash", "-c",
      "cat > '" + Quickshell.env("HOME") + "/.config/hypr/modules/appearance/autogen/layouta.lua' << 'OOZE_LUA_EOF'\n" + content + "\nOOZE_LUA_EOF\n"]
    running: false
  }

  // Regenera ~/.config/hypr/layouts.lua con el layout por defecto
  // para los 10 workspaces (mismo criterio que tu loop de
  // `for i = 1, 10 do hl.workspace_rule(...) end`).
  function writeLayoutsLua(layoutName) {
    const lua =
      "-- Auto-generado por OozeShell (APPEARANCE). No editar a mano.\n" +
      "return {\n" +
      "    layout = \"" + layoutName + "\",\n" +
      "}\n"
    saveLayoutsLua.content = lua
    saveLayoutsLua.running = false
    saveLayoutsLua.running = true
  }

  // Commit de un valor: actualiza el estado, lo aplica en vivo (por
  // si el commit llega sin preview previo, ej. desde IPC) y persiste
  // cache + theme.lua. Se llama al soltar el slider, o al tocar un
  // toggle (que no tiene "arrastre", así que aplica y persiste junto).
  function setAppearanceValue(key, value) {
    const updated = Object.assign({}, root.appearance)
    updated[key] = value
    root.appearance = updated

    applyAppearanceLive(key, value)
    writeAppearanceCache()
    writeThemeLua()
  }

  Process {
    id: applyLayoutKeyword
    property string cmd: ""
    command: ["bash", "-c", cmd]
    running: false
    stdout: SplitParser { onRead: line => console.log("[layout] hyprctl:", line) }
    stderr: SplitParser { onRead: line => console.log("[layout] hyprctl error:", line) }
  }

  Process {
    id: notifyLayoutChange
    property string cmd: ""
    command: ["bash", "-c", cmd]
    running: false
  }

  // Cambia el layout por defecto de los 10 workspaces, tanto en vivo
  // (hyprctl keyword, se ve al toque) como persistido (layouts.lua).
  // Como el bind SUPER+K lee el layout en vivo del workspace activo
  // (hl.get_active_workspace().tiled_layout), no hace falta sincronizar
  // nada aparte: al aplicar acá con hyprctl keyword, la próxima vez
  // que se apriete SUPER+K va a ciclar a partir del layout real.
  function setLayout(layoutName) {
    const updated = Object.assign({}, root.appearance)
    updated.layout = layoutName
    root.appearance = updated

    // Un solo hyprctl eval con un for de Lua, en vez de 10 llamadas
    // separadas: mismo criterio que tu loop `for i = 1, 10 do
    // hl.workspace_rule(...) end` en hyprland.lua, pero disparado
    // en caliente vía eval.
    applyLayoutKeyword.cmd =
      "hyprctl eval 'for i = 1, 10 do hl.workspace_rule({ workspace = tostring(i), layout = \"" +
      layoutName + "\" }) end'"
    applyLayoutKeyword.running = false
    applyLayoutKeyword.running = true

    writeAppearanceCache()
    writeLayoutsLua(layoutName)

    // Mismo mecanismo de notificación que ya usa el bind SUPER+K.
    notifyLayoutChange.cmd =
      "quickshell ipc -p ~/.config/hypr/OozeShell/shell.qml call -- notify show 'Layout: " + layoutName + "'"
    notifyLayoutChange.running = false
    notifyLayoutChange.running = true
  }

  IpcHandler {
    target: "appearance"
    function toggle(): void { root.togglePopup("appearance") }
    function get(): string { return JSON.stringify(root.appearance) }
    // set <key> <value>  -- ej: set gapsOut 10 / set blurEnabled true / set shadowRange 8 / set layout master
    function set(key: string, value: string): void {
      if (key === "layout") { root.setLayout(value); return }
      if (key === "blurEnabled" || key === "animationsEnabled" || key === "shadowEnabled") {
        root.setAppearanceValue(key, (value === "true" || value === "1"))
      } else {
        root.setAppearanceValue(key, parseFloat(value))
      }
    }
  }

  Appearance {
    id: appearancePanel
    open: root.appearancePickerOpen
    values: root.appearance
    currentLayout: root.appearance.layout
    targetScreen: root.focusedMonitor
    onCloseRequested: root.appearancePickerOpen = false
    onBackRequested: root.swapTo("menu")
    onPreviewChanged: (key, value) => root.applyAppearanceLive(key, value)
    onValueCommitted: (key, value) => root.setAppearanceValue(key, value)
    onToggleChanged: (key, value) => root.setAppearanceValue(key, value)
    onLayoutChosen: (name) => root.setLayout(name)
  }

  Process {
    id: initColors
    command: ["bash", "-c",
      "WP=$(cat ~/.cache/awww/last 2>/dev/null); " +
      "if [ -n \"$WP\" ] && [ -f \"$WP\" ]; then " +
      "  matugen image \"$WP\" --source-color-index 0 --json hex | sed -n '/^{/,/^}/p' > /tmp/matugen-colors.json; " +
      "fi"
    ]
    running: true
  }


  IpcHandler {
    target: "toggleWalls"
    function handle() { root.wallsOpen = !root.wallsOpen }
  }


  Walls {
    id: walls
    open: root.wallsOpen
    currentIndex: root.currentWallIndex
    targetScreen: root.focusedMonitor
    onCurrentIndexChanged: root.currentWallIndex = walls.currentIndex
    onCloseRequested: root.wallsOpen = false
    onColorsReloaded: Theme.reload()
    // Theme.wallpaperChanging es la misma bandera que barModule.wallpaperChanging
    // (línea de arriba, `wallpaperChanging: walls.changing`) pero accesible desde
    // CUALQUIER popup (FusedWindow), no solo desde la barra: mientras dura, los
    // paneles abiertos se dibujan flotantes en vez de colgar de una barra oculta.
    onChangingChanged: Theme.wallpaperChanging = walls.changing
  }

  // Ejemplos:
  //   quickshell ipc -p .../shell.qml call -- notify toggle
  //   quickshell ipc -p .../shell.qml call -- notify toggleDnd
  //   quickshell ipc -p .../shell.qml call -- notify show 'Layout: master'
  IpcHandler {
    target: "notify"
    function toggle(): void { root.togglePopup("notify") }
    // Toast local (lo usa setLayout() más arriba). No se guarda en el historial.
    function show(text: string): void { NotificationsBackend.pushLocal("OozeShell", text) }
    function toggleDnd(): void { NotificationsBackend.toggleDnd() }
    function enableDnd(): void { NotificationsBackend.dnd = true }
    function disableDnd(): void { NotificationsBackend.dnd = false }
    function isDnd(): bool { return NotificationsBackend.dnd }
    function clear(): void { NotificationsBackend.clearAll() }
  }

  Notify {
    id: notify
    open: root.notifyOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.notifyOpen = false
  }

  MonitorSelect {
    id: monitorSelect
    open: root.monitorPickerOpen
    current: root.targetMonitor
    resolvedCurrent: root.resolveMonitor()
    onCloseRequested: root.monitorPickerOpen = false
    onBackRequested: root.swapTo("settings")
    onMonitorChosen: (name) => root.setMonitor(name)
  }

  IpcHandler {
    target: "keybinds"
    // Ahora es un popup de la barra (FusedPanel): abrirlo cierra los demás
    function toggle(): void { root.togglePopup("keybinds") }
  }

  // ─── Idioma de teclado ───────────────────────────────────────────
  // La forma recomendada de que ALT+SHIFT cambie de layout es nativa de
  // Hyprland (no necesita este IPC ni QML: lo hace libinput/xkb solo,
  // y dispara el mismo evento "activelayout" que ya sincroniza el
  // indicador ESP/ENG de la barra). En el input{} de hyprland.conf:
  //
  //   input {
  //     kb_options = grp:alt_shift_toggle
  //   }
  //
  // Si ya usás kb_options para otra cosa, separalas con coma
  // (ej. "caps:escape,grp:alt_shift_toggle"). Este IpcHandler queda
  // como alternativa manual/de prueba, o por si preferís atarlo vos
  // mismo a otra combinación desde Hyprland:
  //   quickshell ipc -p .../shell.qml call -- keyboardlayout next
  IpcHandler {
    target: "keyboardlayout"
    function next(): void { KeyboardLayout.next() }
  }

  Keybinds {
    id: keybinds
    open: root.keybindsOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.keybindsOpen = false
  }

    IpcHandler {
    target: "mpris"
    function toggle() { root.togglePopup("mpris") }
  }

    Mpris {
    id: mpris
    open: root.mprisOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.mprisOpen = false
  }

  IpcHandler {
    target: "menu"
    function toggle(): void { root.togglePopup("menu") }
  }

  IpcHandler {
    target: "network"
    function toggle(): void { root.togglePopup("network") }
  }

  // quickshell ipc -p .../shell.qml call -- bluetooth toggle
  IpcHandler {
    target: "bluetooth"
    function toggle(): void { root.togglePopup("bluetooth") }
  }

  BluetoothMenu {
    id: bluetoothMenu
    open: root.bluetoothOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.bluetoothOpen = false
    onBackRequested: root.swapTo("menu")
  }

  NetworkMenu {
    id: networkMenu
    open: root.networkOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.networkOpen = false
    onBackRequested: root.swapTo("menu")
  }

  // ─── Audio (salida/entrada + OSD, reemplaza swayosd) ────────────
  // El panel es un popup exclusivo más (mismo sistema que menu/notify/
  // network/mpris); el OSD es independiente y siempre está montado,
  // como NotifToasts, y aparece solo mientras AudioBackend lo pide.
  //
  //   quickshell ipc -p .../shell.qml call -- audio toggle
  //   quickshell ipc -p .../shell.qml call -- audio raise
  //   quickshell ipc -p .../shell.qml call -- audio lower
  //   quickshell ipc -p .../shell.qml call -- audio mute
  //   quickshell ipc -p .../shell.qml call -- audio micToggle
  //
  // Apuntá los binds de volumen de Hyprland (y lo que antes llamaba a
  // swayosd-client) acá: el OSD que dispara es el de AUDIO/AudioOSD.qml,
  // no hace falta correr swayosd-server nunca más.
  IpcHandler {
    target: "audio"
    function toggle(): void { root.togglePopup("audio") }
    function raise(): void { AudioBackend.stepVolume(0.05) }
    function lower(): void { AudioBackend.stepVolume(-0.05) }
    function mute(): void { AudioBackend.toggleMuteOsd() }
    function micToggle(): void { AudioBackend.toggleMicMuteOsd() }
    function micRaise(): void { AudioBackend.stepMicVolume(0.05) }
    function micLower(): void { AudioBackend.stepMicVolume(-0.05) }
  }

  AudioMenu {
    id: audioMenu
    open: root.audioOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.audioOpen = false
  }

  AudioOSD {
    id: audioOsd
    targetScreen: root.focusedMonitor
  }

  // ─── OSD de Caps Lock ───────────────────────────────────────────
  // Aviso flotante al activar/desactivar Caps Lock (CAPS/CapsOSD.qml).
  // Prueba sin teclado:
  //   quickshell ipc -p .../shell.qml call -- caps show true|false
  CapsOSD {
    id: capsOsd
    targetScreen: root.focusedMonitor
  }

  IpcHandler {
    target: "caps"
    function show(on: bool): void { capsOsd.show(on) }
  }

  // ─── Overview (vista general de los workspaces) ─────────────────
  // Botón junto al reloj de la barra. Cuelga de la barra como los demás
  // popups (excluyente con ellos) y se maneja con mouse o teclado; ver
  // OVERVIEW/Overview.qml para las teclas.
  //
  //   quickshell ipc -p .../shell.qml call -- overview toggle
  //   quickshell ipc -p .../shell.qml call -- overview open
  //   quickshell ipc -p .../shell.qml call -- overview close
  IpcHandler {
    target: "overview"
    function toggle(): void { root.togglePopup("overview") }
    function open(): void { root.openPopup("overview") }
    function close(): void { root.overviewOpen = false }
  }

  Overview {
    id: overview
    open: root.overviewOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.overviewOpen = false
  }

  // ─── Launcher (reemplaza el launcher de rofi) ───────────────────
  // Apps / Ventanas / Ejecutar / Archivos en un solo panel. Cuelga de la
  // barra como los demás popups (excluyente con ellos); ver
  // Launcher/Launcher.qml para las teclas.
  //
  //   quickshell ipc -p .../shell.qml call -- launcher toggle
  //   quickshell ipc -p .../shell.qml call -- launcher open apps|windows|run|files
  //   quickshell ipc -p .../shell.qml call -- launcher close
  // Bindealo en Hyprland en vez del script de rofi. `open windows` /
  // `open run` / `open files` reemplazan a `rofi -show window|run|filebrowser`.
  IpcHandler {
    target: "launcher"
    function toggle(): void {
      launcher.startMode = "apps"
      root.togglePopup("launcher")
    }
    function open(mode: string): void {
      const ok = ["apps", "windows", "run", "files"]
      launcher.startMode = ok.indexOf(mode) >= 0 ? mode : "apps"
      root.openPopup("launcher")
    }
    function close(): void { root.launcherOpen = false }
  }

  Launcher {
    id: launcher
    open: root.launcherOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.launcherOpen = false
  }

  // ─── Pac Search (reemplaza el script de rofi + nix-search) ──────
  // Busca paquetes en repos + AUR mientras escribís. Ver PACSEARCH/PacSearch.qml.
  //
  //   quickshell ipc -p .../shell.qml call -- pacsearch toggle
  //   quickshell ipc -p .../shell.qml call -- pacsearch open [consulta]
  //   quickshell ipc -p .../shell.qml call -- pacsearch close
  IpcHandler {
    target: "pacsearch"
    function toggle(): void {
      pacSearch.startQuery = ""
      root.togglePopup("pacsearch")
    }
    function open(query: string): void {
      pacSearch.startQuery = query
      root.openPopup("pacsearch")
    }
    function close(): void { root.pacSearchOpen = false }
  }

  PacSearch {
    id: pacSearch
    open: root.pacSearchOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.pacSearchOpen = false
  }

  // ─── Capturas de pantalla (solo IPC, sin panel) ──────────────────
  // Ver SCREENSHOT/ScreenshotBackend.qml. El marco de selección usa
  // Theme.primary, así que sigue el color del wallpaper actual igual que
  // el resto del shell — pero no hay ningún botón para esto en la UI:
  // asigná estos comandos a tus binds de Hyprland (Print, Shift+Print, etc).
  //   quickshell ipc -p .../shell.qml call -- screenshot areaCopy
  //   quickshell ipc -p .../shell.qml call -- screenshot fullSave
  //   quickshell ipc -p .../shell.qml call -- screenshot areaSave
  IpcHandler {
    target: "screenshot"
    function areaCopy(): void { ScreenshotBackend.areaCopy() }
    function fullSave(): void { ScreenshotBackend.fullSave() }
    function areaSave(): void { ScreenshotBackend.areaSave() }
  }

  // ─── Menú de energía (reemplaza el powermenu.sh de rofi) ────────
  //   quickshell ipc -p .../shell.qml call -- powermenu toggle
  //   quickshell ipc -p .../shell.qml call -- powermenu open
  //   quickshell ipc -p .../shell.qml call -- powermenu close
  // Apuntá acá tu bind de Hyprland (SUPER SHIFT M) en vez de al script.
  IpcHandler {
    target: "powermenu"
    function toggle(): void {
      root.closeAllPopups()
      if (!root.powerOpen) root.focusedMonitor = root.resolveMonitor()
      root.powerOpen = !root.powerOpen
    }
    function open(): void {
      root.closeAllPopups()
      root.focusedMonitor = root.resolveMonitor()
      root.powerOpen = true
    }
    function close(): void { root.powerOpen = false }
  }

  PowerMenu {
    id: powerMenu
    open: root.powerOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.powerOpen = false
  }

  Menu {
    id: menu
    open: root.menuOpen
    targetScreen: root.focusedMonitor
    onCloseRequested: root.menuOpen = false
    onRequestAppearance: root.swapTo("appearance")
    onRequestSettings: root.swapTo("settings")
    onRequestWalls: root.wallsOpen = true
    onRequestNetwork: root.swapTo("network")
    onRequestBluetooth: root.swapTo("bluetooth")
    screenCorners: root.screenCorners
    onRequestCornersToggle: root.setScreenCorners(!root.screenCorners)
  }

}
