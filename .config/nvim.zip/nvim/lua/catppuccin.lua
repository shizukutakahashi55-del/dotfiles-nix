return {
  "catppuccin/nvim",
  name = "catppuccin",
  priority = 1000,

  config = function()
    require("catppuccin").setup({
      flavour = "mocha",

      integrations = {
        neo_tree = true,
        treesitter = true,
        telescope = true,
        lsp_trouble = true,
        cmp = true,
        gitsigns = true,
      },
    })

    vim.cmd.colorscheme("catppuccin-mocha")
  end,
}
