-- ============================================================
-- plugins/neo-tree.lua – Árbol de archivos
-- ============================================================

return {
  "nvim-neo-tree/neo-tree.nvim",
  branch = "v3.x",

  dependencies = {
    "nvim-lua/plenary.nvim",
    "nvim-tree/nvim-web-devicons",
    "MunifTanjim/nui.nvim",
  },

  keys = {
    {
      "<leader>e",
      "<cmd>Neotree toggle<CR>",
      desc = "Toggle árbol",
    },
    {
      "<leader>ef",
      "<cmd>Neotree reveal<CR>",
      desc = "Revelar archivo actual",
    },
    {
      "<leader>eg",
      "<cmd>Neotree git_status<CR>",
      desc = "Git status en árbol",
    },
  },

  opts = {
    -- ----------------------------------------------------------
    -- Apariencia
    -- ----------------------------------------------------------
    popup_border_style = "rounded",

    default_component_configs = {
      indent = {
        indent_size = 2,
        padding = 1,
        with_markers = true,

        indent_marker = "│",
        last_indent_marker = "└",

        with_expanders = true,
        expander_collapsed = "",
        expander_expanded = "",
      },

      icon = {
        folder_closed = "",
        folder_open = "",
        folder_empty = "󰜌",
        default = "󰈔",
      },

      git_status = {
        symbols = {
          added = "✚",
          modified = "",
          deleted = "✖",
          renamed = "󰁕",
          untracked = "",
          ignored = "",
          unstaged = "󰄱",
          staged = "",
          conflict = "",
        },
      },
    },

    -- ----------------------------------------------------------
    -- Ventana principal
    -- ----------------------------------------------------------
    window = {
      position = "left",
      width = 35,

      mappings = {
        ["<space>"] = "toggle_node",
        ["<cr>"] = "open",

        ["S"] = "open_split",
        ["s"] = "open_vsplit",
        ["t"] = "open_tabnew",

        ["P"] = {
          "toggle_preview",
          config = {
            use_float = true,
          },
        },

        ["a"] = {
          "add",
          config = {
            show_path = "relative",
          },
        },

        ["d"] = "delete",
        ["r"] = "rename",

        ["y"] = "copy_to_clipboard",
        ["x"] = "cut_to_clipboard",
        ["p"] = "paste_from_clipboard",

        ["c"] = "copy",
        ["m"] = "move",

        ["q"] = "close_window",
        ["R"] = "refresh",
        ["?"] = "show_help",
      },
    },

    -- ----------------------------------------------------------
    -- Sistema de archivos
    -- ----------------------------------------------------------
    filesystem = {
      filtered_items = {
        visible = false,

        -- Mostrar archivos ocultos como .env, .gitignore, etc.
        hide_dotfiles = false,

        -- Ocultar archivos ignorados por Git
        hide_gitignored = true,

        -- Directorios que no queremos mostrar
        hide_by_name = {
          "node_modules",
          ".git",
        },
      },

      follow_current_file = {
        enabled = true,
        leave_dirs_open = true,
      },

      use_libuv_file_watcher = true,
    },

    -- ----------------------------------------------------------
    -- Buffers
    -- ----------------------------------------------------------
    buffers = {
      follow_current_file = {
        enabled = true,
      },
    },

    -- ----------------------------------------------------------
    -- Git
    -- ----------------------------------------------------------
    git_status = {
      window = {
        position = "float",
      },
    },
  },
}
