-- ============================================================
--  lua/plugins/themes.lua  –  Temas de color
--  Tema activo por defecto: TokyoNight Night
-- ============================================================
return {

  -- ── TokyoNight ────────────────────────────────────────────
  {
    "folke/tokyonight.nvim",
    priority = 1000,
    lazy     = false,   -- carga inmediata para que el tema esté disponible
    opts = {
      style      = "night",   -- "night" | "storm" | "moon" | "day"
      transparent = false,
      styles = {
        comments = { italic = true },
        keywords = { italic = true },
      },
      -- Integración con plugins
      on_highlights = function(hl, c)
        hl.DashboardHeader  = { fg = c.blue }
        hl.DashboardFooter  = { fg = c.comment }
      end,
    },
    config = function(_, opts)
      require("tokyonight").setup(opts)
      vim.cmd.colorscheme("tokyonight-night")  -- ← tema por defecto
    end,
  },

  -- ── Catppuccin ────────────────────────────────────────────
  {
    "catppuccin/nvim",
    name     = "catppuccin",
    priority = 999,
    lazy     = true,
    opts = {
      flavour = "mocha",
      integrations = {
        neo_tree   = true,
        telescope  = { enabled = true },
        treesitter = true,
        lualine    = true,
        bufferline = true,
        dashboard  = true,
        which_key  = true,
        indent_blankline = { enabled = true },
      },
    },
  },

  -- ── Gruvbox Material ──────────────────────────────────────
  {
    "sainnhe/gruvbox-material",
    priority = 999,
    lazy     = true,
    config = function()
      vim.g.gruvbox_material_background    = "medium"
      vim.g.gruvbox_material_foreground    = "material"
      vim.g.gruvbox_material_enable_italic = 1
      vim.g.gruvbox_material_enable_bold   = 1
    end,
  },
}
