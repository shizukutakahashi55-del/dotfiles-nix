#!/usr/bin/env bash
# Instala las fuentes de iconos (obligatorias) y la config de fontconfig.
# La fuente pixel de texto es opcional: ver ARCH.md → Fuentes.
set -e
sudo pacman -S --needed ttf-jetbrains-mono-nerd ttf-nerd-fonts-symbols-mono
# Fuente de texto de OozeSoft (opcional; sin ella se usa Varela Round, ya incluida).
# Si el paquete no existe en tu mirror, instala Nunito/Outfit/Lexend desde Google Fonts.
sudo pacman -S --needed ttf-nunito || echo "(opcional) instala Nunito, Outfit o Lexend a mano"
mkdir -p ~/.config/fontconfig/conf.d
cp "$(dirname "$0")/99-oozeshell-pixel.conf" ~/.config/fontconfig/conf.d/
fc-cache -f
echo "Listo. Reinicia quickshell para que lea las fuentes nuevas."
